import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/models/weather_data.dart';
import 'package:dio/dio.dart' as dio;
import '../../../../core/services/gps_tracking_service.dart';
import '../../../../core/services/weather_repository.dart';
import '../../../../core/services/weather_service.dart';

// Reverse geocoding + fallback na súradnice
final _locationNameProvider = FutureProvider<String?>((ref) async {
  final pos = GpsTrackingService().lastPosition;
  if (pos == null) return null;

  final lat = pos.latitude;
  final lon = pos.longitude;
  final coordStr = '${lat.toStringAsFixed(4)}°N, ${lon.toStringAsFixed(4)}°E';

  try {
    final response = await dio.Dio().get(
      'https://nominatim.openstreetmap.org/reverse',
      queryParameters: {
        'lat': lat.toString(),
        'lon': lon.toString(),
        'format': 'json',
        'zoom': '10',
      },
      options: dio.Options(
        headers: {'User-Agent': 'HMBSailingLog/1.0'},
        sendTimeout: const Duration(seconds: 5),
        receiveTimeout: const Duration(seconds: 5),
      ),
    );
    final data = response.data as Map<String, dynamic>;
    final address = data['address'] as Map<String, dynamic>?;
    final name = address?['city'] ?? address?['town'] ??
                 address?['village'] ?? address?['county'] ??
                 address?['state'];
    return name != null ? '$name ($coordStr)' : coordStr;
  } catch (_) {
    return coordStr; // Fallback na GPS súradnice
  }
});

final weatherProvider = FutureProvider<List<WeatherData>>((ref) async {
  return WeatherService().getForecast();
});

class WeatherScreen extends ConsumerWidget {
  const WeatherScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weatherAsync = ref.watch(weatherProvider);

    final locationName = ref.watch(_locationNameProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Počasie a more'),
            if (locationName != null)
              Text(locationName,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Aktualizovať predpoveď',
            onPressed: () async {
              final pos = GpsTrackingService().lastPosition;
              if (pos == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('GPS nie je dostupné – zapnite tracking'),
                  ),
                );
                return;
              }
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Sťahujem predpoveď...'),
                  duration: Duration(seconds: 2),
                ),
              );
              try {
                await WeatherRepository().syncWeather(
                  lat: pos.latitude,
                  lon: pos.longitude,
                );
                ref.invalidate(weatherProvider);
              } catch (e) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Chyba: $e')),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: weatherAsync.when(
        data: (forecast) {
          if (forecast.isEmpty) {
            return _EmptyWeather();
          }
          return _WeatherContent(forecast: forecast);
        },
        loading: () => const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Načítavam predpoveď...'),
            ],
          ),
        ),
        error: (e, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off, size: 64, color: Colors.grey),
              const SizedBox(height: 16),
              const Text('Nie je dostupné spojenie'),
              const SizedBox(height: 8),
              const Text(
                'Stlačte refresh keď ste online',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyWeather extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cloud_download_outlined,
                size: 64, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text('Žiadne dáta počasia',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(color: Colors.grey)),
            const SizedBox(height: 8),
            const Text(
              'Predpoveď sa stiahne automaticky po spustení trackingu, alebo stlačte Refresh.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () async {
                final pos = GpsTrackingService().lastPosition;
                if (pos == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Zapnite GPS / tracking najprv')),
                  );
                  return;
                }
                try {
                  await WeatherRepository().syncWeather(
                    lat: pos.latitude,
                    lon: pos.longitude,
                  );
                  ref.invalidate(weatherProvider);
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Chyba sťahovania: $e')),
                    );
                  }
                }
              },
              icon: const Icon(Icons.refresh),
              label: const Text('Stiahnuť predpoveď'),
            ),
          ],
        ),
      ),
    );
  }
}

class _WeatherContent extends StatelessWidget {
  final List<WeatherData> forecast;
  const _WeatherContent({required this.forecast});

  @override
  Widget build(BuildContext context) {
    if (forecast.isEmpty) return const SizedBox();
    final current = forecast.first;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _CurrentWeatherCard(weather: current),
        const SizedBox(height: 12),
        _BeaufortCard(beaufort: current.beaufort),
        const SizedBox(height: 12),
        _WindChart(forecast: forecast.take(24).toList()),
        const SizedBox(height: 12),
        _WaveChart(forecast: forecast.take(24).toList()),
        const SizedBox(height: 12),
        _HourlyTable(forecast: forecast.take(12).toList()),
      ],
    );
  }
}

class _CurrentWeatherCard extends StatelessWidget {
  final WeatherData weather;
  const _CurrentWeatherCard({required this.weather});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Text('${weather.windSpeed.toStringAsFixed(0)} kn',
                  style: Theme.of(context).textTheme.displaySmall?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.primary)),
              const SizedBox(width: 8),
              Text('${weather.windDirectionLabel} ${weather.windDirection.toStringAsFixed(0)}°',
                  style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              const Icon(Icons.air, size: 32),
            ]),
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _Metric('Vlny', '${weather.waveHeight.toStringAsFixed(1)} m', Icons.waves),
                _Metric('Tlak', '${weather.airPressure.toStringAsFixed(0)} hPa', Icons.compress),
                _Metric('Vzduch', '${weather.airTemp.toStringAsFixed(0)}°C', Icons.thermostat),
                _Metric('Voda', '${weather.waterTemp.toStringAsFixed(0)}°C', Icons.water),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const _Metric(this.label, this.value, this.icon);

  @override
  Widget build(BuildContext context) => Column(children: [
        Icon(icon, size: 20, color: Colors.grey),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ]);
}

class _BeaufortCard extends StatelessWidget {
  final int beaufort;
  const _BeaufortCard({required this.beaufort});

  static const _desc = [
    'Bezvetrie', 'Tichý vánok', 'Slabý vietor', 'Slabý vietor',
    'Mierny vietor', 'Dosť čerstvý', 'Čerstvý vietor', 'Silný vietor',
    'Búrlivý vietor', 'Búrka', 'Silná búrka', 'Mimoriadna búrka', 'Orkán',
  ];

  Color get _color {
    if (beaufort <= 3) return Colors.green;
    if (beaufort <= 5) return Colors.orange;
    if (beaufort <= 7) return Colors.deepOrange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) => Card(
        color: _color.withOpacity(0.1),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: _color,
            child: Text('$beaufort',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          title: Text('Beaufort $beaufort'),
          subtitle: Text(beaufort < _desc.length ? _desc[beaufort] : ''),
          trailing: Icon(Icons.flag, color: _color),
        ),
      );
}

class _WindChart extends StatelessWidget {
  final List<WeatherData> forecast;
  const _WindChart({required this.forecast});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Vietor – 24h',
                  style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(height: 16),
              SizedBox(
                height: 150,
                child: LineChart(LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 30,
                            getTitlesWidget: (v, _) => Text('${v.toInt()}',
                                style: const TextStyle(fontSize: 10)))),
                    bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                            showTitles: true,
                            interval: 6,
                            getTitlesWidget: (v, _) {
                              final i = v.toInt();
                              if (i >= forecast.length) return const SizedBox();
                              return Text('${forecast[i].time.hour}h',
                                  style: const TextStyle(fontSize: 10));
                            })),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: forecast
                          .asMap()
                          .entries
                          .map((e) => FlSpot(e.key.toDouble(), e.value.windSpeed))
                          .toList(),
                      isCurved: true,
                      color: Colors.blue,
                      barWidth: 2,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: Colors.blue.withOpacity(0.1)),
                    ),
                  ],
                )),
              ),
            ],
          ),
        ),
      );
}

class _WaveChart extends StatelessWidget {
  final List<WeatherData> forecast;
  const _WaveChart({required this.forecast});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Vlny – 24h',
                  style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(height: 16),
              SizedBox(
                height: 120,
                child: LineChart(LineChartData(
                  gridData: const FlGridData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 32,
                            getTitlesWidget: (v, _) =>
                                Text('${v.toStringAsFixed(1)}m',
                                    style: const TextStyle(fontSize: 9)))),
                    bottomTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: forecast
                          .asMap()
                          .entries
                          .map((e) => FlSpot(e.key.toDouble(), e.value.waveHeight))
                          .toList(),
                      isCurved: true,
                      color: Colors.teal,
                      barWidth: 2,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: Colors.teal.withOpacity(0.1)),
                    ),
                  ],
                )),
              ),
            ],
          ),
        ),
      );
}

class _HourlyTable extends StatelessWidget {
  final List<WeatherData> forecast;
  const _HourlyTable({required this.forecast});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Hodinová predpoveď',
                  style: Theme.of(context).textTheme.titleSmall),
              const SizedBox(height: 8),
              Table(
                columnWidths: const {
                  0: FlexColumnWidth(2),
                  1: FlexColumnWidth(2),
                  2: FlexColumnWidth(2),
                  3: FlexColumnWidth(2),
                },
                children: [
                  TableRow(
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer),
                    children: ['Čas', 'Vietor', 'Vlny', 'Tlak']
                        .map((h) => Padding(
                              padding: const EdgeInsets.all(8),
                              child: Text(h,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12)),
                            ))
                        .toList(),
                  ),
                  ...forecast.map((w) => TableRow(children: [
                        _cell('${w.time.hour}:00'),
                        _cell(
                            '${w.windSpeed.toStringAsFixed(0)} kn ${w.windDirectionLabel}'),
                        _cell('${w.waveHeight.toStringAsFixed(1)} m'),
                        _cell('${w.airPressure.toStringAsFixed(0)} hPa'),
                      ])),
                ],
              ),
            ],
          ),
        ),
      );

  Widget _cell(String t) => Padding(
        padding: const EdgeInsets.all(8),
        child: Text(t, style: const TextStyle(fontSize: 12)),
      );
}
