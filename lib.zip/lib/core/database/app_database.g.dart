// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $ChartersTable extends Charters with TableInfo<$ChartersTable, Charter> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ChartersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dateFromMeta =
      const VerificationMeta('dateFrom');
  @override
  late final GeneratedColumn<DateTime> dateFrom = GeneratedColumn<DateTime>(
      'date_from', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _dateToMeta = const VerificationMeta('dateTo');
  @override
  late final GeneratedColumn<DateTime> dateTo = GeneratedColumn<DateTime>(
      'date_to', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _vesselNameMeta =
      const VerificationMeta('vesselName');
  @override
  late final GeneratedColumn<String> vesselName = GeneratedColumn<String>(
      'vessel_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _vesselTypeMeta =
      const VerificationMeta('vesselType');
  @override
  late final GeneratedColumn<String> vesselType = GeneratedColumn<String>(
      'vessel_type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _homePortMeta =
      const VerificationMeta('homePort');
  @override
  late final GeneratedColumn<String> homePort = GeneratedColumn<String>(
      'home_port', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _skipperNameMeta =
      const VerificationMeta('skipperName');
  @override
  late final GeneratedColumn<String> skipperName = GeneratedColumn<String>(
      'skipper_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _crewNamesMeta =
      const VerificationMeta('crewNames');
  @override
  late final GeneratedColumn<String> crewNames = GeneratedColumn<String>(
      'crew_names', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _notesMeta = const VerificationMeta('notes');
  @override
  late final GeneratedColumn<String> notes = GeneratedColumn<String>(
      'notes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _safetyBriefingDoneMeta =
      const VerificationMeta('safetyBriefingDone');
  @override
  late final GeneratedColumn<bool> safetyBriefingDone = GeneratedColumn<bool>(
      'safety_briefing_done', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("safety_briefing_done" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _checkInDoneMeta =
      const VerificationMeta('checkInDone');
  @override
  late final GeneratedColumn<bool> checkInDone = GeneratedColumn<bool>(
      'check_in_done', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("check_in_done" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _checkOutDoneMeta =
      const VerificationMeta('checkOutDone');
  @override
  late final GeneratedColumn<bool> checkOutDone = GeneratedColumn<bool>(
      'check_out_done', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("check_out_done" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        title,
        dateFrom,
        dateTo,
        vesselName,
        vesselType,
        homePort,
        skipperName,
        crewNames,
        notes,
        safetyBriefingDone,
        checkInDone,
        checkOutDone,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'charters';
  @override
  VerificationContext validateIntegrity(Insertable<Charter> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('date_from')) {
      context.handle(_dateFromMeta,
          dateFrom.isAcceptableOrUnknown(data['date_from']!, _dateFromMeta));
    } else if (isInserting) {
      context.missing(_dateFromMeta);
    }
    if (data.containsKey('date_to')) {
      context.handle(_dateToMeta,
          dateTo.isAcceptableOrUnknown(data['date_to']!, _dateToMeta));
    } else if (isInserting) {
      context.missing(_dateToMeta);
    }
    if (data.containsKey('vessel_name')) {
      context.handle(
          _vesselNameMeta,
          vesselName.isAcceptableOrUnknown(
              data['vessel_name']!, _vesselNameMeta));
    }
    if (data.containsKey('vessel_type')) {
      context.handle(
          _vesselTypeMeta,
          vesselType.isAcceptableOrUnknown(
              data['vessel_type']!, _vesselTypeMeta));
    }
    if (data.containsKey('home_port')) {
      context.handle(_homePortMeta,
          homePort.isAcceptableOrUnknown(data['home_port']!, _homePortMeta));
    }
    if (data.containsKey('skipper_name')) {
      context.handle(
          _skipperNameMeta,
          skipperName.isAcceptableOrUnknown(
              data['skipper_name']!, _skipperNameMeta));
    }
    if (data.containsKey('crew_names')) {
      context.handle(_crewNamesMeta,
          crewNames.isAcceptableOrUnknown(data['crew_names']!, _crewNamesMeta));
    }
    if (data.containsKey('notes')) {
      context.handle(
          _notesMeta, notes.isAcceptableOrUnknown(data['notes']!, _notesMeta));
    }
    if (data.containsKey('safety_briefing_done')) {
      context.handle(
          _safetyBriefingDoneMeta,
          safetyBriefingDone.isAcceptableOrUnknown(
              data['safety_briefing_done']!, _safetyBriefingDoneMeta));
    }
    if (data.containsKey('check_in_done')) {
      context.handle(
          _checkInDoneMeta,
          checkInDone.isAcceptableOrUnknown(
              data['check_in_done']!, _checkInDoneMeta));
    }
    if (data.containsKey('check_out_done')) {
      context.handle(
          _checkOutDoneMeta,
          checkOutDone.isAcceptableOrUnknown(
              data['check_out_done']!, _checkOutDoneMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Charter map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Charter(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      dateFrom: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}date_from'])!,
      dateTo: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}date_to'])!,
      vesselName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}vessel_name']),
      vesselType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}vessel_type']),
      homePort: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}home_port']),
      skipperName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}skipper_name']),
      crewNames: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crew_names']),
      notes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}notes']),
      safetyBriefingDone: attachedDatabase.typeMapping.read(
          DriftSqlType.bool, data['${effectivePrefix}safety_briefing_done'])!,
      checkInDone: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}check_in_done'])!,
      checkOutDone: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}check_out_done'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $ChartersTable createAlias(String alias) {
    return $ChartersTable(attachedDatabase, alias);
  }
}

class Charter extends DataClass implements Insertable<Charter> {
  final int id;
  final String title;
  final DateTime dateFrom;
  final DateTime dateTo;
  final String? vesselName;
  final String? vesselType;
  final String? homePort;
  final String? skipperName;
  final String? crewNames;
  final String? notes;
  final bool safetyBriefingDone;
  final bool checkInDone;
  final bool checkOutDone;
  final DateTime createdAt;
  const Charter(
      {required this.id,
      required this.title,
      required this.dateFrom,
      required this.dateTo,
      this.vesselName,
      this.vesselType,
      this.homePort,
      this.skipperName,
      this.crewNames,
      this.notes,
      required this.safetyBriefingDone,
      required this.checkInDone,
      required this.checkOutDone,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['title'] = Variable<String>(title);
    map['date_from'] = Variable<DateTime>(dateFrom);
    map['date_to'] = Variable<DateTime>(dateTo);
    if (!nullToAbsent || vesselName != null) {
      map['vessel_name'] = Variable<String>(vesselName);
    }
    if (!nullToAbsent || vesselType != null) {
      map['vessel_type'] = Variable<String>(vesselType);
    }
    if (!nullToAbsent || homePort != null) {
      map['home_port'] = Variable<String>(homePort);
    }
    if (!nullToAbsent || skipperName != null) {
      map['skipper_name'] = Variable<String>(skipperName);
    }
    if (!nullToAbsent || crewNames != null) {
      map['crew_names'] = Variable<String>(crewNames);
    }
    if (!nullToAbsent || notes != null) {
      map['notes'] = Variable<String>(notes);
    }
    map['safety_briefing_done'] = Variable<bool>(safetyBriefingDone);
    map['check_in_done'] = Variable<bool>(checkInDone);
    map['check_out_done'] = Variable<bool>(checkOutDone);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  ChartersCompanion toCompanion(bool nullToAbsent) {
    return ChartersCompanion(
      id: Value(id),
      title: Value(title),
      dateFrom: Value(dateFrom),
      dateTo: Value(dateTo),
      vesselName: vesselName == null && nullToAbsent
          ? const Value.absent()
          : Value(vesselName),
      vesselType: vesselType == null && nullToAbsent
          ? const Value.absent()
          : Value(vesselType),
      homePort: homePort == null && nullToAbsent
          ? const Value.absent()
          : Value(homePort),
      skipperName: skipperName == null && nullToAbsent
          ? const Value.absent()
          : Value(skipperName),
      crewNames: crewNames == null && nullToAbsent
          ? const Value.absent()
          : Value(crewNames),
      notes:
          notes == null && nullToAbsent ? const Value.absent() : Value(notes),
      safetyBriefingDone: Value(safetyBriefingDone),
      checkInDone: Value(checkInDone),
      checkOutDone: Value(checkOutDone),
      createdAt: Value(createdAt),
    );
  }

  factory Charter.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Charter(
      id: serializer.fromJson<int>(json['id']),
      title: serializer.fromJson<String>(json['title']),
      dateFrom: serializer.fromJson<DateTime>(json['dateFrom']),
      dateTo: serializer.fromJson<DateTime>(json['dateTo']),
      vesselName: serializer.fromJson<String?>(json['vesselName']),
      vesselType: serializer.fromJson<String?>(json['vesselType']),
      homePort: serializer.fromJson<String?>(json['homePort']),
      skipperName: serializer.fromJson<String?>(json['skipperName']),
      crewNames: serializer.fromJson<String?>(json['crewNames']),
      notes: serializer.fromJson<String?>(json['notes']),
      safetyBriefingDone: serializer.fromJson<bool>(json['safetyBriefingDone']),
      checkInDone: serializer.fromJson<bool>(json['checkInDone']),
      checkOutDone: serializer.fromJson<bool>(json['checkOutDone']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'title': serializer.toJson<String>(title),
      'dateFrom': serializer.toJson<DateTime>(dateFrom),
      'dateTo': serializer.toJson<DateTime>(dateTo),
      'vesselName': serializer.toJson<String?>(vesselName),
      'vesselType': serializer.toJson<String?>(vesselType),
      'homePort': serializer.toJson<String?>(homePort),
      'skipperName': serializer.toJson<String?>(skipperName),
      'crewNames': serializer.toJson<String?>(crewNames),
      'notes': serializer.toJson<String?>(notes),
      'safetyBriefingDone': serializer.toJson<bool>(safetyBriefingDone),
      'checkInDone': serializer.toJson<bool>(checkInDone),
      'checkOutDone': serializer.toJson<bool>(checkOutDone),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  Charter copyWith(
          {int? id,
          String? title,
          DateTime? dateFrom,
          DateTime? dateTo,
          Value<String?> vesselName = const Value.absent(),
          Value<String?> vesselType = const Value.absent(),
          Value<String?> homePort = const Value.absent(),
          Value<String?> skipperName = const Value.absent(),
          Value<String?> crewNames = const Value.absent(),
          Value<String?> notes = const Value.absent(),
          bool? safetyBriefingDone,
          bool? checkInDone,
          bool? checkOutDone,
          DateTime? createdAt}) =>
      Charter(
        id: id ?? this.id,
        title: title ?? this.title,
        dateFrom: dateFrom ?? this.dateFrom,
        dateTo: dateTo ?? this.dateTo,
        vesselName: vesselName.present ? vesselName.value : this.vesselName,
        vesselType: vesselType.present ? vesselType.value : this.vesselType,
        homePort: homePort.present ? homePort.value : this.homePort,
        skipperName: skipperName.present ? skipperName.value : this.skipperName,
        crewNames: crewNames.present ? crewNames.value : this.crewNames,
        notes: notes.present ? notes.value : this.notes,
        safetyBriefingDone: safetyBriefingDone ?? this.safetyBriefingDone,
        checkInDone: checkInDone ?? this.checkInDone,
        checkOutDone: checkOutDone ?? this.checkOutDone,
        createdAt: createdAt ?? this.createdAt,
      );
  Charter copyWithCompanion(ChartersCompanion data) {
    return Charter(
      id: data.id.present ? data.id.value : this.id,
      title: data.title.present ? data.title.value : this.title,
      dateFrom: data.dateFrom.present ? data.dateFrom.value : this.dateFrom,
      dateTo: data.dateTo.present ? data.dateTo.value : this.dateTo,
      vesselName:
          data.vesselName.present ? data.vesselName.value : this.vesselName,
      vesselType:
          data.vesselType.present ? data.vesselType.value : this.vesselType,
      homePort: data.homePort.present ? data.homePort.value : this.homePort,
      skipperName:
          data.skipperName.present ? data.skipperName.value : this.skipperName,
      crewNames: data.crewNames.present ? data.crewNames.value : this.crewNames,
      notes: data.notes.present ? data.notes.value : this.notes,
      safetyBriefingDone: data.safetyBriefingDone.present
          ? data.safetyBriefingDone.value
          : this.safetyBriefingDone,
      checkInDone:
          data.checkInDone.present ? data.checkInDone.value : this.checkInDone,
      checkOutDone: data.checkOutDone.present
          ? data.checkOutDone.value
          : this.checkOutDone,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Charter(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('dateFrom: $dateFrom, ')
          ..write('dateTo: $dateTo, ')
          ..write('vesselName: $vesselName, ')
          ..write('vesselType: $vesselType, ')
          ..write('homePort: $homePort, ')
          ..write('skipperName: $skipperName, ')
          ..write('crewNames: $crewNames, ')
          ..write('notes: $notes, ')
          ..write('safetyBriefingDone: $safetyBriefingDone, ')
          ..write('checkInDone: $checkInDone, ')
          ..write('checkOutDone: $checkOutDone, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      title,
      dateFrom,
      dateTo,
      vesselName,
      vesselType,
      homePort,
      skipperName,
      crewNames,
      notes,
      safetyBriefingDone,
      checkInDone,
      checkOutDone,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Charter &&
          other.id == this.id &&
          other.title == this.title &&
          other.dateFrom == this.dateFrom &&
          other.dateTo == this.dateTo &&
          other.vesselName == this.vesselName &&
          other.vesselType == this.vesselType &&
          other.homePort == this.homePort &&
          other.skipperName == this.skipperName &&
          other.crewNames == this.crewNames &&
          other.notes == this.notes &&
          other.safetyBriefingDone == this.safetyBriefingDone &&
          other.checkInDone == this.checkInDone &&
          other.checkOutDone == this.checkOutDone &&
          other.createdAt == this.createdAt);
}

class ChartersCompanion extends UpdateCompanion<Charter> {
  final Value<int> id;
  final Value<String> title;
  final Value<DateTime> dateFrom;
  final Value<DateTime> dateTo;
  final Value<String?> vesselName;
  final Value<String?> vesselType;
  final Value<String?> homePort;
  final Value<String?> skipperName;
  final Value<String?> crewNames;
  final Value<String?> notes;
  final Value<bool> safetyBriefingDone;
  final Value<bool> checkInDone;
  final Value<bool> checkOutDone;
  final Value<DateTime> createdAt;
  const ChartersCompanion({
    this.id = const Value.absent(),
    this.title = const Value.absent(),
    this.dateFrom = const Value.absent(),
    this.dateTo = const Value.absent(),
    this.vesselName = const Value.absent(),
    this.vesselType = const Value.absent(),
    this.homePort = const Value.absent(),
    this.skipperName = const Value.absent(),
    this.crewNames = const Value.absent(),
    this.notes = const Value.absent(),
    this.safetyBriefingDone = const Value.absent(),
    this.checkInDone = const Value.absent(),
    this.checkOutDone = const Value.absent(),
    this.createdAt = const Value.absent(),
  });
  ChartersCompanion.insert({
    this.id = const Value.absent(),
    required String title,
    required DateTime dateFrom,
    required DateTime dateTo,
    this.vesselName = const Value.absent(),
    this.vesselType = const Value.absent(),
    this.homePort = const Value.absent(),
    this.skipperName = const Value.absent(),
    this.crewNames = const Value.absent(),
    this.notes = const Value.absent(),
    this.safetyBriefingDone = const Value.absent(),
    this.checkInDone = const Value.absent(),
    this.checkOutDone = const Value.absent(),
    required DateTime createdAt,
  })  : title = Value(title),
        dateFrom = Value(dateFrom),
        dateTo = Value(dateTo),
        createdAt = Value(createdAt);
  static Insertable<Charter> custom({
    Expression<int>? id,
    Expression<String>? title,
    Expression<DateTime>? dateFrom,
    Expression<DateTime>? dateTo,
    Expression<String>? vesselName,
    Expression<String>? vesselType,
    Expression<String>? homePort,
    Expression<String>? skipperName,
    Expression<String>? crewNames,
    Expression<String>? notes,
    Expression<bool>? safetyBriefingDone,
    Expression<bool>? checkInDone,
    Expression<bool>? checkOutDone,
    Expression<DateTime>? createdAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (title != null) 'title': title,
      if (dateFrom != null) 'date_from': dateFrom,
      if (dateTo != null) 'date_to': dateTo,
      if (vesselName != null) 'vessel_name': vesselName,
      if (vesselType != null) 'vessel_type': vesselType,
      if (homePort != null) 'home_port': homePort,
      if (skipperName != null) 'skipper_name': skipperName,
      if (crewNames != null) 'crew_names': crewNames,
      if (notes != null) 'notes': notes,
      if (safetyBriefingDone != null)
        'safety_briefing_done': safetyBriefingDone,
      if (checkInDone != null) 'check_in_done': checkInDone,
      if (checkOutDone != null) 'check_out_done': checkOutDone,
      if (createdAt != null) 'created_at': createdAt,
    });
  }

  ChartersCompanion copyWith(
      {Value<int>? id,
      Value<String>? title,
      Value<DateTime>? dateFrom,
      Value<DateTime>? dateTo,
      Value<String?>? vesselName,
      Value<String?>? vesselType,
      Value<String?>? homePort,
      Value<String?>? skipperName,
      Value<String?>? crewNames,
      Value<String?>? notes,
      Value<bool>? safetyBriefingDone,
      Value<bool>? checkInDone,
      Value<bool>? checkOutDone,
      Value<DateTime>? createdAt}) {
    return ChartersCompanion(
      id: id ?? this.id,
      title: title ?? this.title,
      dateFrom: dateFrom ?? this.dateFrom,
      dateTo: dateTo ?? this.dateTo,
      vesselName: vesselName ?? this.vesselName,
      vesselType: vesselType ?? this.vesselType,
      homePort: homePort ?? this.homePort,
      skipperName: skipperName ?? this.skipperName,
      crewNames: crewNames ?? this.crewNames,
      notes: notes ?? this.notes,
      safetyBriefingDone: safetyBriefingDone ?? this.safetyBriefingDone,
      checkInDone: checkInDone ?? this.checkInDone,
      checkOutDone: checkOutDone ?? this.checkOutDone,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (dateFrom.present) {
      map['date_from'] = Variable<DateTime>(dateFrom.value);
    }
    if (dateTo.present) {
      map['date_to'] = Variable<DateTime>(dateTo.value);
    }
    if (vesselName.present) {
      map['vessel_name'] = Variable<String>(vesselName.value);
    }
    if (vesselType.present) {
      map['vessel_type'] = Variable<String>(vesselType.value);
    }
    if (homePort.present) {
      map['home_port'] = Variable<String>(homePort.value);
    }
    if (skipperName.present) {
      map['skipper_name'] = Variable<String>(skipperName.value);
    }
    if (crewNames.present) {
      map['crew_names'] = Variable<String>(crewNames.value);
    }
    if (notes.present) {
      map['notes'] = Variable<String>(notes.value);
    }
    if (safetyBriefingDone.present) {
      map['safety_briefing_done'] = Variable<bool>(safetyBriefingDone.value);
    }
    if (checkInDone.present) {
      map['check_in_done'] = Variable<bool>(checkInDone.value);
    }
    if (checkOutDone.present) {
      map['check_out_done'] = Variable<bool>(checkOutDone.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ChartersCompanion(')
          ..write('id: $id, ')
          ..write('title: $title, ')
          ..write('dateFrom: $dateFrom, ')
          ..write('dateTo: $dateTo, ')
          ..write('vesselName: $vesselName, ')
          ..write('vesselType: $vesselType, ')
          ..write('homePort: $homePort, ')
          ..write('skipperName: $skipperName, ')
          ..write('crewNames: $crewNames, ')
          ..write('notes: $notes, ')
          ..write('safetyBriefingDone: $safetyBriefingDone, ')
          ..write('checkInDone: $checkInDone, ')
          ..write('checkOutDone: $checkOutDone, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }
}

class $DayLogsTable extends DayLogs with TableInfo<$DayLogsTable, DayLog> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DayLogsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _charterIdMeta =
      const VerificationMeta('charterId');
  @override
  late final GeneratedColumn<int> charterId = GeneratedColumn<int>(
      'charter_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES charters (id)'));
  static const VerificationMeta _dateMeta = const VerificationMeta('date');
  @override
  late final GeneratedColumn<DateTime> date = GeneratedColumn<DateTime>(
      'date', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _portFromMeta =
      const VerificationMeta('portFrom');
  @override
  late final GeneratedColumn<String> portFrom = GeneratedColumn<String>(
      'port_from', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _portToMeta = const VerificationMeta('portTo');
  @override
  late final GeneratedColumn<String> portTo = GeneratedColumn<String>(
      'port_to', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _vesselForDayMeta =
      const VerificationMeta('vesselForDay');
  @override
  late final GeneratedColumn<String> vesselForDay = GeneratedColumn<String>(
      'vessel_for_day', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _distanceNmMeta =
      const VerificationMeta('distanceNm');
  @override
  late final GeneratedColumn<double> distanceNm = GeneratedColumn<double>(
      'distance_nm', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _beaufortMorningMeta =
      const VerificationMeta('beaufortMorning');
  @override
  late final GeneratedColumn<int> beaufortMorning = GeneratedColumn<int>(
      'beaufort_morning', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _beaufortNoonMeta =
      const VerificationMeta('beaufortNoon');
  @override
  late final GeneratedColumn<int> beaufortNoon = GeneratedColumn<int>(
      'beaufort_noon', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _beaufortEveningMeta =
      const VerificationMeta('beaufortEvening');
  @override
  late final GeneratedColumn<int> beaufortEvening = GeneratedColumn<int>(
      'beaufort_evening', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _seaStateMeta =
      const VerificationMeta('seaState');
  @override
  late final GeneratedColumn<String> seaState = GeneratedColumn<String>(
      'sea_state', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _waveHeightMMeta =
      const VerificationMeta('waveHeightM');
  @override
  late final GeneratedColumn<double> waveHeightM = GeneratedColumn<double>(
      'wave_height_m', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _windDirectionMeta =
      const VerificationMeta('windDirection');
  @override
  late final GeneratedColumn<String> windDirection = GeneratedColumn<String>(
      'wind_direction', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _airTempCMeta =
      const VerificationMeta('airTempC');
  @override
  late final GeneratedColumn<double> airTempC = GeneratedColumn<double>(
      'air_temp_c', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _waterTempCMeta =
      const VerificationMeta('waterTempC');
  @override
  late final GeneratedColumn<double> waterTempC = GeneratedColumn<double>(
      'water_temp_c', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _skipperNoteMeta =
      const VerificationMeta('skipperNote');
  @override
  late final GeneratedColumn<String> skipperNote = GeneratedColumn<String>(
      'skipper_note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isCompleteMeta =
      const VerificationMeta('isComplete');
  @override
  late final GeneratedColumn<bool> isComplete = GeneratedColumn<bool>(
      'is_complete', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_complete" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        charterId,
        date,
        portFrom,
        portTo,
        vesselForDay,
        distanceNm,
        beaufortMorning,
        beaufortNoon,
        beaufortEvening,
        seaState,
        waveHeightM,
        windDirection,
        airTempC,
        waterTempC,
        sessionId,
        skipperNote,
        isComplete
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'day_logs';
  @override
  VerificationContext validateIntegrity(Insertable<DayLog> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('charter_id')) {
      context.handle(_charterIdMeta,
          charterId.isAcceptableOrUnknown(data['charter_id']!, _charterIdMeta));
    } else if (isInserting) {
      context.missing(_charterIdMeta);
    }
    if (data.containsKey('date')) {
      context.handle(
          _dateMeta, date.isAcceptableOrUnknown(data['date']!, _dateMeta));
    } else if (isInserting) {
      context.missing(_dateMeta);
    }
    if (data.containsKey('port_from')) {
      context.handle(_portFromMeta,
          portFrom.isAcceptableOrUnknown(data['port_from']!, _portFromMeta));
    }
    if (data.containsKey('port_to')) {
      context.handle(_portToMeta,
          portTo.isAcceptableOrUnknown(data['port_to']!, _portToMeta));
    }
    if (data.containsKey('vessel_for_day')) {
      context.handle(
          _vesselForDayMeta,
          vesselForDay.isAcceptableOrUnknown(
              data['vessel_for_day']!, _vesselForDayMeta));
    }
    if (data.containsKey('distance_nm')) {
      context.handle(
          _distanceNmMeta,
          distanceNm.isAcceptableOrUnknown(
              data['distance_nm']!, _distanceNmMeta));
    }
    if (data.containsKey('beaufort_morning')) {
      context.handle(
          _beaufortMorningMeta,
          beaufortMorning.isAcceptableOrUnknown(
              data['beaufort_morning']!, _beaufortMorningMeta));
    }
    if (data.containsKey('beaufort_noon')) {
      context.handle(
          _beaufortNoonMeta,
          beaufortNoon.isAcceptableOrUnknown(
              data['beaufort_noon']!, _beaufortNoonMeta));
    }
    if (data.containsKey('beaufort_evening')) {
      context.handle(
          _beaufortEveningMeta,
          beaufortEvening.isAcceptableOrUnknown(
              data['beaufort_evening']!, _beaufortEveningMeta));
    }
    if (data.containsKey('sea_state')) {
      context.handle(_seaStateMeta,
          seaState.isAcceptableOrUnknown(data['sea_state']!, _seaStateMeta));
    }
    if (data.containsKey('wave_height_m')) {
      context.handle(
          _waveHeightMMeta,
          waveHeightM.isAcceptableOrUnknown(
              data['wave_height_m']!, _waveHeightMMeta));
    }
    if (data.containsKey('wind_direction')) {
      context.handle(
          _windDirectionMeta,
          windDirection.isAcceptableOrUnknown(
              data['wind_direction']!, _windDirectionMeta));
    }
    if (data.containsKey('air_temp_c')) {
      context.handle(_airTempCMeta,
          airTempC.isAcceptableOrUnknown(data['air_temp_c']!, _airTempCMeta));
    }
    if (data.containsKey('water_temp_c')) {
      context.handle(
          _waterTempCMeta,
          waterTempC.isAcceptableOrUnknown(
              data['water_temp_c']!, _waterTempCMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('skipper_note')) {
      context.handle(
          _skipperNoteMeta,
          skipperNote.isAcceptableOrUnknown(
              data['skipper_note']!, _skipperNoteMeta));
    }
    if (data.containsKey('is_complete')) {
      context.handle(
          _isCompleteMeta,
          isComplete.isAcceptableOrUnknown(
              data['is_complete']!, _isCompleteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DayLog map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DayLog(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      charterId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}charter_id'])!,
      date: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}date'])!,
      portFrom: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}port_from']),
      portTo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}port_to']),
      vesselForDay: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}vessel_for_day']),
      distanceNm: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}distance_nm'])!,
      beaufortMorning: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}beaufort_morning']),
      beaufortNoon: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}beaufort_noon']),
      beaufortEvening: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}beaufort_evening']),
      seaState: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sea_state']),
      waveHeightM: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wave_height_m']),
      windDirection: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wind_direction']),
      airTempC: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}air_temp_c']),
      waterTempC: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}water_temp_c']),
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      skipperNote: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}skipper_note']),
      isComplete: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_complete'])!,
    );
  }

  @override
  $DayLogsTable createAlias(String alias) {
    return $DayLogsTable(attachedDatabase, alias);
  }
}

class DayLog extends DataClass implements Insertable<DayLog> {
  final int id;
  final int charterId;
  final DateTime date;
  final String? portFrom;
  final String? portTo;
  final String? vesselForDay;
  final double distanceNm;
  final int? beaufortMorning;
  final int? beaufortNoon;
  final int? beaufortEvening;
  final String? seaState;
  final double? waveHeightM;
  final String? windDirection;
  final double? airTempC;
  final double? waterTempC;
  final String? sessionId;
  final String? skipperNote;
  final bool isComplete;
  const DayLog(
      {required this.id,
      required this.charterId,
      required this.date,
      this.portFrom,
      this.portTo,
      this.vesselForDay,
      required this.distanceNm,
      this.beaufortMorning,
      this.beaufortNoon,
      this.beaufortEvening,
      this.seaState,
      this.waveHeightM,
      this.windDirection,
      this.airTempC,
      this.waterTempC,
      this.sessionId,
      this.skipperNote,
      required this.isComplete});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['charter_id'] = Variable<int>(charterId);
    map['date'] = Variable<DateTime>(date);
    if (!nullToAbsent || portFrom != null) {
      map['port_from'] = Variable<String>(portFrom);
    }
    if (!nullToAbsent || portTo != null) {
      map['port_to'] = Variable<String>(portTo);
    }
    if (!nullToAbsent || vesselForDay != null) {
      map['vessel_for_day'] = Variable<String>(vesselForDay);
    }
    map['distance_nm'] = Variable<double>(distanceNm);
    if (!nullToAbsent || beaufortMorning != null) {
      map['beaufort_morning'] = Variable<int>(beaufortMorning);
    }
    if (!nullToAbsent || beaufortNoon != null) {
      map['beaufort_noon'] = Variable<int>(beaufortNoon);
    }
    if (!nullToAbsent || beaufortEvening != null) {
      map['beaufort_evening'] = Variable<int>(beaufortEvening);
    }
    if (!nullToAbsent || seaState != null) {
      map['sea_state'] = Variable<String>(seaState);
    }
    if (!nullToAbsent || waveHeightM != null) {
      map['wave_height_m'] = Variable<double>(waveHeightM);
    }
    if (!nullToAbsent || windDirection != null) {
      map['wind_direction'] = Variable<String>(windDirection);
    }
    if (!nullToAbsent || airTempC != null) {
      map['air_temp_c'] = Variable<double>(airTempC);
    }
    if (!nullToAbsent || waterTempC != null) {
      map['water_temp_c'] = Variable<double>(waterTempC);
    }
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    if (!nullToAbsent || skipperNote != null) {
      map['skipper_note'] = Variable<String>(skipperNote);
    }
    map['is_complete'] = Variable<bool>(isComplete);
    return map;
  }

  DayLogsCompanion toCompanion(bool nullToAbsent) {
    return DayLogsCompanion(
      id: Value(id),
      charterId: Value(charterId),
      date: Value(date),
      portFrom: portFrom == null && nullToAbsent
          ? const Value.absent()
          : Value(portFrom),
      portTo:
          portTo == null && nullToAbsent ? const Value.absent() : Value(portTo),
      vesselForDay: vesselForDay == null && nullToAbsent
          ? const Value.absent()
          : Value(vesselForDay),
      distanceNm: Value(distanceNm),
      beaufortMorning: beaufortMorning == null && nullToAbsent
          ? const Value.absent()
          : Value(beaufortMorning),
      beaufortNoon: beaufortNoon == null && nullToAbsent
          ? const Value.absent()
          : Value(beaufortNoon),
      beaufortEvening: beaufortEvening == null && nullToAbsent
          ? const Value.absent()
          : Value(beaufortEvening),
      seaState: seaState == null && nullToAbsent
          ? const Value.absent()
          : Value(seaState),
      waveHeightM: waveHeightM == null && nullToAbsent
          ? const Value.absent()
          : Value(waveHeightM),
      windDirection: windDirection == null && nullToAbsent
          ? const Value.absent()
          : Value(windDirection),
      airTempC: airTempC == null && nullToAbsent
          ? const Value.absent()
          : Value(airTempC),
      waterTempC: waterTempC == null && nullToAbsent
          ? const Value.absent()
          : Value(waterTempC),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      skipperNote: skipperNote == null && nullToAbsent
          ? const Value.absent()
          : Value(skipperNote),
      isComplete: Value(isComplete),
    );
  }

  factory DayLog.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DayLog(
      id: serializer.fromJson<int>(json['id']),
      charterId: serializer.fromJson<int>(json['charterId']),
      date: serializer.fromJson<DateTime>(json['date']),
      portFrom: serializer.fromJson<String?>(json['portFrom']),
      portTo: serializer.fromJson<String?>(json['portTo']),
      vesselForDay: serializer.fromJson<String?>(json['vesselForDay']),
      distanceNm: serializer.fromJson<double>(json['distanceNm']),
      beaufortMorning: serializer.fromJson<int?>(json['beaufortMorning']),
      beaufortNoon: serializer.fromJson<int?>(json['beaufortNoon']),
      beaufortEvening: serializer.fromJson<int?>(json['beaufortEvening']),
      seaState: serializer.fromJson<String?>(json['seaState']),
      waveHeightM: serializer.fromJson<double?>(json['waveHeightM']),
      windDirection: serializer.fromJson<String?>(json['windDirection']),
      airTempC: serializer.fromJson<double?>(json['airTempC']),
      waterTempC: serializer.fromJson<double?>(json['waterTempC']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      skipperNote: serializer.fromJson<String?>(json['skipperNote']),
      isComplete: serializer.fromJson<bool>(json['isComplete']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'charterId': serializer.toJson<int>(charterId),
      'date': serializer.toJson<DateTime>(date),
      'portFrom': serializer.toJson<String?>(portFrom),
      'portTo': serializer.toJson<String?>(portTo),
      'vesselForDay': serializer.toJson<String?>(vesselForDay),
      'distanceNm': serializer.toJson<double>(distanceNm),
      'beaufortMorning': serializer.toJson<int?>(beaufortMorning),
      'beaufortNoon': serializer.toJson<int?>(beaufortNoon),
      'beaufortEvening': serializer.toJson<int?>(beaufortEvening),
      'seaState': serializer.toJson<String?>(seaState),
      'waveHeightM': serializer.toJson<double?>(waveHeightM),
      'windDirection': serializer.toJson<String?>(windDirection),
      'airTempC': serializer.toJson<double?>(airTempC),
      'waterTempC': serializer.toJson<double?>(waterTempC),
      'sessionId': serializer.toJson<String?>(sessionId),
      'skipperNote': serializer.toJson<String?>(skipperNote),
      'isComplete': serializer.toJson<bool>(isComplete),
    };
  }

  DayLog copyWith(
          {int? id,
          int? charterId,
          DateTime? date,
          Value<String?> portFrom = const Value.absent(),
          Value<String?> portTo = const Value.absent(),
          Value<String?> vesselForDay = const Value.absent(),
          double? distanceNm,
          Value<int?> beaufortMorning = const Value.absent(),
          Value<int?> beaufortNoon = const Value.absent(),
          Value<int?> beaufortEvening = const Value.absent(),
          Value<String?> seaState = const Value.absent(),
          Value<double?> waveHeightM = const Value.absent(),
          Value<String?> windDirection = const Value.absent(),
          Value<double?> airTempC = const Value.absent(),
          Value<double?> waterTempC = const Value.absent(),
          Value<String?> sessionId = const Value.absent(),
          Value<String?> skipperNote = const Value.absent(),
          bool? isComplete}) =>
      DayLog(
        id: id ?? this.id,
        charterId: charterId ?? this.charterId,
        date: date ?? this.date,
        portFrom: portFrom.present ? portFrom.value : this.portFrom,
        portTo: portTo.present ? portTo.value : this.portTo,
        vesselForDay:
            vesselForDay.present ? vesselForDay.value : this.vesselForDay,
        distanceNm: distanceNm ?? this.distanceNm,
        beaufortMorning: beaufortMorning.present
            ? beaufortMorning.value
            : this.beaufortMorning,
        beaufortNoon:
            beaufortNoon.present ? beaufortNoon.value : this.beaufortNoon,
        beaufortEvening: beaufortEvening.present
            ? beaufortEvening.value
            : this.beaufortEvening,
        seaState: seaState.present ? seaState.value : this.seaState,
        waveHeightM: waveHeightM.present ? waveHeightM.value : this.waveHeightM,
        windDirection:
            windDirection.present ? windDirection.value : this.windDirection,
        airTempC: airTempC.present ? airTempC.value : this.airTempC,
        waterTempC: waterTempC.present ? waterTempC.value : this.waterTempC,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        skipperNote: skipperNote.present ? skipperNote.value : this.skipperNote,
        isComplete: isComplete ?? this.isComplete,
      );
  DayLog copyWithCompanion(DayLogsCompanion data) {
    return DayLog(
      id: data.id.present ? data.id.value : this.id,
      charterId: data.charterId.present ? data.charterId.value : this.charterId,
      date: data.date.present ? data.date.value : this.date,
      portFrom: data.portFrom.present ? data.portFrom.value : this.portFrom,
      portTo: data.portTo.present ? data.portTo.value : this.portTo,
      vesselForDay: data.vesselForDay.present
          ? data.vesselForDay.value
          : this.vesselForDay,
      distanceNm:
          data.distanceNm.present ? data.distanceNm.value : this.distanceNm,
      beaufortMorning: data.beaufortMorning.present
          ? data.beaufortMorning.value
          : this.beaufortMorning,
      beaufortNoon: data.beaufortNoon.present
          ? data.beaufortNoon.value
          : this.beaufortNoon,
      beaufortEvening: data.beaufortEvening.present
          ? data.beaufortEvening.value
          : this.beaufortEvening,
      seaState: data.seaState.present ? data.seaState.value : this.seaState,
      waveHeightM:
          data.waveHeightM.present ? data.waveHeightM.value : this.waveHeightM,
      windDirection: data.windDirection.present
          ? data.windDirection.value
          : this.windDirection,
      airTempC: data.airTempC.present ? data.airTempC.value : this.airTempC,
      waterTempC:
          data.waterTempC.present ? data.waterTempC.value : this.waterTempC,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      skipperNote:
          data.skipperNote.present ? data.skipperNote.value : this.skipperNote,
      isComplete:
          data.isComplete.present ? data.isComplete.value : this.isComplete,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DayLog(')
          ..write('id: $id, ')
          ..write('charterId: $charterId, ')
          ..write('date: $date, ')
          ..write('portFrom: $portFrom, ')
          ..write('portTo: $portTo, ')
          ..write('vesselForDay: $vesselForDay, ')
          ..write('distanceNm: $distanceNm, ')
          ..write('beaufortMorning: $beaufortMorning, ')
          ..write('beaufortNoon: $beaufortNoon, ')
          ..write('beaufortEvening: $beaufortEvening, ')
          ..write('seaState: $seaState, ')
          ..write('waveHeightM: $waveHeightM, ')
          ..write('windDirection: $windDirection, ')
          ..write('airTempC: $airTempC, ')
          ..write('waterTempC: $waterTempC, ')
          ..write('sessionId: $sessionId, ')
          ..write('skipperNote: $skipperNote, ')
          ..write('isComplete: $isComplete')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      charterId,
      date,
      portFrom,
      portTo,
      vesselForDay,
      distanceNm,
      beaufortMorning,
      beaufortNoon,
      beaufortEvening,
      seaState,
      waveHeightM,
      windDirection,
      airTempC,
      waterTempC,
      sessionId,
      skipperNote,
      isComplete);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DayLog &&
          other.id == this.id &&
          other.charterId == this.charterId &&
          other.date == this.date &&
          other.portFrom == this.portFrom &&
          other.portTo == this.portTo &&
          other.vesselForDay == this.vesselForDay &&
          other.distanceNm == this.distanceNm &&
          other.beaufortMorning == this.beaufortMorning &&
          other.beaufortNoon == this.beaufortNoon &&
          other.beaufortEvening == this.beaufortEvening &&
          other.seaState == this.seaState &&
          other.waveHeightM == this.waveHeightM &&
          other.windDirection == this.windDirection &&
          other.airTempC == this.airTempC &&
          other.waterTempC == this.waterTempC &&
          other.sessionId == this.sessionId &&
          other.skipperNote == this.skipperNote &&
          other.isComplete == this.isComplete);
}

class DayLogsCompanion extends UpdateCompanion<DayLog> {
  final Value<int> id;
  final Value<int> charterId;
  final Value<DateTime> date;
  final Value<String?> portFrom;
  final Value<String?> portTo;
  final Value<String?> vesselForDay;
  final Value<double> distanceNm;
  final Value<int?> beaufortMorning;
  final Value<int?> beaufortNoon;
  final Value<int?> beaufortEvening;
  final Value<String?> seaState;
  final Value<double?> waveHeightM;
  final Value<String?> windDirection;
  final Value<double?> airTempC;
  final Value<double?> waterTempC;
  final Value<String?> sessionId;
  final Value<String?> skipperNote;
  final Value<bool> isComplete;
  const DayLogsCompanion({
    this.id = const Value.absent(),
    this.charterId = const Value.absent(),
    this.date = const Value.absent(),
    this.portFrom = const Value.absent(),
    this.portTo = const Value.absent(),
    this.vesselForDay = const Value.absent(),
    this.distanceNm = const Value.absent(),
    this.beaufortMorning = const Value.absent(),
    this.beaufortNoon = const Value.absent(),
    this.beaufortEvening = const Value.absent(),
    this.seaState = const Value.absent(),
    this.waveHeightM = const Value.absent(),
    this.windDirection = const Value.absent(),
    this.airTempC = const Value.absent(),
    this.waterTempC = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.skipperNote = const Value.absent(),
    this.isComplete = const Value.absent(),
  });
  DayLogsCompanion.insert({
    this.id = const Value.absent(),
    required int charterId,
    required DateTime date,
    this.portFrom = const Value.absent(),
    this.portTo = const Value.absent(),
    this.vesselForDay = const Value.absent(),
    this.distanceNm = const Value.absent(),
    this.beaufortMorning = const Value.absent(),
    this.beaufortNoon = const Value.absent(),
    this.beaufortEvening = const Value.absent(),
    this.seaState = const Value.absent(),
    this.waveHeightM = const Value.absent(),
    this.windDirection = const Value.absent(),
    this.airTempC = const Value.absent(),
    this.waterTempC = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.skipperNote = const Value.absent(),
    this.isComplete = const Value.absent(),
  })  : charterId = Value(charterId),
        date = Value(date);
  static Insertable<DayLog> custom({
    Expression<int>? id,
    Expression<int>? charterId,
    Expression<DateTime>? date,
    Expression<String>? portFrom,
    Expression<String>? portTo,
    Expression<String>? vesselForDay,
    Expression<double>? distanceNm,
    Expression<int>? beaufortMorning,
    Expression<int>? beaufortNoon,
    Expression<int>? beaufortEvening,
    Expression<String>? seaState,
    Expression<double>? waveHeightM,
    Expression<String>? windDirection,
    Expression<double>? airTempC,
    Expression<double>? waterTempC,
    Expression<String>? sessionId,
    Expression<String>? skipperNote,
    Expression<bool>? isComplete,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (charterId != null) 'charter_id': charterId,
      if (date != null) 'date': date,
      if (portFrom != null) 'port_from': portFrom,
      if (portTo != null) 'port_to': portTo,
      if (vesselForDay != null) 'vessel_for_day': vesselForDay,
      if (distanceNm != null) 'distance_nm': distanceNm,
      if (beaufortMorning != null) 'beaufort_morning': beaufortMorning,
      if (beaufortNoon != null) 'beaufort_noon': beaufortNoon,
      if (beaufortEvening != null) 'beaufort_evening': beaufortEvening,
      if (seaState != null) 'sea_state': seaState,
      if (waveHeightM != null) 'wave_height_m': waveHeightM,
      if (windDirection != null) 'wind_direction': windDirection,
      if (airTempC != null) 'air_temp_c': airTempC,
      if (waterTempC != null) 'water_temp_c': waterTempC,
      if (sessionId != null) 'session_id': sessionId,
      if (skipperNote != null) 'skipper_note': skipperNote,
      if (isComplete != null) 'is_complete': isComplete,
    });
  }

  DayLogsCompanion copyWith(
      {Value<int>? id,
      Value<int>? charterId,
      Value<DateTime>? date,
      Value<String?>? portFrom,
      Value<String?>? portTo,
      Value<String?>? vesselForDay,
      Value<double>? distanceNm,
      Value<int?>? beaufortMorning,
      Value<int?>? beaufortNoon,
      Value<int?>? beaufortEvening,
      Value<String?>? seaState,
      Value<double?>? waveHeightM,
      Value<String?>? windDirection,
      Value<double?>? airTempC,
      Value<double?>? waterTempC,
      Value<String?>? sessionId,
      Value<String?>? skipperNote,
      Value<bool>? isComplete}) {
    return DayLogsCompanion(
      id: id ?? this.id,
      charterId: charterId ?? this.charterId,
      date: date ?? this.date,
      portFrom: portFrom ?? this.portFrom,
      portTo: portTo ?? this.portTo,
      vesselForDay: vesselForDay ?? this.vesselForDay,
      distanceNm: distanceNm ?? this.distanceNm,
      beaufortMorning: beaufortMorning ?? this.beaufortMorning,
      beaufortNoon: beaufortNoon ?? this.beaufortNoon,
      beaufortEvening: beaufortEvening ?? this.beaufortEvening,
      seaState: seaState ?? this.seaState,
      waveHeightM: waveHeightM ?? this.waveHeightM,
      windDirection: windDirection ?? this.windDirection,
      airTempC: airTempC ?? this.airTempC,
      waterTempC: waterTempC ?? this.waterTempC,
      sessionId: sessionId ?? this.sessionId,
      skipperNote: skipperNote ?? this.skipperNote,
      isComplete: isComplete ?? this.isComplete,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (charterId.present) {
      map['charter_id'] = Variable<int>(charterId.value);
    }
    if (date.present) {
      map['date'] = Variable<DateTime>(date.value);
    }
    if (portFrom.present) {
      map['port_from'] = Variable<String>(portFrom.value);
    }
    if (portTo.present) {
      map['port_to'] = Variable<String>(portTo.value);
    }
    if (vesselForDay.present) {
      map['vessel_for_day'] = Variable<String>(vesselForDay.value);
    }
    if (distanceNm.present) {
      map['distance_nm'] = Variable<double>(distanceNm.value);
    }
    if (beaufortMorning.present) {
      map['beaufort_morning'] = Variable<int>(beaufortMorning.value);
    }
    if (beaufortNoon.present) {
      map['beaufort_noon'] = Variable<int>(beaufortNoon.value);
    }
    if (beaufortEvening.present) {
      map['beaufort_evening'] = Variable<int>(beaufortEvening.value);
    }
    if (seaState.present) {
      map['sea_state'] = Variable<String>(seaState.value);
    }
    if (waveHeightM.present) {
      map['wave_height_m'] = Variable<double>(waveHeightM.value);
    }
    if (windDirection.present) {
      map['wind_direction'] = Variable<String>(windDirection.value);
    }
    if (airTempC.present) {
      map['air_temp_c'] = Variable<double>(airTempC.value);
    }
    if (waterTempC.present) {
      map['water_temp_c'] = Variable<double>(waterTempC.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (skipperNote.present) {
      map['skipper_note'] = Variable<String>(skipperNote.value);
    }
    if (isComplete.present) {
      map['is_complete'] = Variable<bool>(isComplete.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DayLogsCompanion(')
          ..write('id: $id, ')
          ..write('charterId: $charterId, ')
          ..write('date: $date, ')
          ..write('portFrom: $portFrom, ')
          ..write('portTo: $portTo, ')
          ..write('vesselForDay: $vesselForDay, ')
          ..write('distanceNm: $distanceNm, ')
          ..write('beaufortMorning: $beaufortMorning, ')
          ..write('beaufortNoon: $beaufortNoon, ')
          ..write('beaufortEvening: $beaufortEvening, ')
          ..write('seaState: $seaState, ')
          ..write('waveHeightM: $waveHeightM, ')
          ..write('windDirection: $windDirection, ')
          ..write('airTempC: $airTempC, ')
          ..write('waterTempC: $waterTempC, ')
          ..write('sessionId: $sessionId, ')
          ..write('skipperNote: $skipperNote, ')
          ..write('isComplete: $isComplete')
          ..write(')'))
        .toString();
  }
}

class $LogbookEntriesTable extends LogbookEntries
    with TableInfo<$LogbookEntriesTable, LogbookEntry> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LogbookEntriesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _dayLogIdMeta =
      const VerificationMeta('dayLogId');
  @override
  late final GeneratedColumn<int> dayLogId = GeneratedColumn<int>(
      'day_log_id', aliasedName, true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES day_logs (id)'));
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _timestampMeta =
      const VerificationMeta('timestamp');
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
      'timestamp', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _latitudeMeta =
      const VerificationMeta('latitude');
  @override
  late final GeneratedColumn<double> latitude = GeneratedColumn<double>(
      'latitude', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _longitudeMeta =
      const VerificationMeta('longitude');
  @override
  late final GeneratedColumn<double> longitude = GeneratedColumn<double>(
      'longitude', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _sogMeta = const VerificationMeta('sog');
  @override
  late final GeneratedColumn<double> sog = GeneratedColumn<double>(
      'sog', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cogMeta = const VerificationMeta('cog');
  @override
  late final GeneratedColumn<double> cog = GeneratedColumn<double>(
      'cog', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _headingMeta =
      const VerificationMeta('heading');
  @override
  late final GeneratedColumn<double> heading = GeneratedColumn<double>(
      'heading', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _windSpeedMeta =
      const VerificationMeta('windSpeed');
  @override
  late final GeneratedColumn<double> windSpeed = GeneratedColumn<double>(
      'wind_speed', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _windDirectionMeta =
      const VerificationMeta('windDirection');
  @override
  late final GeneratedColumn<double> windDirection = GeneratedColumn<double>(
      'wind_direction', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _waveHeightMeta =
      const VerificationMeta('waveHeight');
  @override
  late final GeneratedColumn<double> waveHeight = GeneratedColumn<double>(
      'wave_height', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _airPressureMeta =
      const VerificationMeta('airPressure');
  @override
  late final GeneratedColumn<double> airPressure = GeneratedColumn<double>(
      'air_pressure', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _airTempMeta =
      const VerificationMeta('airTemp');
  @override
  late final GeneratedColumn<double> airTemp = GeneratedColumn<double>(
      'air_temp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _waterTempMeta =
      const VerificationMeta('waterTemp');
  @override
  late final GeneratedColumn<double> waterTemp = GeneratedColumn<double>(
      'water_temp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _engineHoursMeta =
      const VerificationMeta('engineHours');
  @override
  late final GeneratedColumn<double> engineHours = GeneratedColumn<double>(
      'engine_hours', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fuelConsumedMeta =
      const VerificationMeta('fuelConsumed');
  @override
  late final GeneratedColumn<double> fuelConsumed = GeneratedColumn<double>(
      'fuel_consumed', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _skipperNameMeta =
      const VerificationMeta('skipperName');
  @override
  late final GeneratedColumn<String> skipperName = GeneratedColumn<String>(
      'skipper_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _crewNamesMeta =
      const VerificationMeta('crewNames');
  @override
  late final GeneratedColumn<String> crewNames = GeneratedColumn<String>(
      'crew_names', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _skipperNoteMeta =
      const VerificationMeta('skipperNote');
  @override
  late final GeneratedColumn<String> skipperNote = GeneratedColumn<String>(
      'skipper_note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isAutoEntryMeta =
      const VerificationMeta('isAutoEntry');
  @override
  late final GeneratedColumn<bool> isAutoEntry = GeneratedColumn<bool>(
      'is_auto_entry', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("is_auto_entry" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dayLogId,
        sessionId,
        timestamp,
        latitude,
        longitude,
        sog,
        cog,
        heading,
        windSpeed,
        windDirection,
        waveHeight,
        airPressure,
        airTemp,
        waterTemp,
        engineHours,
        fuelConsumed,
        skipperName,
        crewNames,
        skipperNote,
        isAutoEntry
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'logbook_entries';
  @override
  VerificationContext validateIntegrity(Insertable<LogbookEntry> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('day_log_id')) {
      context.handle(_dayLogIdMeta,
          dayLogId.isAcceptableOrUnknown(data['day_log_id']!, _dayLogIdMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('timestamp')) {
      context.handle(_timestampMeta,
          timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta));
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    if (data.containsKey('latitude')) {
      context.handle(_latitudeMeta,
          latitude.isAcceptableOrUnknown(data['latitude']!, _latitudeMeta));
    }
    if (data.containsKey('longitude')) {
      context.handle(_longitudeMeta,
          longitude.isAcceptableOrUnknown(data['longitude']!, _longitudeMeta));
    }
    if (data.containsKey('sog')) {
      context.handle(
          _sogMeta, sog.isAcceptableOrUnknown(data['sog']!, _sogMeta));
    }
    if (data.containsKey('cog')) {
      context.handle(
          _cogMeta, cog.isAcceptableOrUnknown(data['cog']!, _cogMeta));
    }
    if (data.containsKey('heading')) {
      context.handle(_headingMeta,
          heading.isAcceptableOrUnknown(data['heading']!, _headingMeta));
    }
    if (data.containsKey('wind_speed')) {
      context.handle(_windSpeedMeta,
          windSpeed.isAcceptableOrUnknown(data['wind_speed']!, _windSpeedMeta));
    }
    if (data.containsKey('wind_direction')) {
      context.handle(
          _windDirectionMeta,
          windDirection.isAcceptableOrUnknown(
              data['wind_direction']!, _windDirectionMeta));
    }
    if (data.containsKey('wave_height')) {
      context.handle(
          _waveHeightMeta,
          waveHeight.isAcceptableOrUnknown(
              data['wave_height']!, _waveHeightMeta));
    }
    if (data.containsKey('air_pressure')) {
      context.handle(
          _airPressureMeta,
          airPressure.isAcceptableOrUnknown(
              data['air_pressure']!, _airPressureMeta));
    }
    if (data.containsKey('air_temp')) {
      context.handle(_airTempMeta,
          airTemp.isAcceptableOrUnknown(data['air_temp']!, _airTempMeta));
    }
    if (data.containsKey('water_temp')) {
      context.handle(_waterTempMeta,
          waterTemp.isAcceptableOrUnknown(data['water_temp']!, _waterTempMeta));
    }
    if (data.containsKey('engine_hours')) {
      context.handle(
          _engineHoursMeta,
          engineHours.isAcceptableOrUnknown(
              data['engine_hours']!, _engineHoursMeta));
    }
    if (data.containsKey('fuel_consumed')) {
      context.handle(
          _fuelConsumedMeta,
          fuelConsumed.isAcceptableOrUnknown(
              data['fuel_consumed']!, _fuelConsumedMeta));
    }
    if (data.containsKey('skipper_name')) {
      context.handle(
          _skipperNameMeta,
          skipperName.isAcceptableOrUnknown(
              data['skipper_name']!, _skipperNameMeta));
    }
    if (data.containsKey('crew_names')) {
      context.handle(_crewNamesMeta,
          crewNames.isAcceptableOrUnknown(data['crew_names']!, _crewNamesMeta));
    }
    if (data.containsKey('skipper_note')) {
      context.handle(
          _skipperNoteMeta,
          skipperNote.isAcceptableOrUnknown(
              data['skipper_note']!, _skipperNoteMeta));
    }
    if (data.containsKey('is_auto_entry')) {
      context.handle(
          _isAutoEntryMeta,
          isAutoEntry.isAcceptableOrUnknown(
              data['is_auto_entry']!, _isAutoEntryMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  LogbookEntry map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return LogbookEntry(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      dayLogId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}day_log_id']),
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      timestamp: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}timestamp'])!,
      latitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}latitude']),
      longitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}longitude']),
      sog: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}sog']),
      cog: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}cog']),
      heading: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}heading']),
      windSpeed: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wind_speed']),
      windDirection: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wind_direction']),
      waveHeight: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wave_height']),
      airPressure: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}air_pressure']),
      airTemp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}air_temp']),
      waterTemp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}water_temp']),
      engineHours: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}engine_hours']),
      fuelConsumed: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}fuel_consumed']),
      skipperName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}skipper_name']),
      crewNames: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crew_names']),
      skipperNote: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}skipper_note']),
      isAutoEntry: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_auto_entry'])!,
    );
  }

  @override
  $LogbookEntriesTable createAlias(String alias) {
    return $LogbookEntriesTable(attachedDatabase, alias);
  }
}

class LogbookEntry extends DataClass implements Insertable<LogbookEntry> {
  final int id;
  final int? dayLogId;
  final String? sessionId;
  final DateTime timestamp;
  final double? latitude;
  final double? longitude;
  final double? sog;
  final double? cog;
  final double? heading;
  final double? windSpeed;
  final double? windDirection;
  final double? waveHeight;
  final double? airPressure;
  final double? airTemp;
  final double? waterTemp;
  final double? engineHours;
  final double? fuelConsumed;
  final String? skipperName;
  final String? crewNames;
  final String? skipperNote;
  final bool isAutoEntry;
  const LogbookEntry(
      {required this.id,
      this.dayLogId,
      this.sessionId,
      required this.timestamp,
      this.latitude,
      this.longitude,
      this.sog,
      this.cog,
      this.heading,
      this.windSpeed,
      this.windDirection,
      this.waveHeight,
      this.airPressure,
      this.airTemp,
      this.waterTemp,
      this.engineHours,
      this.fuelConsumed,
      this.skipperName,
      this.crewNames,
      this.skipperNote,
      required this.isAutoEntry});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    if (!nullToAbsent || dayLogId != null) {
      map['day_log_id'] = Variable<int>(dayLogId);
    }
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    map['timestamp'] = Variable<DateTime>(timestamp);
    if (!nullToAbsent || latitude != null) {
      map['latitude'] = Variable<double>(latitude);
    }
    if (!nullToAbsent || longitude != null) {
      map['longitude'] = Variable<double>(longitude);
    }
    if (!nullToAbsent || sog != null) {
      map['sog'] = Variable<double>(sog);
    }
    if (!nullToAbsent || cog != null) {
      map['cog'] = Variable<double>(cog);
    }
    if (!nullToAbsent || heading != null) {
      map['heading'] = Variable<double>(heading);
    }
    if (!nullToAbsent || windSpeed != null) {
      map['wind_speed'] = Variable<double>(windSpeed);
    }
    if (!nullToAbsent || windDirection != null) {
      map['wind_direction'] = Variable<double>(windDirection);
    }
    if (!nullToAbsent || waveHeight != null) {
      map['wave_height'] = Variable<double>(waveHeight);
    }
    if (!nullToAbsent || airPressure != null) {
      map['air_pressure'] = Variable<double>(airPressure);
    }
    if (!nullToAbsent || airTemp != null) {
      map['air_temp'] = Variable<double>(airTemp);
    }
    if (!nullToAbsent || waterTemp != null) {
      map['water_temp'] = Variable<double>(waterTemp);
    }
    if (!nullToAbsent || engineHours != null) {
      map['engine_hours'] = Variable<double>(engineHours);
    }
    if (!nullToAbsent || fuelConsumed != null) {
      map['fuel_consumed'] = Variable<double>(fuelConsumed);
    }
    if (!nullToAbsent || skipperName != null) {
      map['skipper_name'] = Variable<String>(skipperName);
    }
    if (!nullToAbsent || crewNames != null) {
      map['crew_names'] = Variable<String>(crewNames);
    }
    if (!nullToAbsent || skipperNote != null) {
      map['skipper_note'] = Variable<String>(skipperNote);
    }
    map['is_auto_entry'] = Variable<bool>(isAutoEntry);
    return map;
  }

  LogbookEntriesCompanion toCompanion(bool nullToAbsent) {
    return LogbookEntriesCompanion(
      id: Value(id),
      dayLogId: dayLogId == null && nullToAbsent
          ? const Value.absent()
          : Value(dayLogId),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      timestamp: Value(timestamp),
      latitude: latitude == null && nullToAbsent
          ? const Value.absent()
          : Value(latitude),
      longitude: longitude == null && nullToAbsent
          ? const Value.absent()
          : Value(longitude),
      sog: sog == null && nullToAbsent ? const Value.absent() : Value(sog),
      cog: cog == null && nullToAbsent ? const Value.absent() : Value(cog),
      heading: heading == null && nullToAbsent
          ? const Value.absent()
          : Value(heading),
      windSpeed: windSpeed == null && nullToAbsent
          ? const Value.absent()
          : Value(windSpeed),
      windDirection: windDirection == null && nullToAbsent
          ? const Value.absent()
          : Value(windDirection),
      waveHeight: waveHeight == null && nullToAbsent
          ? const Value.absent()
          : Value(waveHeight),
      airPressure: airPressure == null && nullToAbsent
          ? const Value.absent()
          : Value(airPressure),
      airTemp: airTemp == null && nullToAbsent
          ? const Value.absent()
          : Value(airTemp),
      waterTemp: waterTemp == null && nullToAbsent
          ? const Value.absent()
          : Value(waterTemp),
      engineHours: engineHours == null && nullToAbsent
          ? const Value.absent()
          : Value(engineHours),
      fuelConsumed: fuelConsumed == null && nullToAbsent
          ? const Value.absent()
          : Value(fuelConsumed),
      skipperName: skipperName == null && nullToAbsent
          ? const Value.absent()
          : Value(skipperName),
      crewNames: crewNames == null && nullToAbsent
          ? const Value.absent()
          : Value(crewNames),
      skipperNote: skipperNote == null && nullToAbsent
          ? const Value.absent()
          : Value(skipperNote),
      isAutoEntry: Value(isAutoEntry),
    );
  }

  factory LogbookEntry.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return LogbookEntry(
      id: serializer.fromJson<int>(json['id']),
      dayLogId: serializer.fromJson<int?>(json['dayLogId']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
      latitude: serializer.fromJson<double?>(json['latitude']),
      longitude: serializer.fromJson<double?>(json['longitude']),
      sog: serializer.fromJson<double?>(json['sog']),
      cog: serializer.fromJson<double?>(json['cog']),
      heading: serializer.fromJson<double?>(json['heading']),
      windSpeed: serializer.fromJson<double?>(json['windSpeed']),
      windDirection: serializer.fromJson<double?>(json['windDirection']),
      waveHeight: serializer.fromJson<double?>(json['waveHeight']),
      airPressure: serializer.fromJson<double?>(json['airPressure']),
      airTemp: serializer.fromJson<double?>(json['airTemp']),
      waterTemp: serializer.fromJson<double?>(json['waterTemp']),
      engineHours: serializer.fromJson<double?>(json['engineHours']),
      fuelConsumed: serializer.fromJson<double?>(json['fuelConsumed']),
      skipperName: serializer.fromJson<String?>(json['skipperName']),
      crewNames: serializer.fromJson<String?>(json['crewNames']),
      skipperNote: serializer.fromJson<String?>(json['skipperNote']),
      isAutoEntry: serializer.fromJson<bool>(json['isAutoEntry']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'dayLogId': serializer.toJson<int?>(dayLogId),
      'sessionId': serializer.toJson<String?>(sessionId),
      'timestamp': serializer.toJson<DateTime>(timestamp),
      'latitude': serializer.toJson<double?>(latitude),
      'longitude': serializer.toJson<double?>(longitude),
      'sog': serializer.toJson<double?>(sog),
      'cog': serializer.toJson<double?>(cog),
      'heading': serializer.toJson<double?>(heading),
      'windSpeed': serializer.toJson<double?>(windSpeed),
      'windDirection': serializer.toJson<double?>(windDirection),
      'waveHeight': serializer.toJson<double?>(waveHeight),
      'airPressure': serializer.toJson<double?>(airPressure),
      'airTemp': serializer.toJson<double?>(airTemp),
      'waterTemp': serializer.toJson<double?>(waterTemp),
      'engineHours': serializer.toJson<double?>(engineHours),
      'fuelConsumed': serializer.toJson<double?>(fuelConsumed),
      'skipperName': serializer.toJson<String?>(skipperName),
      'crewNames': serializer.toJson<String?>(crewNames),
      'skipperNote': serializer.toJson<String?>(skipperNote),
      'isAutoEntry': serializer.toJson<bool>(isAutoEntry),
    };
  }

  LogbookEntry copyWith(
          {int? id,
          Value<int?> dayLogId = const Value.absent(),
          Value<String?> sessionId = const Value.absent(),
          DateTime? timestamp,
          Value<double?> latitude = const Value.absent(),
          Value<double?> longitude = const Value.absent(),
          Value<double?> sog = const Value.absent(),
          Value<double?> cog = const Value.absent(),
          Value<double?> heading = const Value.absent(),
          Value<double?> windSpeed = const Value.absent(),
          Value<double?> windDirection = const Value.absent(),
          Value<double?> waveHeight = const Value.absent(),
          Value<double?> airPressure = const Value.absent(),
          Value<double?> airTemp = const Value.absent(),
          Value<double?> waterTemp = const Value.absent(),
          Value<double?> engineHours = const Value.absent(),
          Value<double?> fuelConsumed = const Value.absent(),
          Value<String?> skipperName = const Value.absent(),
          Value<String?> crewNames = const Value.absent(),
          Value<String?> skipperNote = const Value.absent(),
          bool? isAutoEntry}) =>
      LogbookEntry(
        id: id ?? this.id,
        dayLogId: dayLogId.present ? dayLogId.value : this.dayLogId,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        timestamp: timestamp ?? this.timestamp,
        latitude: latitude.present ? latitude.value : this.latitude,
        longitude: longitude.present ? longitude.value : this.longitude,
        sog: sog.present ? sog.value : this.sog,
        cog: cog.present ? cog.value : this.cog,
        heading: heading.present ? heading.value : this.heading,
        windSpeed: windSpeed.present ? windSpeed.value : this.windSpeed,
        windDirection:
            windDirection.present ? windDirection.value : this.windDirection,
        waveHeight: waveHeight.present ? waveHeight.value : this.waveHeight,
        airPressure: airPressure.present ? airPressure.value : this.airPressure,
        airTemp: airTemp.present ? airTemp.value : this.airTemp,
        waterTemp: waterTemp.present ? waterTemp.value : this.waterTemp,
        engineHours: engineHours.present ? engineHours.value : this.engineHours,
        fuelConsumed:
            fuelConsumed.present ? fuelConsumed.value : this.fuelConsumed,
        skipperName: skipperName.present ? skipperName.value : this.skipperName,
        crewNames: crewNames.present ? crewNames.value : this.crewNames,
        skipperNote: skipperNote.present ? skipperNote.value : this.skipperNote,
        isAutoEntry: isAutoEntry ?? this.isAutoEntry,
      );
  LogbookEntry copyWithCompanion(LogbookEntriesCompanion data) {
    return LogbookEntry(
      id: data.id.present ? data.id.value : this.id,
      dayLogId: data.dayLogId.present ? data.dayLogId.value : this.dayLogId,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
      latitude: data.latitude.present ? data.latitude.value : this.latitude,
      longitude: data.longitude.present ? data.longitude.value : this.longitude,
      sog: data.sog.present ? data.sog.value : this.sog,
      cog: data.cog.present ? data.cog.value : this.cog,
      heading: data.heading.present ? data.heading.value : this.heading,
      windSpeed: data.windSpeed.present ? data.windSpeed.value : this.windSpeed,
      windDirection: data.windDirection.present
          ? data.windDirection.value
          : this.windDirection,
      waveHeight:
          data.waveHeight.present ? data.waveHeight.value : this.waveHeight,
      airPressure:
          data.airPressure.present ? data.airPressure.value : this.airPressure,
      airTemp: data.airTemp.present ? data.airTemp.value : this.airTemp,
      waterTemp: data.waterTemp.present ? data.waterTemp.value : this.waterTemp,
      engineHours:
          data.engineHours.present ? data.engineHours.value : this.engineHours,
      fuelConsumed: data.fuelConsumed.present
          ? data.fuelConsumed.value
          : this.fuelConsumed,
      skipperName:
          data.skipperName.present ? data.skipperName.value : this.skipperName,
      crewNames: data.crewNames.present ? data.crewNames.value : this.crewNames,
      skipperNote:
          data.skipperNote.present ? data.skipperNote.value : this.skipperNote,
      isAutoEntry:
          data.isAutoEntry.present ? data.isAutoEntry.value : this.isAutoEntry,
    );
  }

  @override
  String toString() {
    return (StringBuffer('LogbookEntry(')
          ..write('id: $id, ')
          ..write('dayLogId: $dayLogId, ')
          ..write('sessionId: $sessionId, ')
          ..write('timestamp: $timestamp, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('sog: $sog, ')
          ..write('cog: $cog, ')
          ..write('heading: $heading, ')
          ..write('windSpeed: $windSpeed, ')
          ..write('windDirection: $windDirection, ')
          ..write('waveHeight: $waveHeight, ')
          ..write('airPressure: $airPressure, ')
          ..write('airTemp: $airTemp, ')
          ..write('waterTemp: $waterTemp, ')
          ..write('engineHours: $engineHours, ')
          ..write('fuelConsumed: $fuelConsumed, ')
          ..write('skipperName: $skipperName, ')
          ..write('crewNames: $crewNames, ')
          ..write('skipperNote: $skipperNote, ')
          ..write('isAutoEntry: $isAutoEntry')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        dayLogId,
        sessionId,
        timestamp,
        latitude,
        longitude,
        sog,
        cog,
        heading,
        windSpeed,
        windDirection,
        waveHeight,
        airPressure,
        airTemp,
        waterTemp,
        engineHours,
        fuelConsumed,
        skipperName,
        crewNames,
        skipperNote,
        isAutoEntry
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is LogbookEntry &&
          other.id == this.id &&
          other.dayLogId == this.dayLogId &&
          other.sessionId == this.sessionId &&
          other.timestamp == this.timestamp &&
          other.latitude == this.latitude &&
          other.longitude == this.longitude &&
          other.sog == this.sog &&
          other.cog == this.cog &&
          other.heading == this.heading &&
          other.windSpeed == this.windSpeed &&
          other.windDirection == this.windDirection &&
          other.waveHeight == this.waveHeight &&
          other.airPressure == this.airPressure &&
          other.airTemp == this.airTemp &&
          other.waterTemp == this.waterTemp &&
          other.engineHours == this.engineHours &&
          other.fuelConsumed == this.fuelConsumed &&
          other.skipperName == this.skipperName &&
          other.crewNames == this.crewNames &&
          other.skipperNote == this.skipperNote &&
          other.isAutoEntry == this.isAutoEntry);
}

class LogbookEntriesCompanion extends UpdateCompanion<LogbookEntry> {
  final Value<int> id;
  final Value<int?> dayLogId;
  final Value<String?> sessionId;
  final Value<DateTime> timestamp;
  final Value<double?> latitude;
  final Value<double?> longitude;
  final Value<double?> sog;
  final Value<double?> cog;
  final Value<double?> heading;
  final Value<double?> windSpeed;
  final Value<double?> windDirection;
  final Value<double?> waveHeight;
  final Value<double?> airPressure;
  final Value<double?> airTemp;
  final Value<double?> waterTemp;
  final Value<double?> engineHours;
  final Value<double?> fuelConsumed;
  final Value<String?> skipperName;
  final Value<String?> crewNames;
  final Value<String?> skipperNote;
  final Value<bool> isAutoEntry;
  const LogbookEntriesCompanion({
    this.id = const Value.absent(),
    this.dayLogId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.timestamp = const Value.absent(),
    this.latitude = const Value.absent(),
    this.longitude = const Value.absent(),
    this.sog = const Value.absent(),
    this.cog = const Value.absent(),
    this.heading = const Value.absent(),
    this.windSpeed = const Value.absent(),
    this.windDirection = const Value.absent(),
    this.waveHeight = const Value.absent(),
    this.airPressure = const Value.absent(),
    this.airTemp = const Value.absent(),
    this.waterTemp = const Value.absent(),
    this.engineHours = const Value.absent(),
    this.fuelConsumed = const Value.absent(),
    this.skipperName = const Value.absent(),
    this.crewNames = const Value.absent(),
    this.skipperNote = const Value.absent(),
    this.isAutoEntry = const Value.absent(),
  });
  LogbookEntriesCompanion.insert({
    this.id = const Value.absent(),
    this.dayLogId = const Value.absent(),
    this.sessionId = const Value.absent(),
    required DateTime timestamp,
    this.latitude = const Value.absent(),
    this.longitude = const Value.absent(),
    this.sog = const Value.absent(),
    this.cog = const Value.absent(),
    this.heading = const Value.absent(),
    this.windSpeed = const Value.absent(),
    this.windDirection = const Value.absent(),
    this.waveHeight = const Value.absent(),
    this.airPressure = const Value.absent(),
    this.airTemp = const Value.absent(),
    this.waterTemp = const Value.absent(),
    this.engineHours = const Value.absent(),
    this.fuelConsumed = const Value.absent(),
    this.skipperName = const Value.absent(),
    this.crewNames = const Value.absent(),
    this.skipperNote = const Value.absent(),
    this.isAutoEntry = const Value.absent(),
  }) : timestamp = Value(timestamp);
  static Insertable<LogbookEntry> custom({
    Expression<int>? id,
    Expression<int>? dayLogId,
    Expression<String>? sessionId,
    Expression<DateTime>? timestamp,
    Expression<double>? latitude,
    Expression<double>? longitude,
    Expression<double>? sog,
    Expression<double>? cog,
    Expression<double>? heading,
    Expression<double>? windSpeed,
    Expression<double>? windDirection,
    Expression<double>? waveHeight,
    Expression<double>? airPressure,
    Expression<double>? airTemp,
    Expression<double>? waterTemp,
    Expression<double>? engineHours,
    Expression<double>? fuelConsumed,
    Expression<String>? skipperName,
    Expression<String>? crewNames,
    Expression<String>? skipperNote,
    Expression<bool>? isAutoEntry,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dayLogId != null) 'day_log_id': dayLogId,
      if (sessionId != null) 'session_id': sessionId,
      if (timestamp != null) 'timestamp': timestamp,
      if (latitude != null) 'latitude': latitude,
      if (longitude != null) 'longitude': longitude,
      if (sog != null) 'sog': sog,
      if (cog != null) 'cog': cog,
      if (heading != null) 'heading': heading,
      if (windSpeed != null) 'wind_speed': windSpeed,
      if (windDirection != null) 'wind_direction': windDirection,
      if (waveHeight != null) 'wave_height': waveHeight,
      if (airPressure != null) 'air_pressure': airPressure,
      if (airTemp != null) 'air_temp': airTemp,
      if (waterTemp != null) 'water_temp': waterTemp,
      if (engineHours != null) 'engine_hours': engineHours,
      if (fuelConsumed != null) 'fuel_consumed': fuelConsumed,
      if (skipperName != null) 'skipper_name': skipperName,
      if (crewNames != null) 'crew_names': crewNames,
      if (skipperNote != null) 'skipper_note': skipperNote,
      if (isAutoEntry != null) 'is_auto_entry': isAutoEntry,
    });
  }

  LogbookEntriesCompanion copyWith(
      {Value<int>? id,
      Value<int?>? dayLogId,
      Value<String?>? sessionId,
      Value<DateTime>? timestamp,
      Value<double?>? latitude,
      Value<double?>? longitude,
      Value<double?>? sog,
      Value<double?>? cog,
      Value<double?>? heading,
      Value<double?>? windSpeed,
      Value<double?>? windDirection,
      Value<double?>? waveHeight,
      Value<double?>? airPressure,
      Value<double?>? airTemp,
      Value<double?>? waterTemp,
      Value<double?>? engineHours,
      Value<double?>? fuelConsumed,
      Value<String?>? skipperName,
      Value<String?>? crewNames,
      Value<String?>? skipperNote,
      Value<bool>? isAutoEntry}) {
    return LogbookEntriesCompanion(
      id: id ?? this.id,
      dayLogId: dayLogId ?? this.dayLogId,
      sessionId: sessionId ?? this.sessionId,
      timestamp: timestamp ?? this.timestamp,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      sog: sog ?? this.sog,
      cog: cog ?? this.cog,
      heading: heading ?? this.heading,
      windSpeed: windSpeed ?? this.windSpeed,
      windDirection: windDirection ?? this.windDirection,
      waveHeight: waveHeight ?? this.waveHeight,
      airPressure: airPressure ?? this.airPressure,
      airTemp: airTemp ?? this.airTemp,
      waterTemp: waterTemp ?? this.waterTemp,
      engineHours: engineHours ?? this.engineHours,
      fuelConsumed: fuelConsumed ?? this.fuelConsumed,
      skipperName: skipperName ?? this.skipperName,
      crewNames: crewNames ?? this.crewNames,
      skipperNote: skipperNote ?? this.skipperNote,
      isAutoEntry: isAutoEntry ?? this.isAutoEntry,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dayLogId.present) {
      map['day_log_id'] = Variable<int>(dayLogId.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    if (latitude.present) {
      map['latitude'] = Variable<double>(latitude.value);
    }
    if (longitude.present) {
      map['longitude'] = Variable<double>(longitude.value);
    }
    if (sog.present) {
      map['sog'] = Variable<double>(sog.value);
    }
    if (cog.present) {
      map['cog'] = Variable<double>(cog.value);
    }
    if (heading.present) {
      map['heading'] = Variable<double>(heading.value);
    }
    if (windSpeed.present) {
      map['wind_speed'] = Variable<double>(windSpeed.value);
    }
    if (windDirection.present) {
      map['wind_direction'] = Variable<double>(windDirection.value);
    }
    if (waveHeight.present) {
      map['wave_height'] = Variable<double>(waveHeight.value);
    }
    if (airPressure.present) {
      map['air_pressure'] = Variable<double>(airPressure.value);
    }
    if (airTemp.present) {
      map['air_temp'] = Variable<double>(airTemp.value);
    }
    if (waterTemp.present) {
      map['water_temp'] = Variable<double>(waterTemp.value);
    }
    if (engineHours.present) {
      map['engine_hours'] = Variable<double>(engineHours.value);
    }
    if (fuelConsumed.present) {
      map['fuel_consumed'] = Variable<double>(fuelConsumed.value);
    }
    if (skipperName.present) {
      map['skipper_name'] = Variable<String>(skipperName.value);
    }
    if (crewNames.present) {
      map['crew_names'] = Variable<String>(crewNames.value);
    }
    if (skipperNote.present) {
      map['skipper_note'] = Variable<String>(skipperNote.value);
    }
    if (isAutoEntry.present) {
      map['is_auto_entry'] = Variable<bool>(isAutoEntry.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LogbookEntriesCompanion(')
          ..write('id: $id, ')
          ..write('dayLogId: $dayLogId, ')
          ..write('sessionId: $sessionId, ')
          ..write('timestamp: $timestamp, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('sog: $sog, ')
          ..write('cog: $cog, ')
          ..write('heading: $heading, ')
          ..write('windSpeed: $windSpeed, ')
          ..write('windDirection: $windDirection, ')
          ..write('waveHeight: $waveHeight, ')
          ..write('airPressure: $airPressure, ')
          ..write('airTemp: $airTemp, ')
          ..write('waterTemp: $waterTemp, ')
          ..write('engineHours: $engineHours, ')
          ..write('fuelConsumed: $fuelConsumed, ')
          ..write('skipperName: $skipperName, ')
          ..write('crewNames: $crewNames, ')
          ..write('skipperNote: $skipperNote, ')
          ..write('isAutoEntry: $isAutoEntry')
          ..write(')'))
        .toString();
  }
}

class $TrackPointsTable extends TrackPoints
    with TableInfo<$TrackPointsTable, TrackPoint> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TrackPointsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _timestampMeta =
      const VerificationMeta('timestamp');
  @override
  late final GeneratedColumn<DateTime> timestamp = GeneratedColumn<DateTime>(
      'timestamp', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _latitudeMeta =
      const VerificationMeta('latitude');
  @override
  late final GeneratedColumn<double> latitude = GeneratedColumn<double>(
      'latitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _longitudeMeta =
      const VerificationMeta('longitude');
  @override
  late final GeneratedColumn<double> longitude = GeneratedColumn<double>(
      'longitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _altitudeMeta =
      const VerificationMeta('altitude');
  @override
  late final GeneratedColumn<double> altitude = GeneratedColumn<double>(
      'altitude', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _speedMeta = const VerificationMeta('speed');
  @override
  late final GeneratedColumn<double> speed = GeneratedColumn<double>(
      'speed', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _courseMeta = const VerificationMeta('course');
  @override
  late final GeneratedColumn<double> course = GeneratedColumn<double>(
      'course', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _accuracyMeta =
      const VerificationMeta('accuracy');
  @override
  late final GeneratedColumn<double> accuracy = GeneratedColumn<double>(
      'accuracy', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        sessionId,
        timestamp,
        latitude,
        longitude,
        altitude,
        speed,
        course,
        accuracy
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'track_points';
  @override
  VerificationContext validateIntegrity(Insertable<TrackPoint> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('timestamp')) {
      context.handle(_timestampMeta,
          timestamp.isAcceptableOrUnknown(data['timestamp']!, _timestampMeta));
    } else if (isInserting) {
      context.missing(_timestampMeta);
    }
    if (data.containsKey('latitude')) {
      context.handle(_latitudeMeta,
          latitude.isAcceptableOrUnknown(data['latitude']!, _latitudeMeta));
    } else if (isInserting) {
      context.missing(_latitudeMeta);
    }
    if (data.containsKey('longitude')) {
      context.handle(_longitudeMeta,
          longitude.isAcceptableOrUnknown(data['longitude']!, _longitudeMeta));
    } else if (isInserting) {
      context.missing(_longitudeMeta);
    }
    if (data.containsKey('altitude')) {
      context.handle(_altitudeMeta,
          altitude.isAcceptableOrUnknown(data['altitude']!, _altitudeMeta));
    }
    if (data.containsKey('speed')) {
      context.handle(
          _speedMeta, speed.isAcceptableOrUnknown(data['speed']!, _speedMeta));
    }
    if (data.containsKey('course')) {
      context.handle(_courseMeta,
          course.isAcceptableOrUnknown(data['course']!, _courseMeta));
    }
    if (data.containsKey('accuracy')) {
      context.handle(_accuracyMeta,
          accuracy.isAcceptableOrUnknown(data['accuracy']!, _accuracyMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TrackPoint map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TrackPoint(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      timestamp: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}timestamp'])!,
      latitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}latitude'])!,
      longitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}longitude'])!,
      altitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}altitude']),
      speed: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}speed']),
      course: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}course']),
      accuracy: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}accuracy']),
    );
  }

  @override
  $TrackPointsTable createAlias(String alias) {
    return $TrackPointsTable(attachedDatabase, alias);
  }
}

class TrackPoint extends DataClass implements Insertable<TrackPoint> {
  final int id;
  final String? sessionId;
  final DateTime timestamp;
  final double latitude;
  final double longitude;
  final double? altitude;
  final double? speed;
  final double? course;
  final double? accuracy;
  const TrackPoint(
      {required this.id,
      this.sessionId,
      required this.timestamp,
      required this.latitude,
      required this.longitude,
      this.altitude,
      this.speed,
      this.course,
      this.accuracy});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    map['timestamp'] = Variable<DateTime>(timestamp);
    map['latitude'] = Variable<double>(latitude);
    map['longitude'] = Variable<double>(longitude);
    if (!nullToAbsent || altitude != null) {
      map['altitude'] = Variable<double>(altitude);
    }
    if (!nullToAbsent || speed != null) {
      map['speed'] = Variable<double>(speed);
    }
    if (!nullToAbsent || course != null) {
      map['course'] = Variable<double>(course);
    }
    if (!nullToAbsent || accuracy != null) {
      map['accuracy'] = Variable<double>(accuracy);
    }
    return map;
  }

  TrackPointsCompanion toCompanion(bool nullToAbsent) {
    return TrackPointsCompanion(
      id: Value(id),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      timestamp: Value(timestamp),
      latitude: Value(latitude),
      longitude: Value(longitude),
      altitude: altitude == null && nullToAbsent
          ? const Value.absent()
          : Value(altitude),
      speed:
          speed == null && nullToAbsent ? const Value.absent() : Value(speed),
      course:
          course == null && nullToAbsent ? const Value.absent() : Value(course),
      accuracy: accuracy == null && nullToAbsent
          ? const Value.absent()
          : Value(accuracy),
    );
  }

  factory TrackPoint.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TrackPoint(
      id: serializer.fromJson<int>(json['id']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      timestamp: serializer.fromJson<DateTime>(json['timestamp']),
      latitude: serializer.fromJson<double>(json['latitude']),
      longitude: serializer.fromJson<double>(json['longitude']),
      altitude: serializer.fromJson<double?>(json['altitude']),
      speed: serializer.fromJson<double?>(json['speed']),
      course: serializer.fromJson<double?>(json['course']),
      accuracy: serializer.fromJson<double?>(json['accuracy']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'sessionId': serializer.toJson<String?>(sessionId),
      'timestamp': serializer.toJson<DateTime>(timestamp),
      'latitude': serializer.toJson<double>(latitude),
      'longitude': serializer.toJson<double>(longitude),
      'altitude': serializer.toJson<double?>(altitude),
      'speed': serializer.toJson<double?>(speed),
      'course': serializer.toJson<double?>(course),
      'accuracy': serializer.toJson<double?>(accuracy),
    };
  }

  TrackPoint copyWith(
          {int? id,
          Value<String?> sessionId = const Value.absent(),
          DateTime? timestamp,
          double? latitude,
          double? longitude,
          Value<double?> altitude = const Value.absent(),
          Value<double?> speed = const Value.absent(),
          Value<double?> course = const Value.absent(),
          Value<double?> accuracy = const Value.absent()}) =>
      TrackPoint(
        id: id ?? this.id,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        timestamp: timestamp ?? this.timestamp,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        altitude: altitude.present ? altitude.value : this.altitude,
        speed: speed.present ? speed.value : this.speed,
        course: course.present ? course.value : this.course,
        accuracy: accuracy.present ? accuracy.value : this.accuracy,
      );
  TrackPoint copyWithCompanion(TrackPointsCompanion data) {
    return TrackPoint(
      id: data.id.present ? data.id.value : this.id,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      timestamp: data.timestamp.present ? data.timestamp.value : this.timestamp,
      latitude: data.latitude.present ? data.latitude.value : this.latitude,
      longitude: data.longitude.present ? data.longitude.value : this.longitude,
      altitude: data.altitude.present ? data.altitude.value : this.altitude,
      speed: data.speed.present ? data.speed.value : this.speed,
      course: data.course.present ? data.course.value : this.course,
      accuracy: data.accuracy.present ? data.accuracy.value : this.accuracy,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TrackPoint(')
          ..write('id: $id, ')
          ..write('sessionId: $sessionId, ')
          ..write('timestamp: $timestamp, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('altitude: $altitude, ')
          ..write('speed: $speed, ')
          ..write('course: $course, ')
          ..write('accuracy: $accuracy')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sessionId, timestamp, latitude, longitude,
      altitude, speed, course, accuracy);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TrackPoint &&
          other.id == this.id &&
          other.sessionId == this.sessionId &&
          other.timestamp == this.timestamp &&
          other.latitude == this.latitude &&
          other.longitude == this.longitude &&
          other.altitude == this.altitude &&
          other.speed == this.speed &&
          other.course == this.course &&
          other.accuracy == this.accuracy);
}

class TrackPointsCompanion extends UpdateCompanion<TrackPoint> {
  final Value<int> id;
  final Value<String?> sessionId;
  final Value<DateTime> timestamp;
  final Value<double> latitude;
  final Value<double> longitude;
  final Value<double?> altitude;
  final Value<double?> speed;
  final Value<double?> course;
  final Value<double?> accuracy;
  const TrackPointsCompanion({
    this.id = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.timestamp = const Value.absent(),
    this.latitude = const Value.absent(),
    this.longitude = const Value.absent(),
    this.altitude = const Value.absent(),
    this.speed = const Value.absent(),
    this.course = const Value.absent(),
    this.accuracy = const Value.absent(),
  });
  TrackPointsCompanion.insert({
    this.id = const Value.absent(),
    this.sessionId = const Value.absent(),
    required DateTime timestamp,
    required double latitude,
    required double longitude,
    this.altitude = const Value.absent(),
    this.speed = const Value.absent(),
    this.course = const Value.absent(),
    this.accuracy = const Value.absent(),
  })  : timestamp = Value(timestamp),
        latitude = Value(latitude),
        longitude = Value(longitude);
  static Insertable<TrackPoint> custom({
    Expression<int>? id,
    Expression<String>? sessionId,
    Expression<DateTime>? timestamp,
    Expression<double>? latitude,
    Expression<double>? longitude,
    Expression<double>? altitude,
    Expression<double>? speed,
    Expression<double>? course,
    Expression<double>? accuracy,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sessionId != null) 'session_id': sessionId,
      if (timestamp != null) 'timestamp': timestamp,
      if (latitude != null) 'latitude': latitude,
      if (longitude != null) 'longitude': longitude,
      if (altitude != null) 'altitude': altitude,
      if (speed != null) 'speed': speed,
      if (course != null) 'course': course,
      if (accuracy != null) 'accuracy': accuracy,
    });
  }

  TrackPointsCompanion copyWith(
      {Value<int>? id,
      Value<String?>? sessionId,
      Value<DateTime>? timestamp,
      Value<double>? latitude,
      Value<double>? longitude,
      Value<double?>? altitude,
      Value<double?>? speed,
      Value<double?>? course,
      Value<double?>? accuracy}) {
    return TrackPointsCompanion(
      id: id ?? this.id,
      sessionId: sessionId ?? this.sessionId,
      timestamp: timestamp ?? this.timestamp,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      altitude: altitude ?? this.altitude,
      speed: speed ?? this.speed,
      course: course ?? this.course,
      accuracy: accuracy ?? this.accuracy,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (timestamp.present) {
      map['timestamp'] = Variable<DateTime>(timestamp.value);
    }
    if (latitude.present) {
      map['latitude'] = Variable<double>(latitude.value);
    }
    if (longitude.present) {
      map['longitude'] = Variable<double>(longitude.value);
    }
    if (altitude.present) {
      map['altitude'] = Variable<double>(altitude.value);
    }
    if (speed.present) {
      map['speed'] = Variable<double>(speed.value);
    }
    if (course.present) {
      map['course'] = Variable<double>(course.value);
    }
    if (accuracy.present) {
      map['accuracy'] = Variable<double>(accuracy.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TrackPointsCompanion(')
          ..write('id: $id, ')
          ..write('sessionId: $sessionId, ')
          ..write('timestamp: $timestamp, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('altitude: $altitude, ')
          ..write('speed: $speed, ')
          ..write('course: $course, ')
          ..write('accuracy: $accuracy')
          ..write(')'))
        .toString();
  }
}

class $SailingSessionsTable extends SailingSessions
    with TableInfo<$SailingSessionsTable, SailingSession> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SailingSessionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: true,
      defaultConstraints: GeneratedColumn.constraintIsAlways('UNIQUE'));
  static const VerificationMeta _dayLogIdMeta =
      const VerificationMeta('dayLogId');
  @override
  late final GeneratedColumn<int> dayLogId = GeneratedColumn<int>(
      'day_log_id', aliasedName, true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES day_logs (id)'));
  static const VerificationMeta _startTimeMeta =
      const VerificationMeta('startTime');
  @override
  late final GeneratedColumn<DateTime> startTime = GeneratedColumn<DateTime>(
      'start_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _endTimeMeta =
      const VerificationMeta('endTime');
  @override
  late final GeneratedColumn<DateTime> endTime = GeneratedColumn<DateTime>(
      'end_time', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _totalDistanceNmMeta =
      const VerificationMeta('totalDistanceNm');
  @override
  late final GeneratedColumn<double> totalDistanceNm = GeneratedColumn<double>(
      'total_distance_nm', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _maxSpeedKnotsMeta =
      const VerificationMeta('maxSpeedKnots');
  @override
  late final GeneratedColumn<double> maxSpeedKnots = GeneratedColumn<double>(
      'max_speed_knots', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _avgSpeedKnotsMeta =
      const VerificationMeta('avgSpeedKnots');
  @override
  late final GeneratedColumn<double> avgSpeedKnots = GeneratedColumn<double>(
      'avg_speed_knots', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0.0));
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        sessionId,
        dayLogId,
        startTime,
        endTime,
        name,
        totalDistanceNm,
        maxSpeedKnots,
        avgSpeedKnots,
        isActive
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sailing_sessions';
  @override
  VerificationContext validateIntegrity(Insertable<SailingSession> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    } else if (isInserting) {
      context.missing(_sessionIdMeta);
    }
    if (data.containsKey('day_log_id')) {
      context.handle(_dayLogIdMeta,
          dayLogId.isAcceptableOrUnknown(data['day_log_id']!, _dayLogIdMeta));
    }
    if (data.containsKey('start_time')) {
      context.handle(_startTimeMeta,
          startTime.isAcceptableOrUnknown(data['start_time']!, _startTimeMeta));
    } else if (isInserting) {
      context.missing(_startTimeMeta);
    }
    if (data.containsKey('end_time')) {
      context.handle(_endTimeMeta,
          endTime.isAcceptableOrUnknown(data['end_time']!, _endTimeMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    }
    if (data.containsKey('total_distance_nm')) {
      context.handle(
          _totalDistanceNmMeta,
          totalDistanceNm.isAcceptableOrUnknown(
              data['total_distance_nm']!, _totalDistanceNmMeta));
    }
    if (data.containsKey('max_speed_knots')) {
      context.handle(
          _maxSpeedKnotsMeta,
          maxSpeedKnots.isAcceptableOrUnknown(
              data['max_speed_knots']!, _maxSpeedKnotsMeta));
    }
    if (data.containsKey('avg_speed_knots')) {
      context.handle(
          _avgSpeedKnotsMeta,
          avgSpeedKnots.isAcceptableOrUnknown(
              data['avg_speed_knots']!, _avgSpeedKnotsMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SailingSession map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SailingSession(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id'])!,
      dayLogId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}day_log_id']),
      startTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}start_time'])!,
      endTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}end_time']),
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name']),
      totalDistanceNm: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}total_distance_nm'])!,
      maxSpeedKnots: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}max_speed_knots'])!,
      avgSpeedKnots: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}avg_speed_knots'])!,
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
    );
  }

  @override
  $SailingSessionsTable createAlias(String alias) {
    return $SailingSessionsTable(attachedDatabase, alias);
  }
}

class SailingSession extends DataClass implements Insertable<SailingSession> {
  final int id;
  final String sessionId;
  final int? dayLogId;
  final DateTime startTime;
  final DateTime? endTime;
  final String? name;
  final double totalDistanceNm;
  final double maxSpeedKnots;
  final double avgSpeedKnots;
  final bool isActive;
  const SailingSession(
      {required this.id,
      required this.sessionId,
      this.dayLogId,
      required this.startTime,
      this.endTime,
      this.name,
      required this.totalDistanceNm,
      required this.maxSpeedKnots,
      required this.avgSpeedKnots,
      required this.isActive});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['session_id'] = Variable<String>(sessionId);
    if (!nullToAbsent || dayLogId != null) {
      map['day_log_id'] = Variable<int>(dayLogId);
    }
    map['start_time'] = Variable<DateTime>(startTime);
    if (!nullToAbsent || endTime != null) {
      map['end_time'] = Variable<DateTime>(endTime);
    }
    if (!nullToAbsent || name != null) {
      map['name'] = Variable<String>(name);
    }
    map['total_distance_nm'] = Variable<double>(totalDistanceNm);
    map['max_speed_knots'] = Variable<double>(maxSpeedKnots);
    map['avg_speed_knots'] = Variable<double>(avgSpeedKnots);
    map['is_active'] = Variable<bool>(isActive);
    return map;
  }

  SailingSessionsCompanion toCompanion(bool nullToAbsent) {
    return SailingSessionsCompanion(
      id: Value(id),
      sessionId: Value(sessionId),
      dayLogId: dayLogId == null && nullToAbsent
          ? const Value.absent()
          : Value(dayLogId),
      startTime: Value(startTime),
      endTime: endTime == null && nullToAbsent
          ? const Value.absent()
          : Value(endTime),
      name: name == null && nullToAbsent ? const Value.absent() : Value(name),
      totalDistanceNm: Value(totalDistanceNm),
      maxSpeedKnots: Value(maxSpeedKnots),
      avgSpeedKnots: Value(avgSpeedKnots),
      isActive: Value(isActive),
    );
  }

  factory SailingSession.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SailingSession(
      id: serializer.fromJson<int>(json['id']),
      sessionId: serializer.fromJson<String>(json['sessionId']),
      dayLogId: serializer.fromJson<int?>(json['dayLogId']),
      startTime: serializer.fromJson<DateTime>(json['startTime']),
      endTime: serializer.fromJson<DateTime?>(json['endTime']),
      name: serializer.fromJson<String?>(json['name']),
      totalDistanceNm: serializer.fromJson<double>(json['totalDistanceNm']),
      maxSpeedKnots: serializer.fromJson<double>(json['maxSpeedKnots']),
      avgSpeedKnots: serializer.fromJson<double>(json['avgSpeedKnots']),
      isActive: serializer.fromJson<bool>(json['isActive']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'sessionId': serializer.toJson<String>(sessionId),
      'dayLogId': serializer.toJson<int?>(dayLogId),
      'startTime': serializer.toJson<DateTime>(startTime),
      'endTime': serializer.toJson<DateTime?>(endTime),
      'name': serializer.toJson<String?>(name),
      'totalDistanceNm': serializer.toJson<double>(totalDistanceNm),
      'maxSpeedKnots': serializer.toJson<double>(maxSpeedKnots),
      'avgSpeedKnots': serializer.toJson<double>(avgSpeedKnots),
      'isActive': serializer.toJson<bool>(isActive),
    };
  }

  SailingSession copyWith(
          {int? id,
          String? sessionId,
          Value<int?> dayLogId = const Value.absent(),
          DateTime? startTime,
          Value<DateTime?> endTime = const Value.absent(),
          Value<String?> name = const Value.absent(),
          double? totalDistanceNm,
          double? maxSpeedKnots,
          double? avgSpeedKnots,
          bool? isActive}) =>
      SailingSession(
        id: id ?? this.id,
        sessionId: sessionId ?? this.sessionId,
        dayLogId: dayLogId.present ? dayLogId.value : this.dayLogId,
        startTime: startTime ?? this.startTime,
        endTime: endTime.present ? endTime.value : this.endTime,
        name: name.present ? name.value : this.name,
        totalDistanceNm: totalDistanceNm ?? this.totalDistanceNm,
        maxSpeedKnots: maxSpeedKnots ?? this.maxSpeedKnots,
        avgSpeedKnots: avgSpeedKnots ?? this.avgSpeedKnots,
        isActive: isActive ?? this.isActive,
      );
  SailingSession copyWithCompanion(SailingSessionsCompanion data) {
    return SailingSession(
      id: data.id.present ? data.id.value : this.id,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      dayLogId: data.dayLogId.present ? data.dayLogId.value : this.dayLogId,
      startTime: data.startTime.present ? data.startTime.value : this.startTime,
      endTime: data.endTime.present ? data.endTime.value : this.endTime,
      name: data.name.present ? data.name.value : this.name,
      totalDistanceNm: data.totalDistanceNm.present
          ? data.totalDistanceNm.value
          : this.totalDistanceNm,
      maxSpeedKnots: data.maxSpeedKnots.present
          ? data.maxSpeedKnots.value
          : this.maxSpeedKnots,
      avgSpeedKnots: data.avgSpeedKnots.present
          ? data.avgSpeedKnots.value
          : this.avgSpeedKnots,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SailingSession(')
          ..write('id: $id, ')
          ..write('sessionId: $sessionId, ')
          ..write('dayLogId: $dayLogId, ')
          ..write('startTime: $startTime, ')
          ..write('endTime: $endTime, ')
          ..write('name: $name, ')
          ..write('totalDistanceNm: $totalDistanceNm, ')
          ..write('maxSpeedKnots: $maxSpeedKnots, ')
          ..write('avgSpeedKnots: $avgSpeedKnots, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sessionId, dayLogId, startTime, endTime,
      name, totalDistanceNm, maxSpeedKnots, avgSpeedKnots, isActive);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SailingSession &&
          other.id == this.id &&
          other.sessionId == this.sessionId &&
          other.dayLogId == this.dayLogId &&
          other.startTime == this.startTime &&
          other.endTime == this.endTime &&
          other.name == this.name &&
          other.totalDistanceNm == this.totalDistanceNm &&
          other.maxSpeedKnots == this.maxSpeedKnots &&
          other.avgSpeedKnots == this.avgSpeedKnots &&
          other.isActive == this.isActive);
}

class SailingSessionsCompanion extends UpdateCompanion<SailingSession> {
  final Value<int> id;
  final Value<String> sessionId;
  final Value<int?> dayLogId;
  final Value<DateTime> startTime;
  final Value<DateTime?> endTime;
  final Value<String?> name;
  final Value<double> totalDistanceNm;
  final Value<double> maxSpeedKnots;
  final Value<double> avgSpeedKnots;
  final Value<bool> isActive;
  const SailingSessionsCompanion({
    this.id = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.dayLogId = const Value.absent(),
    this.startTime = const Value.absent(),
    this.endTime = const Value.absent(),
    this.name = const Value.absent(),
    this.totalDistanceNm = const Value.absent(),
    this.maxSpeedKnots = const Value.absent(),
    this.avgSpeedKnots = const Value.absent(),
    this.isActive = const Value.absent(),
  });
  SailingSessionsCompanion.insert({
    this.id = const Value.absent(),
    required String sessionId,
    this.dayLogId = const Value.absent(),
    required DateTime startTime,
    this.endTime = const Value.absent(),
    this.name = const Value.absent(),
    this.totalDistanceNm = const Value.absent(),
    this.maxSpeedKnots = const Value.absent(),
    this.avgSpeedKnots = const Value.absent(),
    this.isActive = const Value.absent(),
  })  : sessionId = Value(sessionId),
        startTime = Value(startTime);
  static Insertable<SailingSession> custom({
    Expression<int>? id,
    Expression<String>? sessionId,
    Expression<int>? dayLogId,
    Expression<DateTime>? startTime,
    Expression<DateTime>? endTime,
    Expression<String>? name,
    Expression<double>? totalDistanceNm,
    Expression<double>? maxSpeedKnots,
    Expression<double>? avgSpeedKnots,
    Expression<bool>? isActive,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sessionId != null) 'session_id': sessionId,
      if (dayLogId != null) 'day_log_id': dayLogId,
      if (startTime != null) 'start_time': startTime,
      if (endTime != null) 'end_time': endTime,
      if (name != null) 'name': name,
      if (totalDistanceNm != null) 'total_distance_nm': totalDistanceNm,
      if (maxSpeedKnots != null) 'max_speed_knots': maxSpeedKnots,
      if (avgSpeedKnots != null) 'avg_speed_knots': avgSpeedKnots,
      if (isActive != null) 'is_active': isActive,
    });
  }

  SailingSessionsCompanion copyWith(
      {Value<int>? id,
      Value<String>? sessionId,
      Value<int?>? dayLogId,
      Value<DateTime>? startTime,
      Value<DateTime?>? endTime,
      Value<String?>? name,
      Value<double>? totalDistanceNm,
      Value<double>? maxSpeedKnots,
      Value<double>? avgSpeedKnots,
      Value<bool>? isActive}) {
    return SailingSessionsCompanion(
      id: id ?? this.id,
      sessionId: sessionId ?? this.sessionId,
      dayLogId: dayLogId ?? this.dayLogId,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      name: name ?? this.name,
      totalDistanceNm: totalDistanceNm ?? this.totalDistanceNm,
      maxSpeedKnots: maxSpeedKnots ?? this.maxSpeedKnots,
      avgSpeedKnots: avgSpeedKnots ?? this.avgSpeedKnots,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (dayLogId.present) {
      map['day_log_id'] = Variable<int>(dayLogId.value);
    }
    if (startTime.present) {
      map['start_time'] = Variable<DateTime>(startTime.value);
    }
    if (endTime.present) {
      map['end_time'] = Variable<DateTime>(endTime.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (totalDistanceNm.present) {
      map['total_distance_nm'] = Variable<double>(totalDistanceNm.value);
    }
    if (maxSpeedKnots.present) {
      map['max_speed_knots'] = Variable<double>(maxSpeedKnots.value);
    }
    if (avgSpeedKnots.present) {
      map['avg_speed_knots'] = Variable<double>(avgSpeedKnots.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SailingSessionsCompanion(')
          ..write('id: $id, ')
          ..write('sessionId: $sessionId, ')
          ..write('dayLogId: $dayLogId, ')
          ..write('startTime: $startTime, ')
          ..write('endTime: $endTime, ')
          ..write('name: $name, ')
          ..write('totalDistanceNm: $totalDistanceNm, ')
          ..write('maxSpeedKnots: $maxSpeedKnots, ')
          ..write('avgSpeedKnots: $avgSpeedKnots, ')
          ..write('isActive: $isActive')
          ..write(')'))
        .toString();
  }
}

class $WaypointsTable extends Waypoints
    with TableInfo<$WaypointsTable, Waypoint> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WaypointsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _latitudeMeta =
      const VerificationMeta('latitude');
  @override
  late final GeneratedColumn<double> latitude = GeneratedColumn<double>(
      'latitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _longitudeMeta =
      const VerificationMeta('longitude');
  @override
  late final GeneratedColumn<double> longitude = GeneratedColumn<double>(
      'longitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _isFavoriteMeta =
      const VerificationMeta('isFavorite');
  @override
  late final GeneratedColumn<bool> isFavorite = GeneratedColumn<bool>(
      'is_favorite', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_favorite" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns =>
      [id, name, latitude, longitude, description, type, createdAt, isFavorite];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'waypoints';
  @override
  VerificationContext validateIntegrity(Insertable<Waypoint> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('latitude')) {
      context.handle(_latitudeMeta,
          latitude.isAcceptableOrUnknown(data['latitude']!, _latitudeMeta));
    } else if (isInserting) {
      context.missing(_latitudeMeta);
    }
    if (data.containsKey('longitude')) {
      context.handle(_longitudeMeta,
          longitude.isAcceptableOrUnknown(data['longitude']!, _longitudeMeta));
    } else if (isInserting) {
      context.missing(_longitudeMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('is_favorite')) {
      context.handle(
          _isFavoriteMeta,
          isFavorite.isAcceptableOrUnknown(
              data['is_favorite']!, _isFavoriteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Waypoint map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Waypoint(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      latitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}latitude'])!,
      longitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}longitude'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      isFavorite: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_favorite'])!,
    );
  }

  @override
  $WaypointsTable createAlias(String alias) {
    return $WaypointsTable(attachedDatabase, alias);
  }
}

class Waypoint extends DataClass implements Insertable<Waypoint> {
  final int id;
  final String name;
  final double latitude;
  final double longitude;
  final String? description;
  final String? type;
  final DateTime createdAt;
  final bool isFavorite;
  const Waypoint(
      {required this.id,
      required this.name,
      required this.latitude,
      required this.longitude,
      this.description,
      this.type,
      required this.createdAt,
      required this.isFavorite});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['name'] = Variable<String>(name);
    map['latitude'] = Variable<double>(latitude);
    map['longitude'] = Variable<double>(longitude);
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || type != null) {
      map['type'] = Variable<String>(type);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    map['is_favorite'] = Variable<bool>(isFavorite);
    return map;
  }

  WaypointsCompanion toCompanion(bool nullToAbsent) {
    return WaypointsCompanion(
      id: Value(id),
      name: Value(name),
      latitude: Value(latitude),
      longitude: Value(longitude),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      type: type == null && nullToAbsent ? const Value.absent() : Value(type),
      createdAt: Value(createdAt),
      isFavorite: Value(isFavorite),
    );
  }

  factory Waypoint.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Waypoint(
      id: serializer.fromJson<int>(json['id']),
      name: serializer.fromJson<String>(json['name']),
      latitude: serializer.fromJson<double>(json['latitude']),
      longitude: serializer.fromJson<double>(json['longitude']),
      description: serializer.fromJson<String?>(json['description']),
      type: serializer.fromJson<String?>(json['type']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      isFavorite: serializer.fromJson<bool>(json['isFavorite']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'name': serializer.toJson<String>(name),
      'latitude': serializer.toJson<double>(latitude),
      'longitude': serializer.toJson<double>(longitude),
      'description': serializer.toJson<String?>(description),
      'type': serializer.toJson<String?>(type),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'isFavorite': serializer.toJson<bool>(isFavorite),
    };
  }

  Waypoint copyWith(
          {int? id,
          String? name,
          double? latitude,
          double? longitude,
          Value<String?> description = const Value.absent(),
          Value<String?> type = const Value.absent(),
          DateTime? createdAt,
          bool? isFavorite}) =>
      Waypoint(
        id: id ?? this.id,
        name: name ?? this.name,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        description: description.present ? description.value : this.description,
        type: type.present ? type.value : this.type,
        createdAt: createdAt ?? this.createdAt,
        isFavorite: isFavorite ?? this.isFavorite,
      );
  Waypoint copyWithCompanion(WaypointsCompanion data) {
    return Waypoint(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
      latitude: data.latitude.present ? data.latitude.value : this.latitude,
      longitude: data.longitude.present ? data.longitude.value : this.longitude,
      description:
          data.description.present ? data.description.value : this.description,
      type: data.type.present ? data.type.value : this.type,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      isFavorite:
          data.isFavorite.present ? data.isFavorite.value : this.isFavorite,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Waypoint(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('description: $description, ')
          ..write('type: $type, ')
          ..write('createdAt: $createdAt, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, name, latitude, longitude, description, type, createdAt, isFavorite);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Waypoint &&
          other.id == this.id &&
          other.name == this.name &&
          other.latitude == this.latitude &&
          other.longitude == this.longitude &&
          other.description == this.description &&
          other.type == this.type &&
          other.createdAt == this.createdAt &&
          other.isFavorite == this.isFavorite);
}

class WaypointsCompanion extends UpdateCompanion<Waypoint> {
  final Value<int> id;
  final Value<String> name;
  final Value<double> latitude;
  final Value<double> longitude;
  final Value<String?> description;
  final Value<String?> type;
  final Value<DateTime> createdAt;
  final Value<bool> isFavorite;
  const WaypointsCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.latitude = const Value.absent(),
    this.longitude = const Value.absent(),
    this.description = const Value.absent(),
    this.type = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.isFavorite = const Value.absent(),
  });
  WaypointsCompanion.insert({
    this.id = const Value.absent(),
    required String name,
    required double latitude,
    required double longitude,
    this.description = const Value.absent(),
    this.type = const Value.absent(),
    required DateTime createdAt,
    this.isFavorite = const Value.absent(),
  })  : name = Value(name),
        latitude = Value(latitude),
        longitude = Value(longitude),
        createdAt = Value(createdAt);
  static Insertable<Waypoint> custom({
    Expression<int>? id,
    Expression<String>? name,
    Expression<double>? latitude,
    Expression<double>? longitude,
    Expression<String>? description,
    Expression<String>? type,
    Expression<DateTime>? createdAt,
    Expression<bool>? isFavorite,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (latitude != null) 'latitude': latitude,
      if (longitude != null) 'longitude': longitude,
      if (description != null) 'description': description,
      if (type != null) 'type': type,
      if (createdAt != null) 'created_at': createdAt,
      if (isFavorite != null) 'is_favorite': isFavorite,
    });
  }

  WaypointsCompanion copyWith(
      {Value<int>? id,
      Value<String>? name,
      Value<double>? latitude,
      Value<double>? longitude,
      Value<String?>? description,
      Value<String?>? type,
      Value<DateTime>? createdAt,
      Value<bool>? isFavorite}) {
    return WaypointsCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      description: description ?? this.description,
      type: type ?? this.type,
      createdAt: createdAt ?? this.createdAt,
      isFavorite: isFavorite ?? this.isFavorite,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (latitude.present) {
      map['latitude'] = Variable<double>(latitude.value);
    }
    if (longitude.present) {
      map['longitude'] = Variable<double>(longitude.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (isFavorite.present) {
      map['is_favorite'] = Variable<bool>(isFavorite.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WaypointsCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('description: $description, ')
          ..write('type: $type, ')
          ..write('createdAt: $createdAt, ')
          ..write('isFavorite: $isFavorite')
          ..write(')'))
        .toString();
  }
}

class $WeatherSnapshotsTable extends WeatherSnapshots
    with TableInfo<$WeatherSnapshotsTable, WeatherSnapshot> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WeatherSnapshotsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _latitudeMeta =
      const VerificationMeta('latitude');
  @override
  late final GeneratedColumn<double> latitude = GeneratedColumn<double>(
      'latitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _longitudeMeta =
      const VerificationMeta('longitude');
  @override
  late final GeneratedColumn<double> longitude = GeneratedColumn<double>(
      'longitude', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _forecastTimeMeta =
      const VerificationMeta('forecastTime');
  @override
  late final GeneratedColumn<DateTime> forecastTime = GeneratedColumn<DateTime>(
      'forecast_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _downloadedAtMeta =
      const VerificationMeta('downloadedAt');
  @override
  late final GeneratedColumn<DateTime> downloadedAt = GeneratedColumn<DateTime>(
      'downloaded_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _windSpeedMeta =
      const VerificationMeta('windSpeed');
  @override
  late final GeneratedColumn<double> windSpeed = GeneratedColumn<double>(
      'wind_speed', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _windDirectionMeta =
      const VerificationMeta('windDirection');
  @override
  late final GeneratedColumn<double> windDirection = GeneratedColumn<double>(
      'wind_direction', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _waveHeightMeta =
      const VerificationMeta('waveHeight');
  @override
  late final GeneratedColumn<double> waveHeight = GeneratedColumn<double>(
      'wave_height', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _wavePeriodMeta =
      const VerificationMeta('wavePeriod');
  @override
  late final GeneratedColumn<double> wavePeriod = GeneratedColumn<double>(
      'wave_period', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _airPressureMeta =
      const VerificationMeta('airPressure');
  @override
  late final GeneratedColumn<double> airPressure = GeneratedColumn<double>(
      'air_pressure', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _airTempMeta =
      const VerificationMeta('airTemp');
  @override
  late final GeneratedColumn<double> airTemp = GeneratedColumn<double>(
      'air_temp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _waterTempMeta =
      const VerificationMeta('waterTemp');
  @override
  late final GeneratedColumn<double> waterTemp = GeneratedColumn<double>(
      'water_temp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cloudCoverMeta =
      const VerificationMeta('cloudCover');
  @override
  late final GeneratedColumn<double> cloudCover = GeneratedColumn<double>(
      'cloud_cover', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        latitude,
        longitude,
        forecastTime,
        downloadedAt,
        windSpeed,
        windDirection,
        waveHeight,
        wavePeriod,
        airPressure,
        airTemp,
        waterTemp,
        cloudCover
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'weather_snapshots';
  @override
  VerificationContext validateIntegrity(Insertable<WeatherSnapshot> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('latitude')) {
      context.handle(_latitudeMeta,
          latitude.isAcceptableOrUnknown(data['latitude']!, _latitudeMeta));
    } else if (isInserting) {
      context.missing(_latitudeMeta);
    }
    if (data.containsKey('longitude')) {
      context.handle(_longitudeMeta,
          longitude.isAcceptableOrUnknown(data['longitude']!, _longitudeMeta));
    } else if (isInserting) {
      context.missing(_longitudeMeta);
    }
    if (data.containsKey('forecast_time')) {
      context.handle(
          _forecastTimeMeta,
          forecastTime.isAcceptableOrUnknown(
              data['forecast_time']!, _forecastTimeMeta));
    } else if (isInserting) {
      context.missing(_forecastTimeMeta);
    }
    if (data.containsKey('downloaded_at')) {
      context.handle(
          _downloadedAtMeta,
          downloadedAt.isAcceptableOrUnknown(
              data['downloaded_at']!, _downloadedAtMeta));
    } else if (isInserting) {
      context.missing(_downloadedAtMeta);
    }
    if (data.containsKey('wind_speed')) {
      context.handle(_windSpeedMeta,
          windSpeed.isAcceptableOrUnknown(data['wind_speed']!, _windSpeedMeta));
    } else if (isInserting) {
      context.missing(_windSpeedMeta);
    }
    if (data.containsKey('wind_direction')) {
      context.handle(
          _windDirectionMeta,
          windDirection.isAcceptableOrUnknown(
              data['wind_direction']!, _windDirectionMeta));
    } else if (isInserting) {
      context.missing(_windDirectionMeta);
    }
    if (data.containsKey('wave_height')) {
      context.handle(
          _waveHeightMeta,
          waveHeight.isAcceptableOrUnknown(
              data['wave_height']!, _waveHeightMeta));
    }
    if (data.containsKey('wave_period')) {
      context.handle(
          _wavePeriodMeta,
          wavePeriod.isAcceptableOrUnknown(
              data['wave_period']!, _wavePeriodMeta));
    }
    if (data.containsKey('air_pressure')) {
      context.handle(
          _airPressureMeta,
          airPressure.isAcceptableOrUnknown(
              data['air_pressure']!, _airPressureMeta));
    }
    if (data.containsKey('air_temp')) {
      context.handle(_airTempMeta,
          airTemp.isAcceptableOrUnknown(data['air_temp']!, _airTempMeta));
    }
    if (data.containsKey('water_temp')) {
      context.handle(_waterTempMeta,
          waterTemp.isAcceptableOrUnknown(data['water_temp']!, _waterTempMeta));
    }
    if (data.containsKey('cloud_cover')) {
      context.handle(
          _cloudCoverMeta,
          cloudCover.isAcceptableOrUnknown(
              data['cloud_cover']!, _cloudCoverMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WeatherSnapshot map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WeatherSnapshot(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      latitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}latitude'])!,
      longitude: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}longitude'])!,
      forecastTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}forecast_time'])!,
      downloadedAt: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}downloaded_at'])!,
      windSpeed: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wind_speed'])!,
      windDirection: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wind_direction'])!,
      waveHeight: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wave_height']),
      wavePeriod: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}wave_period']),
      airPressure: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}air_pressure']),
      airTemp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}air_temp']),
      waterTemp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}water_temp']),
      cloudCover: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}cloud_cover']),
    );
  }

  @override
  $WeatherSnapshotsTable createAlias(String alias) {
    return $WeatherSnapshotsTable(attachedDatabase, alias);
  }
}

class WeatherSnapshot extends DataClass implements Insertable<WeatherSnapshot> {
  final int id;
  final double latitude;
  final double longitude;
  final DateTime forecastTime;
  final DateTime downloadedAt;
  final double windSpeed;
  final double windDirection;
  final double? waveHeight;
  final double? wavePeriod;
  final double? airPressure;
  final double? airTemp;
  final double? waterTemp;
  final double? cloudCover;
  const WeatherSnapshot(
      {required this.id,
      required this.latitude,
      required this.longitude,
      required this.forecastTime,
      required this.downloadedAt,
      required this.windSpeed,
      required this.windDirection,
      this.waveHeight,
      this.wavePeriod,
      this.airPressure,
      this.airTemp,
      this.waterTemp,
      this.cloudCover});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['latitude'] = Variable<double>(latitude);
    map['longitude'] = Variable<double>(longitude);
    map['forecast_time'] = Variable<DateTime>(forecastTime);
    map['downloaded_at'] = Variable<DateTime>(downloadedAt);
    map['wind_speed'] = Variable<double>(windSpeed);
    map['wind_direction'] = Variable<double>(windDirection);
    if (!nullToAbsent || waveHeight != null) {
      map['wave_height'] = Variable<double>(waveHeight);
    }
    if (!nullToAbsent || wavePeriod != null) {
      map['wave_period'] = Variable<double>(wavePeriod);
    }
    if (!nullToAbsent || airPressure != null) {
      map['air_pressure'] = Variable<double>(airPressure);
    }
    if (!nullToAbsent || airTemp != null) {
      map['air_temp'] = Variable<double>(airTemp);
    }
    if (!nullToAbsent || waterTemp != null) {
      map['water_temp'] = Variable<double>(waterTemp);
    }
    if (!nullToAbsent || cloudCover != null) {
      map['cloud_cover'] = Variable<double>(cloudCover);
    }
    return map;
  }

  WeatherSnapshotsCompanion toCompanion(bool nullToAbsent) {
    return WeatherSnapshotsCompanion(
      id: Value(id),
      latitude: Value(latitude),
      longitude: Value(longitude),
      forecastTime: Value(forecastTime),
      downloadedAt: Value(downloadedAt),
      windSpeed: Value(windSpeed),
      windDirection: Value(windDirection),
      waveHeight: waveHeight == null && nullToAbsent
          ? const Value.absent()
          : Value(waveHeight),
      wavePeriod: wavePeriod == null && nullToAbsent
          ? const Value.absent()
          : Value(wavePeriod),
      airPressure: airPressure == null && nullToAbsent
          ? const Value.absent()
          : Value(airPressure),
      airTemp: airTemp == null && nullToAbsent
          ? const Value.absent()
          : Value(airTemp),
      waterTemp: waterTemp == null && nullToAbsent
          ? const Value.absent()
          : Value(waterTemp),
      cloudCover: cloudCover == null && nullToAbsent
          ? const Value.absent()
          : Value(cloudCover),
    );
  }

  factory WeatherSnapshot.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WeatherSnapshot(
      id: serializer.fromJson<int>(json['id']),
      latitude: serializer.fromJson<double>(json['latitude']),
      longitude: serializer.fromJson<double>(json['longitude']),
      forecastTime: serializer.fromJson<DateTime>(json['forecastTime']),
      downloadedAt: serializer.fromJson<DateTime>(json['downloadedAt']),
      windSpeed: serializer.fromJson<double>(json['windSpeed']),
      windDirection: serializer.fromJson<double>(json['windDirection']),
      waveHeight: serializer.fromJson<double?>(json['waveHeight']),
      wavePeriod: serializer.fromJson<double?>(json['wavePeriod']),
      airPressure: serializer.fromJson<double?>(json['airPressure']),
      airTemp: serializer.fromJson<double?>(json['airTemp']),
      waterTemp: serializer.fromJson<double?>(json['waterTemp']),
      cloudCover: serializer.fromJson<double?>(json['cloudCover']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'latitude': serializer.toJson<double>(latitude),
      'longitude': serializer.toJson<double>(longitude),
      'forecastTime': serializer.toJson<DateTime>(forecastTime),
      'downloadedAt': serializer.toJson<DateTime>(downloadedAt),
      'windSpeed': serializer.toJson<double>(windSpeed),
      'windDirection': serializer.toJson<double>(windDirection),
      'waveHeight': serializer.toJson<double?>(waveHeight),
      'wavePeriod': serializer.toJson<double?>(wavePeriod),
      'airPressure': serializer.toJson<double?>(airPressure),
      'airTemp': serializer.toJson<double?>(airTemp),
      'waterTemp': serializer.toJson<double?>(waterTemp),
      'cloudCover': serializer.toJson<double?>(cloudCover),
    };
  }

  WeatherSnapshot copyWith(
          {int? id,
          double? latitude,
          double? longitude,
          DateTime? forecastTime,
          DateTime? downloadedAt,
          double? windSpeed,
          double? windDirection,
          Value<double?> waveHeight = const Value.absent(),
          Value<double?> wavePeriod = const Value.absent(),
          Value<double?> airPressure = const Value.absent(),
          Value<double?> airTemp = const Value.absent(),
          Value<double?> waterTemp = const Value.absent(),
          Value<double?> cloudCover = const Value.absent()}) =>
      WeatherSnapshot(
        id: id ?? this.id,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        forecastTime: forecastTime ?? this.forecastTime,
        downloadedAt: downloadedAt ?? this.downloadedAt,
        windSpeed: windSpeed ?? this.windSpeed,
        windDirection: windDirection ?? this.windDirection,
        waveHeight: waveHeight.present ? waveHeight.value : this.waveHeight,
        wavePeriod: wavePeriod.present ? wavePeriod.value : this.wavePeriod,
        airPressure: airPressure.present ? airPressure.value : this.airPressure,
        airTemp: airTemp.present ? airTemp.value : this.airTemp,
        waterTemp: waterTemp.present ? waterTemp.value : this.waterTemp,
        cloudCover: cloudCover.present ? cloudCover.value : this.cloudCover,
      );
  WeatherSnapshot copyWithCompanion(WeatherSnapshotsCompanion data) {
    return WeatherSnapshot(
      id: data.id.present ? data.id.value : this.id,
      latitude: data.latitude.present ? data.latitude.value : this.latitude,
      longitude: data.longitude.present ? data.longitude.value : this.longitude,
      forecastTime: data.forecastTime.present
          ? data.forecastTime.value
          : this.forecastTime,
      downloadedAt: data.downloadedAt.present
          ? data.downloadedAt.value
          : this.downloadedAt,
      windSpeed: data.windSpeed.present ? data.windSpeed.value : this.windSpeed,
      windDirection: data.windDirection.present
          ? data.windDirection.value
          : this.windDirection,
      waveHeight:
          data.waveHeight.present ? data.waveHeight.value : this.waveHeight,
      wavePeriod:
          data.wavePeriod.present ? data.wavePeriod.value : this.wavePeriod,
      airPressure:
          data.airPressure.present ? data.airPressure.value : this.airPressure,
      airTemp: data.airTemp.present ? data.airTemp.value : this.airTemp,
      waterTemp: data.waterTemp.present ? data.waterTemp.value : this.waterTemp,
      cloudCover:
          data.cloudCover.present ? data.cloudCover.value : this.cloudCover,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WeatherSnapshot(')
          ..write('id: $id, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('forecastTime: $forecastTime, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('windSpeed: $windSpeed, ')
          ..write('windDirection: $windDirection, ')
          ..write('waveHeight: $waveHeight, ')
          ..write('wavePeriod: $wavePeriod, ')
          ..write('airPressure: $airPressure, ')
          ..write('airTemp: $airTemp, ')
          ..write('waterTemp: $waterTemp, ')
          ..write('cloudCover: $cloudCover')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      latitude,
      longitude,
      forecastTime,
      downloadedAt,
      windSpeed,
      windDirection,
      waveHeight,
      wavePeriod,
      airPressure,
      airTemp,
      waterTemp,
      cloudCover);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WeatherSnapshot &&
          other.id == this.id &&
          other.latitude == this.latitude &&
          other.longitude == this.longitude &&
          other.forecastTime == this.forecastTime &&
          other.downloadedAt == this.downloadedAt &&
          other.windSpeed == this.windSpeed &&
          other.windDirection == this.windDirection &&
          other.waveHeight == this.waveHeight &&
          other.wavePeriod == this.wavePeriod &&
          other.airPressure == this.airPressure &&
          other.airTemp == this.airTemp &&
          other.waterTemp == this.waterTemp &&
          other.cloudCover == this.cloudCover);
}

class WeatherSnapshotsCompanion extends UpdateCompanion<WeatherSnapshot> {
  final Value<int> id;
  final Value<double> latitude;
  final Value<double> longitude;
  final Value<DateTime> forecastTime;
  final Value<DateTime> downloadedAt;
  final Value<double> windSpeed;
  final Value<double> windDirection;
  final Value<double?> waveHeight;
  final Value<double?> wavePeriod;
  final Value<double?> airPressure;
  final Value<double?> airTemp;
  final Value<double?> waterTemp;
  final Value<double?> cloudCover;
  const WeatherSnapshotsCompanion({
    this.id = const Value.absent(),
    this.latitude = const Value.absent(),
    this.longitude = const Value.absent(),
    this.forecastTime = const Value.absent(),
    this.downloadedAt = const Value.absent(),
    this.windSpeed = const Value.absent(),
    this.windDirection = const Value.absent(),
    this.waveHeight = const Value.absent(),
    this.wavePeriod = const Value.absent(),
    this.airPressure = const Value.absent(),
    this.airTemp = const Value.absent(),
    this.waterTemp = const Value.absent(),
    this.cloudCover = const Value.absent(),
  });
  WeatherSnapshotsCompanion.insert({
    this.id = const Value.absent(),
    required double latitude,
    required double longitude,
    required DateTime forecastTime,
    required DateTime downloadedAt,
    required double windSpeed,
    required double windDirection,
    this.waveHeight = const Value.absent(),
    this.wavePeriod = const Value.absent(),
    this.airPressure = const Value.absent(),
    this.airTemp = const Value.absent(),
    this.waterTemp = const Value.absent(),
    this.cloudCover = const Value.absent(),
  })  : latitude = Value(latitude),
        longitude = Value(longitude),
        forecastTime = Value(forecastTime),
        downloadedAt = Value(downloadedAt),
        windSpeed = Value(windSpeed),
        windDirection = Value(windDirection);
  static Insertable<WeatherSnapshot> custom({
    Expression<int>? id,
    Expression<double>? latitude,
    Expression<double>? longitude,
    Expression<DateTime>? forecastTime,
    Expression<DateTime>? downloadedAt,
    Expression<double>? windSpeed,
    Expression<double>? windDirection,
    Expression<double>? waveHeight,
    Expression<double>? wavePeriod,
    Expression<double>? airPressure,
    Expression<double>? airTemp,
    Expression<double>? waterTemp,
    Expression<double>? cloudCover,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (latitude != null) 'latitude': latitude,
      if (longitude != null) 'longitude': longitude,
      if (forecastTime != null) 'forecast_time': forecastTime,
      if (downloadedAt != null) 'downloaded_at': downloadedAt,
      if (windSpeed != null) 'wind_speed': windSpeed,
      if (windDirection != null) 'wind_direction': windDirection,
      if (waveHeight != null) 'wave_height': waveHeight,
      if (wavePeriod != null) 'wave_period': wavePeriod,
      if (airPressure != null) 'air_pressure': airPressure,
      if (airTemp != null) 'air_temp': airTemp,
      if (waterTemp != null) 'water_temp': waterTemp,
      if (cloudCover != null) 'cloud_cover': cloudCover,
    });
  }

  WeatherSnapshotsCompanion copyWith(
      {Value<int>? id,
      Value<double>? latitude,
      Value<double>? longitude,
      Value<DateTime>? forecastTime,
      Value<DateTime>? downloadedAt,
      Value<double>? windSpeed,
      Value<double>? windDirection,
      Value<double?>? waveHeight,
      Value<double?>? wavePeriod,
      Value<double?>? airPressure,
      Value<double?>? airTemp,
      Value<double?>? waterTemp,
      Value<double?>? cloudCover}) {
    return WeatherSnapshotsCompanion(
      id: id ?? this.id,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      forecastTime: forecastTime ?? this.forecastTime,
      downloadedAt: downloadedAt ?? this.downloadedAt,
      windSpeed: windSpeed ?? this.windSpeed,
      windDirection: windDirection ?? this.windDirection,
      waveHeight: waveHeight ?? this.waveHeight,
      wavePeriod: wavePeriod ?? this.wavePeriod,
      airPressure: airPressure ?? this.airPressure,
      airTemp: airTemp ?? this.airTemp,
      waterTemp: waterTemp ?? this.waterTemp,
      cloudCover: cloudCover ?? this.cloudCover,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (latitude.present) {
      map['latitude'] = Variable<double>(latitude.value);
    }
    if (longitude.present) {
      map['longitude'] = Variable<double>(longitude.value);
    }
    if (forecastTime.present) {
      map['forecast_time'] = Variable<DateTime>(forecastTime.value);
    }
    if (downloadedAt.present) {
      map['downloaded_at'] = Variable<DateTime>(downloadedAt.value);
    }
    if (windSpeed.present) {
      map['wind_speed'] = Variable<double>(windSpeed.value);
    }
    if (windDirection.present) {
      map['wind_direction'] = Variable<double>(windDirection.value);
    }
    if (waveHeight.present) {
      map['wave_height'] = Variable<double>(waveHeight.value);
    }
    if (wavePeriod.present) {
      map['wave_period'] = Variable<double>(wavePeriod.value);
    }
    if (airPressure.present) {
      map['air_pressure'] = Variable<double>(airPressure.value);
    }
    if (airTemp.present) {
      map['air_temp'] = Variable<double>(airTemp.value);
    }
    if (waterTemp.present) {
      map['water_temp'] = Variable<double>(waterTemp.value);
    }
    if (cloudCover.present) {
      map['cloud_cover'] = Variable<double>(cloudCover.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WeatherSnapshotsCompanion(')
          ..write('id: $id, ')
          ..write('latitude: $latitude, ')
          ..write('longitude: $longitude, ')
          ..write('forecastTime: $forecastTime, ')
          ..write('downloadedAt: $downloadedAt, ')
          ..write('windSpeed: $windSpeed, ')
          ..write('windDirection: $windDirection, ')
          ..write('waveHeight: $waveHeight, ')
          ..write('wavePeriod: $wavePeriod, ')
          ..write('airPressure: $airPressure, ')
          ..write('airTemp: $airTemp, ')
          ..write('waterTemp: $waterTemp, ')
          ..write('cloudCover: $cloudCover')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ChartersTable charters = $ChartersTable(this);
  late final $DayLogsTable dayLogs = $DayLogsTable(this);
  late final $LogbookEntriesTable logbookEntries = $LogbookEntriesTable(this);
  late final $TrackPointsTable trackPoints = $TrackPointsTable(this);
  late final $SailingSessionsTable sailingSessions =
      $SailingSessionsTable(this);
  late final $WaypointsTable waypoints = $WaypointsTable(this);
  late final $WeatherSnapshotsTable weatherSnapshots =
      $WeatherSnapshotsTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        charters,
        dayLogs,
        logbookEntries,
        trackPoints,
        sailingSessions,
        waypoints,
        weatherSnapshots
      ];
}

typedef $$ChartersTableCreateCompanionBuilder = ChartersCompanion Function({
  Value<int> id,
  required String title,
  required DateTime dateFrom,
  required DateTime dateTo,
  Value<String?> vesselName,
  Value<String?> vesselType,
  Value<String?> homePort,
  Value<String?> skipperName,
  Value<String?> crewNames,
  Value<String?> notes,
  Value<bool> safetyBriefingDone,
  Value<bool> checkInDone,
  Value<bool> checkOutDone,
  required DateTime createdAt,
});
typedef $$ChartersTableUpdateCompanionBuilder = ChartersCompanion Function({
  Value<int> id,
  Value<String> title,
  Value<DateTime> dateFrom,
  Value<DateTime> dateTo,
  Value<String?> vesselName,
  Value<String?> vesselType,
  Value<String?> homePort,
  Value<String?> skipperName,
  Value<String?> crewNames,
  Value<String?> notes,
  Value<bool> safetyBriefingDone,
  Value<bool> checkInDone,
  Value<bool> checkOutDone,
  Value<DateTime> createdAt,
});

final class $$ChartersTableReferences
    extends BaseReferences<_$AppDatabase, $ChartersTable, Charter> {
  $$ChartersTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static MultiTypedResultKey<$DayLogsTable, List<DayLog>> _dayLogsRefsTable(
          _$AppDatabase db) =>
      MultiTypedResultKey.fromTable(db.dayLogs,
          aliasName:
              $_aliasNameGenerator(db.charters.id, db.dayLogs.charterId));

  $$DayLogsTableProcessedTableManager get dayLogsRefs {
    final manager = $$DayLogsTableTableManager($_db, $_db.dayLogs)
        .filter((f) => f.charterId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_dayLogsRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$ChartersTableFilterComposer
    extends Composer<_$AppDatabase, $ChartersTable> {
  $$ChartersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get dateFrom => $composableBuilder(
      column: $table.dateFrom, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get dateTo => $composableBuilder(
      column: $table.dateTo, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get vesselName => $composableBuilder(
      column: $table.vesselName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get vesselType => $composableBuilder(
      column: $table.vesselType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get homePort => $composableBuilder(
      column: $table.homePort, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get crewNames => $composableBuilder(
      column: $table.crewNames, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get safetyBriefingDone => $composableBuilder(
      column: $table.safetyBriefingDone,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get checkInDone => $composableBuilder(
      column: $table.checkInDone, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get checkOutDone => $composableBuilder(
      column: $table.checkOutDone, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  Expression<bool> dayLogsRefs(
      Expression<bool> Function($$DayLogsTableFilterComposer f) f) {
    final $$DayLogsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.charterId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableFilterComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$ChartersTableOrderingComposer
    extends Composer<_$AppDatabase, $ChartersTable> {
  $$ChartersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get dateFrom => $composableBuilder(
      column: $table.dateFrom, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get dateTo => $composableBuilder(
      column: $table.dateTo, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get vesselName => $composableBuilder(
      column: $table.vesselName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get vesselType => $composableBuilder(
      column: $table.vesselType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get homePort => $composableBuilder(
      column: $table.homePort, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get crewNames => $composableBuilder(
      column: $table.crewNames, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get notes => $composableBuilder(
      column: $table.notes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get safetyBriefingDone => $composableBuilder(
      column: $table.safetyBriefingDone,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get checkInDone => $composableBuilder(
      column: $table.checkInDone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get checkOutDone => $composableBuilder(
      column: $table.checkOutDone,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$ChartersTableAnnotationComposer
    extends Composer<_$AppDatabase, $ChartersTable> {
  $$ChartersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<DateTime> get dateFrom =>
      $composableBuilder(column: $table.dateFrom, builder: (column) => column);

  GeneratedColumn<DateTime> get dateTo =>
      $composableBuilder(column: $table.dateTo, builder: (column) => column);

  GeneratedColumn<String> get vesselName => $composableBuilder(
      column: $table.vesselName, builder: (column) => column);

  GeneratedColumn<String> get vesselType => $composableBuilder(
      column: $table.vesselType, builder: (column) => column);

  GeneratedColumn<String> get homePort =>
      $composableBuilder(column: $table.homePort, builder: (column) => column);

  GeneratedColumn<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => column);

  GeneratedColumn<String> get crewNames =>
      $composableBuilder(column: $table.crewNames, builder: (column) => column);

  GeneratedColumn<String> get notes =>
      $composableBuilder(column: $table.notes, builder: (column) => column);

  GeneratedColumn<bool> get safetyBriefingDone => $composableBuilder(
      column: $table.safetyBriefingDone, builder: (column) => column);

  GeneratedColumn<bool> get checkInDone => $composableBuilder(
      column: $table.checkInDone, builder: (column) => column);

  GeneratedColumn<bool> get checkOutDone => $composableBuilder(
      column: $table.checkOutDone, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  Expression<T> dayLogsRefs<T extends Object>(
      Expression<T> Function($$DayLogsTableAnnotationComposer a) f) {
    final $$DayLogsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.charterId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableAnnotationComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$ChartersTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ChartersTable,
    Charter,
    $$ChartersTableFilterComposer,
    $$ChartersTableOrderingComposer,
    $$ChartersTableAnnotationComposer,
    $$ChartersTableCreateCompanionBuilder,
    $$ChartersTableUpdateCompanionBuilder,
    (Charter, $$ChartersTableReferences),
    Charter,
    PrefetchHooks Function({bool dayLogsRefs})> {
  $$ChartersTableTableManager(_$AppDatabase db, $ChartersTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ChartersTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ChartersTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ChartersTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<DateTime> dateFrom = const Value.absent(),
            Value<DateTime> dateTo = const Value.absent(),
            Value<String?> vesselName = const Value.absent(),
            Value<String?> vesselType = const Value.absent(),
            Value<String?> homePort = const Value.absent(),
            Value<String?> skipperName = const Value.absent(),
            Value<String?> crewNames = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<bool> safetyBriefingDone = const Value.absent(),
            Value<bool> checkInDone = const Value.absent(),
            Value<bool> checkOutDone = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
          }) =>
              ChartersCompanion(
            id: id,
            title: title,
            dateFrom: dateFrom,
            dateTo: dateTo,
            vesselName: vesselName,
            vesselType: vesselType,
            homePort: homePort,
            skipperName: skipperName,
            crewNames: crewNames,
            notes: notes,
            safetyBriefingDone: safetyBriefingDone,
            checkInDone: checkInDone,
            checkOutDone: checkOutDone,
            createdAt: createdAt,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String title,
            required DateTime dateFrom,
            required DateTime dateTo,
            Value<String?> vesselName = const Value.absent(),
            Value<String?> vesselType = const Value.absent(),
            Value<String?> homePort = const Value.absent(),
            Value<String?> skipperName = const Value.absent(),
            Value<String?> crewNames = const Value.absent(),
            Value<String?> notes = const Value.absent(),
            Value<bool> safetyBriefingDone = const Value.absent(),
            Value<bool> checkInDone = const Value.absent(),
            Value<bool> checkOutDone = const Value.absent(),
            required DateTime createdAt,
          }) =>
              ChartersCompanion.insert(
            id: id,
            title: title,
            dateFrom: dateFrom,
            dateTo: dateTo,
            vesselName: vesselName,
            vesselType: vesselType,
            homePort: homePort,
            skipperName: skipperName,
            crewNames: crewNames,
            notes: notes,
            safetyBriefingDone: safetyBriefingDone,
            checkInDone: checkInDone,
            checkOutDone: checkOutDone,
            createdAt: createdAt,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$ChartersTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: ({dayLogsRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [if (dayLogsRefs) db.dayLogs],
              addJoins: null,
              getPrefetchedDataCallback: (items) async {
                return [
                  if (dayLogsRefs)
                    await $_getPrefetchedData<Charter, $ChartersTable, DayLog>(
                        currentTable: table,
                        referencedTable:
                            $$ChartersTableReferences._dayLogsRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$ChartersTableReferences(db, table, p0)
                                .dayLogsRefs,
                        referencedItemsForCurrentItem:
                            (item, referencedItems) => referencedItems
                                .where((e) => e.charterId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$ChartersTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ChartersTable,
    Charter,
    $$ChartersTableFilterComposer,
    $$ChartersTableOrderingComposer,
    $$ChartersTableAnnotationComposer,
    $$ChartersTableCreateCompanionBuilder,
    $$ChartersTableUpdateCompanionBuilder,
    (Charter, $$ChartersTableReferences),
    Charter,
    PrefetchHooks Function({bool dayLogsRefs})>;
typedef $$DayLogsTableCreateCompanionBuilder = DayLogsCompanion Function({
  Value<int> id,
  required int charterId,
  required DateTime date,
  Value<String?> portFrom,
  Value<String?> portTo,
  Value<String?> vesselForDay,
  Value<double> distanceNm,
  Value<int?> beaufortMorning,
  Value<int?> beaufortNoon,
  Value<int?> beaufortEvening,
  Value<String?> seaState,
  Value<double?> waveHeightM,
  Value<String?> windDirection,
  Value<double?> airTempC,
  Value<double?> waterTempC,
  Value<String?> sessionId,
  Value<String?> skipperNote,
  Value<bool> isComplete,
});
typedef $$DayLogsTableUpdateCompanionBuilder = DayLogsCompanion Function({
  Value<int> id,
  Value<int> charterId,
  Value<DateTime> date,
  Value<String?> portFrom,
  Value<String?> portTo,
  Value<String?> vesselForDay,
  Value<double> distanceNm,
  Value<int?> beaufortMorning,
  Value<int?> beaufortNoon,
  Value<int?> beaufortEvening,
  Value<String?> seaState,
  Value<double?> waveHeightM,
  Value<String?> windDirection,
  Value<double?> airTempC,
  Value<double?> waterTempC,
  Value<String?> sessionId,
  Value<String?> skipperNote,
  Value<bool> isComplete,
});

final class $$DayLogsTableReferences
    extends BaseReferences<_$AppDatabase, $DayLogsTable, DayLog> {
  $$DayLogsTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $ChartersTable _charterIdTable(_$AppDatabase db) => db.charters
      .createAlias($_aliasNameGenerator(db.dayLogs.charterId, db.charters.id));

  $$ChartersTableProcessedTableManager get charterId {
    final $_column = $_itemColumn<int>('charter_id')!;

    final manager = $$ChartersTableTableManager($_db, $_db.charters)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_charterIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }

  static MultiTypedResultKey<$LogbookEntriesTable, List<LogbookEntry>>
      _logbookEntriesRefsTable(_$AppDatabase db) =>
          MultiTypedResultKey.fromTable(db.logbookEntries,
              aliasName: $_aliasNameGenerator(
                  db.dayLogs.id, db.logbookEntries.dayLogId));

  $$LogbookEntriesTableProcessedTableManager get logbookEntriesRefs {
    final manager = $$LogbookEntriesTableTableManager($_db, $_db.logbookEntries)
        .filter((f) => f.dayLogId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_logbookEntriesRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }

  static MultiTypedResultKey<$SailingSessionsTable, List<SailingSession>>
      _sailingSessionsRefsTable(_$AppDatabase db) =>
          MultiTypedResultKey.fromTable(db.sailingSessions,
              aliasName: $_aliasNameGenerator(
                  db.dayLogs.id, db.sailingSessions.dayLogId));

  $$SailingSessionsTableProcessedTableManager get sailingSessionsRefs {
    final manager =
        $$SailingSessionsTableTableManager($_db, $_db.sailingSessions)
            .filter((f) => f.dayLogId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache =
        $_typedResult.readTableOrNull(_sailingSessionsRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$DayLogsTableFilterComposer
    extends Composer<_$AppDatabase, $DayLogsTable> {
  $$DayLogsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get portFrom => $composableBuilder(
      column: $table.portFrom, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get portTo => $composableBuilder(
      column: $table.portTo, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get vesselForDay => $composableBuilder(
      column: $table.vesselForDay, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get distanceNm => $composableBuilder(
      column: $table.distanceNm, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get beaufortMorning => $composableBuilder(
      column: $table.beaufortMorning,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get beaufortNoon => $composableBuilder(
      column: $table.beaufortNoon, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get beaufortEvening => $composableBuilder(
      column: $table.beaufortEvening,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get seaState => $composableBuilder(
      column: $table.seaState, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waveHeightM => $composableBuilder(
      column: $table.waveHeightM, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get airTempC => $composableBuilder(
      column: $table.airTempC, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waterTempC => $composableBuilder(
      column: $table.waterTempC, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isComplete => $composableBuilder(
      column: $table.isComplete, builder: (column) => ColumnFilters(column));

  $$ChartersTableFilterComposer get charterId {
    final $$ChartersTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.charterId,
        referencedTable: $db.charters,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$ChartersTableFilterComposer(
              $db: $db,
              $table: $db.charters,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<bool> logbookEntriesRefs(
      Expression<bool> Function($$LogbookEntriesTableFilterComposer f) f) {
    final $$LogbookEntriesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.logbookEntries,
        getReferencedColumn: (t) => t.dayLogId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$LogbookEntriesTableFilterComposer(
              $db: $db,
              $table: $db.logbookEntries,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<bool> sailingSessionsRefs(
      Expression<bool> Function($$SailingSessionsTableFilterComposer f) f) {
    final $$SailingSessionsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.sailingSessions,
        getReferencedColumn: (t) => t.dayLogId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$SailingSessionsTableFilterComposer(
              $db: $db,
              $table: $db.sailingSessions,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$DayLogsTableOrderingComposer
    extends Composer<_$AppDatabase, $DayLogsTable> {
  $$DayLogsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get date => $composableBuilder(
      column: $table.date, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get portFrom => $composableBuilder(
      column: $table.portFrom, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get portTo => $composableBuilder(
      column: $table.portTo, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get vesselForDay => $composableBuilder(
      column: $table.vesselForDay,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get distanceNm => $composableBuilder(
      column: $table.distanceNm, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get beaufortMorning => $composableBuilder(
      column: $table.beaufortMorning,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get beaufortNoon => $composableBuilder(
      column: $table.beaufortNoon,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get beaufortEvening => $composableBuilder(
      column: $table.beaufortEvening,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get seaState => $composableBuilder(
      column: $table.seaState, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waveHeightM => $composableBuilder(
      column: $table.waveHeightM, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get windDirection => $composableBuilder(
      column: $table.windDirection,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get airTempC => $composableBuilder(
      column: $table.airTempC, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waterTempC => $composableBuilder(
      column: $table.waterTempC, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isComplete => $composableBuilder(
      column: $table.isComplete, builder: (column) => ColumnOrderings(column));

  $$ChartersTableOrderingComposer get charterId {
    final $$ChartersTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.charterId,
        referencedTable: $db.charters,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$ChartersTableOrderingComposer(
              $db: $db,
              $table: $db.charters,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$DayLogsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DayLogsTable> {
  $$DayLogsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get date =>
      $composableBuilder(column: $table.date, builder: (column) => column);

  GeneratedColumn<String> get portFrom =>
      $composableBuilder(column: $table.portFrom, builder: (column) => column);

  GeneratedColumn<String> get portTo =>
      $composableBuilder(column: $table.portTo, builder: (column) => column);

  GeneratedColumn<String> get vesselForDay => $composableBuilder(
      column: $table.vesselForDay, builder: (column) => column);

  GeneratedColumn<double> get distanceNm => $composableBuilder(
      column: $table.distanceNm, builder: (column) => column);

  GeneratedColumn<int> get beaufortMorning => $composableBuilder(
      column: $table.beaufortMorning, builder: (column) => column);

  GeneratedColumn<int> get beaufortNoon => $composableBuilder(
      column: $table.beaufortNoon, builder: (column) => column);

  GeneratedColumn<int> get beaufortEvening => $composableBuilder(
      column: $table.beaufortEvening, builder: (column) => column);

  GeneratedColumn<String> get seaState =>
      $composableBuilder(column: $table.seaState, builder: (column) => column);

  GeneratedColumn<double> get waveHeightM => $composableBuilder(
      column: $table.waveHeightM, builder: (column) => column);

  GeneratedColumn<String> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => column);

  GeneratedColumn<double> get airTempC =>
      $composableBuilder(column: $table.airTempC, builder: (column) => column);

  GeneratedColumn<double> get waterTempC => $composableBuilder(
      column: $table.waterTempC, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => column);

  GeneratedColumn<bool> get isComplete => $composableBuilder(
      column: $table.isComplete, builder: (column) => column);

  $$ChartersTableAnnotationComposer get charterId {
    final $$ChartersTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.charterId,
        referencedTable: $db.charters,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$ChartersTableAnnotationComposer(
              $db: $db,
              $table: $db.charters,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }

  Expression<T> logbookEntriesRefs<T extends Object>(
      Expression<T> Function($$LogbookEntriesTableAnnotationComposer a) f) {
    final $$LogbookEntriesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.logbookEntries,
        getReferencedColumn: (t) => t.dayLogId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$LogbookEntriesTableAnnotationComposer(
              $db: $db,
              $table: $db.logbookEntries,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }

  Expression<T> sailingSessionsRefs<T extends Object>(
      Expression<T> Function($$SailingSessionsTableAnnotationComposer a) f) {
    final $$SailingSessionsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.sailingSessions,
        getReferencedColumn: (t) => t.dayLogId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$SailingSessionsTableAnnotationComposer(
              $db: $db,
              $table: $db.sailingSessions,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$DayLogsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DayLogsTable,
    DayLog,
    $$DayLogsTableFilterComposer,
    $$DayLogsTableOrderingComposer,
    $$DayLogsTableAnnotationComposer,
    $$DayLogsTableCreateCompanionBuilder,
    $$DayLogsTableUpdateCompanionBuilder,
    (DayLog, $$DayLogsTableReferences),
    DayLog,
    PrefetchHooks Function(
        {bool charterId, bool logbookEntriesRefs, bool sailingSessionsRefs})> {
  $$DayLogsTableTableManager(_$AppDatabase db, $DayLogsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DayLogsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DayLogsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DayLogsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> charterId = const Value.absent(),
            Value<DateTime> date = const Value.absent(),
            Value<String?> portFrom = const Value.absent(),
            Value<String?> portTo = const Value.absent(),
            Value<String?> vesselForDay = const Value.absent(),
            Value<double> distanceNm = const Value.absent(),
            Value<int?> beaufortMorning = const Value.absent(),
            Value<int?> beaufortNoon = const Value.absent(),
            Value<int?> beaufortEvening = const Value.absent(),
            Value<String?> seaState = const Value.absent(),
            Value<double?> waveHeightM = const Value.absent(),
            Value<String?> windDirection = const Value.absent(),
            Value<double?> airTempC = const Value.absent(),
            Value<double?> waterTempC = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<String?> skipperNote = const Value.absent(),
            Value<bool> isComplete = const Value.absent(),
          }) =>
              DayLogsCompanion(
            id: id,
            charterId: charterId,
            date: date,
            portFrom: portFrom,
            portTo: portTo,
            vesselForDay: vesselForDay,
            distanceNm: distanceNm,
            beaufortMorning: beaufortMorning,
            beaufortNoon: beaufortNoon,
            beaufortEvening: beaufortEvening,
            seaState: seaState,
            waveHeightM: waveHeightM,
            windDirection: windDirection,
            airTempC: airTempC,
            waterTempC: waterTempC,
            sessionId: sessionId,
            skipperNote: skipperNote,
            isComplete: isComplete,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int charterId,
            required DateTime date,
            Value<String?> portFrom = const Value.absent(),
            Value<String?> portTo = const Value.absent(),
            Value<String?> vesselForDay = const Value.absent(),
            Value<double> distanceNm = const Value.absent(),
            Value<int?> beaufortMorning = const Value.absent(),
            Value<int?> beaufortNoon = const Value.absent(),
            Value<int?> beaufortEvening = const Value.absent(),
            Value<String?> seaState = const Value.absent(),
            Value<double?> waveHeightM = const Value.absent(),
            Value<String?> windDirection = const Value.absent(),
            Value<double?> airTempC = const Value.absent(),
            Value<double?> waterTempC = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<String?> skipperNote = const Value.absent(),
            Value<bool> isComplete = const Value.absent(),
          }) =>
              DayLogsCompanion.insert(
            id: id,
            charterId: charterId,
            date: date,
            portFrom: portFrom,
            portTo: portTo,
            vesselForDay: vesselForDay,
            distanceNm: distanceNm,
            beaufortMorning: beaufortMorning,
            beaufortNoon: beaufortNoon,
            beaufortEvening: beaufortEvening,
            seaState: seaState,
            waveHeightM: waveHeightM,
            windDirection: windDirection,
            airTempC: airTempC,
            waterTempC: waterTempC,
            sessionId: sessionId,
            skipperNote: skipperNote,
            isComplete: isComplete,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$DayLogsTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: (
              {charterId = false,
              logbookEntriesRefs = false,
              sailingSessionsRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [
                if (logbookEntriesRefs) db.logbookEntries,
                if (sailingSessionsRefs) db.sailingSessions
              ],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (charterId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.charterId,
                    referencedTable:
                        $$DayLogsTableReferences._charterIdTable(db),
                    referencedColumn:
                        $$DayLogsTableReferences._charterIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [
                  if (logbookEntriesRefs)
                    await $_getPrefetchedData<DayLog, $DayLogsTable,
                            LogbookEntry>(
                        currentTable: table,
                        referencedTable: $$DayLogsTableReferences
                            ._logbookEntriesRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$DayLogsTableReferences(db, table, p0)
                                .logbookEntriesRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.dayLogId == item.id),
                        typedResults: items),
                  if (sailingSessionsRefs)
                    await $_getPrefetchedData<DayLog, $DayLogsTable,
                            SailingSession>(
                        currentTable: table,
                        referencedTable: $$DayLogsTableReferences
                            ._sailingSessionsRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$DayLogsTableReferences(db, table, p0)
                                .sailingSessionsRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.dayLogId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$DayLogsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DayLogsTable,
    DayLog,
    $$DayLogsTableFilterComposer,
    $$DayLogsTableOrderingComposer,
    $$DayLogsTableAnnotationComposer,
    $$DayLogsTableCreateCompanionBuilder,
    $$DayLogsTableUpdateCompanionBuilder,
    (DayLog, $$DayLogsTableReferences),
    DayLog,
    PrefetchHooks Function(
        {bool charterId, bool logbookEntriesRefs, bool sailingSessionsRefs})>;
typedef $$LogbookEntriesTableCreateCompanionBuilder = LogbookEntriesCompanion
    Function({
  Value<int> id,
  Value<int?> dayLogId,
  Value<String?> sessionId,
  required DateTime timestamp,
  Value<double?> latitude,
  Value<double?> longitude,
  Value<double?> sog,
  Value<double?> cog,
  Value<double?> heading,
  Value<double?> windSpeed,
  Value<double?> windDirection,
  Value<double?> waveHeight,
  Value<double?> airPressure,
  Value<double?> airTemp,
  Value<double?> waterTemp,
  Value<double?> engineHours,
  Value<double?> fuelConsumed,
  Value<String?> skipperName,
  Value<String?> crewNames,
  Value<String?> skipperNote,
  Value<bool> isAutoEntry,
});
typedef $$LogbookEntriesTableUpdateCompanionBuilder = LogbookEntriesCompanion
    Function({
  Value<int> id,
  Value<int?> dayLogId,
  Value<String?> sessionId,
  Value<DateTime> timestamp,
  Value<double?> latitude,
  Value<double?> longitude,
  Value<double?> sog,
  Value<double?> cog,
  Value<double?> heading,
  Value<double?> windSpeed,
  Value<double?> windDirection,
  Value<double?> waveHeight,
  Value<double?> airPressure,
  Value<double?> airTemp,
  Value<double?> waterTemp,
  Value<double?> engineHours,
  Value<double?> fuelConsumed,
  Value<String?> skipperName,
  Value<String?> crewNames,
  Value<String?> skipperNote,
  Value<bool> isAutoEntry,
});

final class $$LogbookEntriesTableReferences
    extends BaseReferences<_$AppDatabase, $LogbookEntriesTable, LogbookEntry> {
  $$LogbookEntriesTableReferences(
      super.$_db, super.$_table, super.$_typedResult);

  static $DayLogsTable _dayLogIdTable(_$AppDatabase db) =>
      db.dayLogs.createAlias(
          $_aliasNameGenerator(db.logbookEntries.dayLogId, db.dayLogs.id));

  $$DayLogsTableProcessedTableManager? get dayLogId {
    final $_column = $_itemColumn<int>('day_log_id');
    if ($_column == null) return null;
    final manager = $$DayLogsTableTableManager($_db, $_db.dayLogs)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_dayLogIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$LogbookEntriesTableFilterComposer
    extends Composer<_$AppDatabase, $LogbookEntriesTable> {
  $$LogbookEntriesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
      column: $table.timestamp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get sog => $composableBuilder(
      column: $table.sog, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get cog => $composableBuilder(
      column: $table.cog, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get heading => $composableBuilder(
      column: $table.heading, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get windSpeed => $composableBuilder(
      column: $table.windSpeed, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get airTemp => $composableBuilder(
      column: $table.airTemp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waterTemp => $composableBuilder(
      column: $table.waterTemp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get engineHours => $composableBuilder(
      column: $table.engineHours, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get fuelConsumed => $composableBuilder(
      column: $table.fuelConsumed, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get crewNames => $composableBuilder(
      column: $table.crewNames, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isAutoEntry => $composableBuilder(
      column: $table.isAutoEntry, builder: (column) => ColumnFilters(column));

  $$DayLogsTableFilterComposer get dayLogId {
    final $$DayLogsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableFilterComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$LogbookEntriesTableOrderingComposer
    extends Composer<_$AppDatabase, $LogbookEntriesTable> {
  $$LogbookEntriesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
      column: $table.timestamp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get sog => $composableBuilder(
      column: $table.sog, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get cog => $composableBuilder(
      column: $table.cog, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get heading => $composableBuilder(
      column: $table.heading, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get windSpeed => $composableBuilder(
      column: $table.windSpeed, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get windDirection => $composableBuilder(
      column: $table.windDirection,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get airTemp => $composableBuilder(
      column: $table.airTemp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waterTemp => $composableBuilder(
      column: $table.waterTemp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get engineHours => $composableBuilder(
      column: $table.engineHours, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get fuelConsumed => $composableBuilder(
      column: $table.fuelConsumed,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get crewNames => $composableBuilder(
      column: $table.crewNames, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isAutoEntry => $composableBuilder(
      column: $table.isAutoEntry, builder: (column) => ColumnOrderings(column));

  $$DayLogsTableOrderingComposer get dayLogId {
    final $$DayLogsTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableOrderingComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$LogbookEntriesTableAnnotationComposer
    extends Composer<_$AppDatabase, $LogbookEntriesTable> {
  $$LogbookEntriesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);

  GeneratedColumn<double> get latitude =>
      $composableBuilder(column: $table.latitude, builder: (column) => column);

  GeneratedColumn<double> get longitude =>
      $composableBuilder(column: $table.longitude, builder: (column) => column);

  GeneratedColumn<double> get sog =>
      $composableBuilder(column: $table.sog, builder: (column) => column);

  GeneratedColumn<double> get cog =>
      $composableBuilder(column: $table.cog, builder: (column) => column);

  GeneratedColumn<double> get heading =>
      $composableBuilder(column: $table.heading, builder: (column) => column);

  GeneratedColumn<double> get windSpeed =>
      $composableBuilder(column: $table.windSpeed, builder: (column) => column);

  GeneratedColumn<double> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => column);

  GeneratedColumn<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => column);

  GeneratedColumn<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => column);

  GeneratedColumn<double> get airTemp =>
      $composableBuilder(column: $table.airTemp, builder: (column) => column);

  GeneratedColumn<double> get waterTemp =>
      $composableBuilder(column: $table.waterTemp, builder: (column) => column);

  GeneratedColumn<double> get engineHours => $composableBuilder(
      column: $table.engineHours, builder: (column) => column);

  GeneratedColumn<double> get fuelConsumed => $composableBuilder(
      column: $table.fuelConsumed, builder: (column) => column);

  GeneratedColumn<String> get skipperName => $composableBuilder(
      column: $table.skipperName, builder: (column) => column);

  GeneratedColumn<String> get crewNames =>
      $composableBuilder(column: $table.crewNames, builder: (column) => column);

  GeneratedColumn<String> get skipperNote => $composableBuilder(
      column: $table.skipperNote, builder: (column) => column);

  GeneratedColumn<bool> get isAutoEntry => $composableBuilder(
      column: $table.isAutoEntry, builder: (column) => column);

  $$DayLogsTableAnnotationComposer get dayLogId {
    final $$DayLogsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableAnnotationComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$LogbookEntriesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $LogbookEntriesTable,
    LogbookEntry,
    $$LogbookEntriesTableFilterComposer,
    $$LogbookEntriesTableOrderingComposer,
    $$LogbookEntriesTableAnnotationComposer,
    $$LogbookEntriesTableCreateCompanionBuilder,
    $$LogbookEntriesTableUpdateCompanionBuilder,
    (LogbookEntry, $$LogbookEntriesTableReferences),
    LogbookEntry,
    PrefetchHooks Function({bool dayLogId})> {
  $$LogbookEntriesTableTableManager(
      _$AppDatabase db, $LogbookEntriesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LogbookEntriesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LogbookEntriesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LogbookEntriesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int?> dayLogId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<DateTime> timestamp = const Value.absent(),
            Value<double?> latitude = const Value.absent(),
            Value<double?> longitude = const Value.absent(),
            Value<double?> sog = const Value.absent(),
            Value<double?> cog = const Value.absent(),
            Value<double?> heading = const Value.absent(),
            Value<double?> windSpeed = const Value.absent(),
            Value<double?> windDirection = const Value.absent(),
            Value<double?> waveHeight = const Value.absent(),
            Value<double?> airPressure = const Value.absent(),
            Value<double?> airTemp = const Value.absent(),
            Value<double?> waterTemp = const Value.absent(),
            Value<double?> engineHours = const Value.absent(),
            Value<double?> fuelConsumed = const Value.absent(),
            Value<String?> skipperName = const Value.absent(),
            Value<String?> crewNames = const Value.absent(),
            Value<String?> skipperNote = const Value.absent(),
            Value<bool> isAutoEntry = const Value.absent(),
          }) =>
              LogbookEntriesCompanion(
            id: id,
            dayLogId: dayLogId,
            sessionId: sessionId,
            timestamp: timestamp,
            latitude: latitude,
            longitude: longitude,
            sog: sog,
            cog: cog,
            heading: heading,
            windSpeed: windSpeed,
            windDirection: windDirection,
            waveHeight: waveHeight,
            airPressure: airPressure,
            airTemp: airTemp,
            waterTemp: waterTemp,
            engineHours: engineHours,
            fuelConsumed: fuelConsumed,
            skipperName: skipperName,
            crewNames: crewNames,
            skipperNote: skipperNote,
            isAutoEntry: isAutoEntry,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int?> dayLogId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            required DateTime timestamp,
            Value<double?> latitude = const Value.absent(),
            Value<double?> longitude = const Value.absent(),
            Value<double?> sog = const Value.absent(),
            Value<double?> cog = const Value.absent(),
            Value<double?> heading = const Value.absent(),
            Value<double?> windSpeed = const Value.absent(),
            Value<double?> windDirection = const Value.absent(),
            Value<double?> waveHeight = const Value.absent(),
            Value<double?> airPressure = const Value.absent(),
            Value<double?> airTemp = const Value.absent(),
            Value<double?> waterTemp = const Value.absent(),
            Value<double?> engineHours = const Value.absent(),
            Value<double?> fuelConsumed = const Value.absent(),
            Value<String?> skipperName = const Value.absent(),
            Value<String?> crewNames = const Value.absent(),
            Value<String?> skipperNote = const Value.absent(),
            Value<bool> isAutoEntry = const Value.absent(),
          }) =>
              LogbookEntriesCompanion.insert(
            id: id,
            dayLogId: dayLogId,
            sessionId: sessionId,
            timestamp: timestamp,
            latitude: latitude,
            longitude: longitude,
            sog: sog,
            cog: cog,
            heading: heading,
            windSpeed: windSpeed,
            windDirection: windDirection,
            waveHeight: waveHeight,
            airPressure: airPressure,
            airTemp: airTemp,
            waterTemp: waterTemp,
            engineHours: engineHours,
            fuelConsumed: fuelConsumed,
            skipperName: skipperName,
            crewNames: crewNames,
            skipperNote: skipperNote,
            isAutoEntry: isAutoEntry,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (
                    e.readTable(table),
                    $$LogbookEntriesTableReferences(db, table, e)
                  ))
              .toList(),
          prefetchHooksCallback: ({dayLogId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (dayLogId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.dayLogId,
                    referencedTable:
                        $$LogbookEntriesTableReferences._dayLogIdTable(db),
                    referencedColumn:
                        $$LogbookEntriesTableReferences._dayLogIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$LogbookEntriesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $LogbookEntriesTable,
    LogbookEntry,
    $$LogbookEntriesTableFilterComposer,
    $$LogbookEntriesTableOrderingComposer,
    $$LogbookEntriesTableAnnotationComposer,
    $$LogbookEntriesTableCreateCompanionBuilder,
    $$LogbookEntriesTableUpdateCompanionBuilder,
    (LogbookEntry, $$LogbookEntriesTableReferences),
    LogbookEntry,
    PrefetchHooks Function({bool dayLogId})>;
typedef $$TrackPointsTableCreateCompanionBuilder = TrackPointsCompanion
    Function({
  Value<int> id,
  Value<String?> sessionId,
  required DateTime timestamp,
  required double latitude,
  required double longitude,
  Value<double?> altitude,
  Value<double?> speed,
  Value<double?> course,
  Value<double?> accuracy,
});
typedef $$TrackPointsTableUpdateCompanionBuilder = TrackPointsCompanion
    Function({
  Value<int> id,
  Value<String?> sessionId,
  Value<DateTime> timestamp,
  Value<double> latitude,
  Value<double> longitude,
  Value<double?> altitude,
  Value<double?> speed,
  Value<double?> course,
  Value<double?> accuracy,
});

class $$TrackPointsTableFilterComposer
    extends Composer<_$AppDatabase, $TrackPointsTable> {
  $$TrackPointsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get timestamp => $composableBuilder(
      column: $table.timestamp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get altitude => $composableBuilder(
      column: $table.altitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get speed => $composableBuilder(
      column: $table.speed, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get course => $composableBuilder(
      column: $table.course, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get accuracy => $composableBuilder(
      column: $table.accuracy, builder: (column) => ColumnFilters(column));
}

class $$TrackPointsTableOrderingComposer
    extends Composer<_$AppDatabase, $TrackPointsTable> {
  $$TrackPointsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get timestamp => $composableBuilder(
      column: $table.timestamp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get altitude => $composableBuilder(
      column: $table.altitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get speed => $composableBuilder(
      column: $table.speed, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get course => $composableBuilder(
      column: $table.course, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get accuracy => $composableBuilder(
      column: $table.accuracy, builder: (column) => ColumnOrderings(column));
}

class $$TrackPointsTableAnnotationComposer
    extends Composer<_$AppDatabase, $TrackPointsTable> {
  $$TrackPointsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<DateTime> get timestamp =>
      $composableBuilder(column: $table.timestamp, builder: (column) => column);

  GeneratedColumn<double> get latitude =>
      $composableBuilder(column: $table.latitude, builder: (column) => column);

  GeneratedColumn<double> get longitude =>
      $composableBuilder(column: $table.longitude, builder: (column) => column);

  GeneratedColumn<double> get altitude =>
      $composableBuilder(column: $table.altitude, builder: (column) => column);

  GeneratedColumn<double> get speed =>
      $composableBuilder(column: $table.speed, builder: (column) => column);

  GeneratedColumn<double> get course =>
      $composableBuilder(column: $table.course, builder: (column) => column);

  GeneratedColumn<double> get accuracy =>
      $composableBuilder(column: $table.accuracy, builder: (column) => column);
}

class $$TrackPointsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TrackPointsTable,
    TrackPoint,
    $$TrackPointsTableFilterComposer,
    $$TrackPointsTableOrderingComposer,
    $$TrackPointsTableAnnotationComposer,
    $$TrackPointsTableCreateCompanionBuilder,
    $$TrackPointsTableUpdateCompanionBuilder,
    (TrackPoint, BaseReferences<_$AppDatabase, $TrackPointsTable, TrackPoint>),
    TrackPoint,
    PrefetchHooks Function()> {
  $$TrackPointsTableTableManager(_$AppDatabase db, $TrackPointsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$TrackPointsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$TrackPointsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$TrackPointsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<DateTime> timestamp = const Value.absent(),
            Value<double> latitude = const Value.absent(),
            Value<double> longitude = const Value.absent(),
            Value<double?> altitude = const Value.absent(),
            Value<double?> speed = const Value.absent(),
            Value<double?> course = const Value.absent(),
            Value<double?> accuracy = const Value.absent(),
          }) =>
              TrackPointsCompanion(
            id: id,
            sessionId: sessionId,
            timestamp: timestamp,
            latitude: latitude,
            longitude: longitude,
            altitude: altitude,
            speed: speed,
            course: course,
            accuracy: accuracy,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            required DateTime timestamp,
            required double latitude,
            required double longitude,
            Value<double?> altitude = const Value.absent(),
            Value<double?> speed = const Value.absent(),
            Value<double?> course = const Value.absent(),
            Value<double?> accuracy = const Value.absent(),
          }) =>
              TrackPointsCompanion.insert(
            id: id,
            sessionId: sessionId,
            timestamp: timestamp,
            latitude: latitude,
            longitude: longitude,
            altitude: altitude,
            speed: speed,
            course: course,
            accuracy: accuracy,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$TrackPointsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $TrackPointsTable,
    TrackPoint,
    $$TrackPointsTableFilterComposer,
    $$TrackPointsTableOrderingComposer,
    $$TrackPointsTableAnnotationComposer,
    $$TrackPointsTableCreateCompanionBuilder,
    $$TrackPointsTableUpdateCompanionBuilder,
    (TrackPoint, BaseReferences<_$AppDatabase, $TrackPointsTable, TrackPoint>),
    TrackPoint,
    PrefetchHooks Function()>;
typedef $$SailingSessionsTableCreateCompanionBuilder = SailingSessionsCompanion
    Function({
  Value<int> id,
  required String sessionId,
  Value<int?> dayLogId,
  required DateTime startTime,
  Value<DateTime?> endTime,
  Value<String?> name,
  Value<double> totalDistanceNm,
  Value<double> maxSpeedKnots,
  Value<double> avgSpeedKnots,
  Value<bool> isActive,
});
typedef $$SailingSessionsTableUpdateCompanionBuilder = SailingSessionsCompanion
    Function({
  Value<int> id,
  Value<String> sessionId,
  Value<int?> dayLogId,
  Value<DateTime> startTime,
  Value<DateTime?> endTime,
  Value<String?> name,
  Value<double> totalDistanceNm,
  Value<double> maxSpeedKnots,
  Value<double> avgSpeedKnots,
  Value<bool> isActive,
});

final class $$SailingSessionsTableReferences extends BaseReferences<
    _$AppDatabase, $SailingSessionsTable, SailingSession> {
  $$SailingSessionsTableReferences(
      super.$_db, super.$_table, super.$_typedResult);

  static $DayLogsTable _dayLogIdTable(_$AppDatabase db) =>
      db.dayLogs.createAlias(
          $_aliasNameGenerator(db.sailingSessions.dayLogId, db.dayLogs.id));

  $$DayLogsTableProcessedTableManager? get dayLogId {
    final $_column = $_itemColumn<int>('day_log_id');
    if ($_column == null) return null;
    final manager = $$DayLogsTableTableManager($_db, $_db.dayLogs)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_dayLogIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$SailingSessionsTableFilterComposer
    extends Composer<_$AppDatabase, $SailingSessionsTable> {
  $$SailingSessionsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get endTime => $composableBuilder(
      column: $table.endTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get totalDistanceNm => $composableBuilder(
      column: $table.totalDistanceNm,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get maxSpeedKnots => $composableBuilder(
      column: $table.maxSpeedKnots, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get avgSpeedKnots => $composableBuilder(
      column: $table.avgSpeedKnots, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  $$DayLogsTableFilterComposer get dayLogId {
    final $$DayLogsTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableFilterComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$SailingSessionsTableOrderingComposer
    extends Composer<_$AppDatabase, $SailingSessionsTable> {
  $$SailingSessionsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get endTime => $composableBuilder(
      column: $table.endTime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get totalDistanceNm => $composableBuilder(
      column: $table.totalDistanceNm,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get maxSpeedKnots => $composableBuilder(
      column: $table.maxSpeedKnots,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get avgSpeedKnots => $composableBuilder(
      column: $table.avgSpeedKnots,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  $$DayLogsTableOrderingComposer get dayLogId {
    final $$DayLogsTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableOrderingComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$SailingSessionsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SailingSessionsTable> {
  $$SailingSessionsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<DateTime> get startTime =>
      $composableBuilder(column: $table.startTime, builder: (column) => column);

  GeneratedColumn<DateTime> get endTime =>
      $composableBuilder(column: $table.endTime, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<double> get totalDistanceNm => $composableBuilder(
      column: $table.totalDistanceNm, builder: (column) => column);

  GeneratedColumn<double> get maxSpeedKnots => $composableBuilder(
      column: $table.maxSpeedKnots, builder: (column) => column);

  GeneratedColumn<double> get avgSpeedKnots => $composableBuilder(
      column: $table.avgSpeedKnots, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  $$DayLogsTableAnnotationComposer get dayLogId {
    final $$DayLogsTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.dayLogId,
        referencedTable: $db.dayLogs,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$DayLogsTableAnnotationComposer(
              $db: $db,
              $table: $db.dayLogs,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$SailingSessionsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SailingSessionsTable,
    SailingSession,
    $$SailingSessionsTableFilterComposer,
    $$SailingSessionsTableOrderingComposer,
    $$SailingSessionsTableAnnotationComposer,
    $$SailingSessionsTableCreateCompanionBuilder,
    $$SailingSessionsTableUpdateCompanionBuilder,
    (SailingSession, $$SailingSessionsTableReferences),
    SailingSession,
    PrefetchHooks Function({bool dayLogId})> {
  $$SailingSessionsTableTableManager(
      _$AppDatabase db, $SailingSessionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SailingSessionsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SailingSessionsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SailingSessionsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> sessionId = const Value.absent(),
            Value<int?> dayLogId = const Value.absent(),
            Value<DateTime> startTime = const Value.absent(),
            Value<DateTime?> endTime = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<double> totalDistanceNm = const Value.absent(),
            Value<double> maxSpeedKnots = const Value.absent(),
            Value<double> avgSpeedKnots = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
          }) =>
              SailingSessionsCompanion(
            id: id,
            sessionId: sessionId,
            dayLogId: dayLogId,
            startTime: startTime,
            endTime: endTime,
            name: name,
            totalDistanceNm: totalDistanceNm,
            maxSpeedKnots: maxSpeedKnots,
            avgSpeedKnots: avgSpeedKnots,
            isActive: isActive,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String sessionId,
            Value<int?> dayLogId = const Value.absent(),
            required DateTime startTime,
            Value<DateTime?> endTime = const Value.absent(),
            Value<String?> name = const Value.absent(),
            Value<double> totalDistanceNm = const Value.absent(),
            Value<double> maxSpeedKnots = const Value.absent(),
            Value<double> avgSpeedKnots = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
          }) =>
              SailingSessionsCompanion.insert(
            id: id,
            sessionId: sessionId,
            dayLogId: dayLogId,
            startTime: startTime,
            endTime: endTime,
            name: name,
            totalDistanceNm: totalDistanceNm,
            maxSpeedKnots: maxSpeedKnots,
            avgSpeedKnots: avgSpeedKnots,
            isActive: isActive,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (
                    e.readTable(table),
                    $$SailingSessionsTableReferences(db, table, e)
                  ))
              .toList(),
          prefetchHooksCallback: ({dayLogId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (dayLogId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.dayLogId,
                    referencedTable:
                        $$SailingSessionsTableReferences._dayLogIdTable(db),
                    referencedColumn:
                        $$SailingSessionsTableReferences._dayLogIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$SailingSessionsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SailingSessionsTable,
    SailingSession,
    $$SailingSessionsTableFilterComposer,
    $$SailingSessionsTableOrderingComposer,
    $$SailingSessionsTableAnnotationComposer,
    $$SailingSessionsTableCreateCompanionBuilder,
    $$SailingSessionsTableUpdateCompanionBuilder,
    (SailingSession, $$SailingSessionsTableReferences),
    SailingSession,
    PrefetchHooks Function({bool dayLogId})>;
typedef $$WaypointsTableCreateCompanionBuilder = WaypointsCompanion Function({
  Value<int> id,
  required String name,
  required double latitude,
  required double longitude,
  Value<String?> description,
  Value<String?> type,
  required DateTime createdAt,
  Value<bool> isFavorite,
});
typedef $$WaypointsTableUpdateCompanionBuilder = WaypointsCompanion Function({
  Value<int> id,
  Value<String> name,
  Value<double> latitude,
  Value<double> longitude,
  Value<String?> description,
  Value<String?> type,
  Value<DateTime> createdAt,
  Value<bool> isFavorite,
});

class $$WaypointsTableFilterComposer
    extends Composer<_$AppDatabase, $WaypointsTable> {
  $$WaypointsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => ColumnFilters(column));
}

class $$WaypointsTableOrderingComposer
    extends Composer<_$AppDatabase, $WaypointsTable> {
  $$WaypointsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => ColumnOrderings(column));
}

class $$WaypointsTableAnnotationComposer
    extends Composer<_$AppDatabase, $WaypointsTable> {
  $$WaypointsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<double> get latitude =>
      $composableBuilder(column: $table.latitude, builder: (column) => column);

  GeneratedColumn<double> get longitude =>
      $composableBuilder(column: $table.longitude, builder: (column) => column);

  GeneratedColumn<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => column);
}

class $$WaypointsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $WaypointsTable,
    Waypoint,
    $$WaypointsTableFilterComposer,
    $$WaypointsTableOrderingComposer,
    $$WaypointsTableAnnotationComposer,
    $$WaypointsTableCreateCompanionBuilder,
    $$WaypointsTableUpdateCompanionBuilder,
    (Waypoint, BaseReferences<_$AppDatabase, $WaypointsTable, Waypoint>),
    Waypoint,
    PrefetchHooks Function()> {
  $$WaypointsTableTableManager(_$AppDatabase db, $WaypointsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$WaypointsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$WaypointsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$WaypointsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<double> latitude = const Value.absent(),
            Value<double> longitude = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> type = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<bool> isFavorite = const Value.absent(),
          }) =>
              WaypointsCompanion(
            id: id,
            name: name,
            latitude: latitude,
            longitude: longitude,
            description: description,
            type: type,
            createdAt: createdAt,
            isFavorite: isFavorite,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String name,
            required double latitude,
            required double longitude,
            Value<String?> description = const Value.absent(),
            Value<String?> type = const Value.absent(),
            required DateTime createdAt,
            Value<bool> isFavorite = const Value.absent(),
          }) =>
              WaypointsCompanion.insert(
            id: id,
            name: name,
            latitude: latitude,
            longitude: longitude,
            description: description,
            type: type,
            createdAt: createdAt,
            isFavorite: isFavorite,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$WaypointsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $WaypointsTable,
    Waypoint,
    $$WaypointsTableFilterComposer,
    $$WaypointsTableOrderingComposer,
    $$WaypointsTableAnnotationComposer,
    $$WaypointsTableCreateCompanionBuilder,
    $$WaypointsTableUpdateCompanionBuilder,
    (Waypoint, BaseReferences<_$AppDatabase, $WaypointsTable, Waypoint>),
    Waypoint,
    PrefetchHooks Function()>;
typedef $$WeatherSnapshotsTableCreateCompanionBuilder
    = WeatherSnapshotsCompanion Function({
  Value<int> id,
  required double latitude,
  required double longitude,
  required DateTime forecastTime,
  required DateTime downloadedAt,
  required double windSpeed,
  required double windDirection,
  Value<double?> waveHeight,
  Value<double?> wavePeriod,
  Value<double?> airPressure,
  Value<double?> airTemp,
  Value<double?> waterTemp,
  Value<double?> cloudCover,
});
typedef $$WeatherSnapshotsTableUpdateCompanionBuilder
    = WeatherSnapshotsCompanion Function({
  Value<int> id,
  Value<double> latitude,
  Value<double> longitude,
  Value<DateTime> forecastTime,
  Value<DateTime> downloadedAt,
  Value<double> windSpeed,
  Value<double> windDirection,
  Value<double?> waveHeight,
  Value<double?> wavePeriod,
  Value<double?> airPressure,
  Value<double?> airTemp,
  Value<double?> waterTemp,
  Value<double?> cloudCover,
});

class $$WeatherSnapshotsTableFilterComposer
    extends Composer<_$AppDatabase, $WeatherSnapshotsTable> {
  $$WeatherSnapshotsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get forecastTime => $composableBuilder(
      column: $table.forecastTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get downloadedAt => $composableBuilder(
      column: $table.downloadedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get windSpeed => $composableBuilder(
      column: $table.windSpeed, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get wavePeriod => $composableBuilder(
      column: $table.wavePeriod, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get airTemp => $composableBuilder(
      column: $table.airTemp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get waterTemp => $composableBuilder(
      column: $table.waterTemp, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get cloudCover => $composableBuilder(
      column: $table.cloudCover, builder: (column) => ColumnFilters(column));
}

class $$WeatherSnapshotsTableOrderingComposer
    extends Composer<_$AppDatabase, $WeatherSnapshotsTable> {
  $$WeatherSnapshotsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get latitude => $composableBuilder(
      column: $table.latitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get longitude => $composableBuilder(
      column: $table.longitude, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get forecastTime => $composableBuilder(
      column: $table.forecastTime,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get downloadedAt => $composableBuilder(
      column: $table.downloadedAt,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get windSpeed => $composableBuilder(
      column: $table.windSpeed, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get windDirection => $composableBuilder(
      column: $table.windDirection,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get wavePeriod => $composableBuilder(
      column: $table.wavePeriod, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get airTemp => $composableBuilder(
      column: $table.airTemp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get waterTemp => $composableBuilder(
      column: $table.waterTemp, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get cloudCover => $composableBuilder(
      column: $table.cloudCover, builder: (column) => ColumnOrderings(column));
}

class $$WeatherSnapshotsTableAnnotationComposer
    extends Composer<_$AppDatabase, $WeatherSnapshotsTable> {
  $$WeatherSnapshotsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<double> get latitude =>
      $composableBuilder(column: $table.latitude, builder: (column) => column);

  GeneratedColumn<double> get longitude =>
      $composableBuilder(column: $table.longitude, builder: (column) => column);

  GeneratedColumn<DateTime> get forecastTime => $composableBuilder(
      column: $table.forecastTime, builder: (column) => column);

  GeneratedColumn<DateTime> get downloadedAt => $composableBuilder(
      column: $table.downloadedAt, builder: (column) => column);

  GeneratedColumn<double> get windSpeed =>
      $composableBuilder(column: $table.windSpeed, builder: (column) => column);

  GeneratedColumn<double> get windDirection => $composableBuilder(
      column: $table.windDirection, builder: (column) => column);

  GeneratedColumn<double> get waveHeight => $composableBuilder(
      column: $table.waveHeight, builder: (column) => column);

  GeneratedColumn<double> get wavePeriod => $composableBuilder(
      column: $table.wavePeriod, builder: (column) => column);

  GeneratedColumn<double> get airPressure => $composableBuilder(
      column: $table.airPressure, builder: (column) => column);

  GeneratedColumn<double> get airTemp =>
      $composableBuilder(column: $table.airTemp, builder: (column) => column);

  GeneratedColumn<double> get waterTemp =>
      $composableBuilder(column: $table.waterTemp, builder: (column) => column);

  GeneratedColumn<double> get cloudCover => $composableBuilder(
      column: $table.cloudCover, builder: (column) => column);
}

class $$WeatherSnapshotsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $WeatherSnapshotsTable,
    WeatherSnapshot,
    $$WeatherSnapshotsTableFilterComposer,
    $$WeatherSnapshotsTableOrderingComposer,
    $$WeatherSnapshotsTableAnnotationComposer,
    $$WeatherSnapshotsTableCreateCompanionBuilder,
    $$WeatherSnapshotsTableUpdateCompanionBuilder,
    (
      WeatherSnapshot,
      BaseReferences<_$AppDatabase, $WeatherSnapshotsTable, WeatherSnapshot>
    ),
    WeatherSnapshot,
    PrefetchHooks Function()> {
  $$WeatherSnapshotsTableTableManager(
      _$AppDatabase db, $WeatherSnapshotsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$WeatherSnapshotsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$WeatherSnapshotsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$WeatherSnapshotsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<double> latitude = const Value.absent(),
            Value<double> longitude = const Value.absent(),
            Value<DateTime> forecastTime = const Value.absent(),
            Value<DateTime> downloadedAt = const Value.absent(),
            Value<double> windSpeed = const Value.absent(),
            Value<double> windDirection = const Value.absent(),
            Value<double?> waveHeight = const Value.absent(),
            Value<double?> wavePeriod = const Value.absent(),
            Value<double?> airPressure = const Value.absent(),
            Value<double?> airTemp = const Value.absent(),
            Value<double?> waterTemp = const Value.absent(),
            Value<double?> cloudCover = const Value.absent(),
          }) =>
              WeatherSnapshotsCompanion(
            id: id,
            latitude: latitude,
            longitude: longitude,
            forecastTime: forecastTime,
            downloadedAt: downloadedAt,
            windSpeed: windSpeed,
            windDirection: windDirection,
            waveHeight: waveHeight,
            wavePeriod: wavePeriod,
            airPressure: airPressure,
            airTemp: airTemp,
            waterTemp: waterTemp,
            cloudCover: cloudCover,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required double latitude,
            required double longitude,
            required DateTime forecastTime,
            required DateTime downloadedAt,
            required double windSpeed,
            required double windDirection,
            Value<double?> waveHeight = const Value.absent(),
            Value<double?> wavePeriod = const Value.absent(),
            Value<double?> airPressure = const Value.absent(),
            Value<double?> airTemp = const Value.absent(),
            Value<double?> waterTemp = const Value.absent(),
            Value<double?> cloudCover = const Value.absent(),
          }) =>
              WeatherSnapshotsCompanion.insert(
            id: id,
            latitude: latitude,
            longitude: longitude,
            forecastTime: forecastTime,
            downloadedAt: downloadedAt,
            windSpeed: windSpeed,
            windDirection: windDirection,
            waveHeight: waveHeight,
            wavePeriod: wavePeriod,
            airPressure: airPressure,
            airTemp: airTemp,
            waterTemp: waterTemp,
            cloudCover: cloudCover,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$WeatherSnapshotsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $WeatherSnapshotsTable,
    WeatherSnapshot,
    $$WeatherSnapshotsTableFilterComposer,
    $$WeatherSnapshotsTableOrderingComposer,
    $$WeatherSnapshotsTableAnnotationComposer,
    $$WeatherSnapshotsTableCreateCompanionBuilder,
    $$WeatherSnapshotsTableUpdateCompanionBuilder,
    (
      WeatherSnapshot,
      BaseReferences<_$AppDatabase, $WeatherSnapshotsTable, WeatherSnapshot>
    ),
    WeatherSnapshot,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ChartersTableTableManager get charters =>
      $$ChartersTableTableManager(_db, _db.charters);
  $$DayLogsTableTableManager get dayLogs =>
      $$DayLogsTableTableManager(_db, _db.dayLogs);
  $$LogbookEntriesTableTableManager get logbookEntries =>
      $$LogbookEntriesTableTableManager(_db, _db.logbookEntries);
  $$TrackPointsTableTableManager get trackPoints =>
      $$TrackPointsTableTableManager(_db, _db.trackPoints);
  $$SailingSessionsTableTableManager get sailingSessions =>
      $$SailingSessionsTableTableManager(_db, _db.sailingSessions);
  $$WaypointsTableTableManager get waypoints =>
      $$WaypointsTableTableManager(_db, _db.waypoints);
  $$WeatherSnapshotsTableTableManager get weatherSnapshots =>
      $$WeatherSnapshotsTableTableManager(_db, _db.weatherSnapshots);
}
