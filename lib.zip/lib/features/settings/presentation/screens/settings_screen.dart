import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../../../../core/services/units_service.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final unitsAsync = ref.watch(unitsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Nastavenia')),
      body: unitsAsync.when(
        data: (units) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _Section('Jednotky merania'),
            Card(child: Column(children: [
              ListTile(
                leading: const Icon(Icons.thermostat),
                title: const Text('Teplota'),
                trailing: SegmentedButton<TempUnit>(
                  segments: const [
                    ButtonSegment(value: TempUnit.celsius, label: Text('°C')),
                    ButtonSegment(value: TempUnit.fahrenheit, label: Text('°F')),
                  ],
                  selected: {units.temp},
                  onSelectionChanged: (s) =>
                      ref.read(unitsProvider.notifier).setTemp(s.first),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.waves),
                title: const Text('Hĺbka / vlny'),
                trailing: SegmentedButton<DepthUnit>(
                  segments: const [
                    ButtonSegment(value: DepthUnit.meters, label: Text('m')),
                    ButtonSegment(value: DepthUnit.feet, label: Text('ft')),
                  ],
                  selected: {units.depth},
                  onSelectionChanged: (s) =>
                      ref.read(unitsProvider.notifier).setDepth(s.first),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.air),
                title: const Text('Vietor'),
                trailing: SegmentedButton<WindUnit>(
                  segments: const [
                    ButtonSegment(value: WindUnit.knots, label: Text('kn')),
                    ButtonSegment(value: WindUnit.ms, label: Text('m/s')),
                    ButtonSegment(value: WindUnit.beaufort, label: Text('Bft')),
                  ],
                  selected: {units.wind},
                  onSelectionChanged: (s) =>
                      ref.read(unitsProvider.notifier).setWind(s.first),
                ),
              ),
            ])),
            const SizedBox(height: 16),

            _Section('Jazyk'),
            Card(child: ListTile(
              leading: const Text('🌐', style: TextStyle(fontSize: 22)),
              title: const Text('Jazyk aplikácie'),
              subtitle: const Text('Slovenčina'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showLanguageDialog(context),
            )),
            const SizedBox(height: 16),

            _Section('O aplikácii'),
            Card(child: Column(children: [
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('O aplikácii'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showAboutDialog(context),
              ),
            ])),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
      ),
    );
  }

  void _showLanguageDialog(BuildContext context) {
    const langs = [
      ('🇸🇰', 'Slovenčina', 'sk'),
      ('🇬🇧', 'English', 'en'),
      ('🇩🇪', 'Deutsch', 'de'),
      ('🇪🇸', 'Español', 'es'),
      ('🇺🇦', 'Українська', 'uk'),
    ];
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Jazyk / Language'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: langs.map((l) => ListTile(
            leading: Text(l.$1, style: const TextStyle(fontSize: 24)),
            title: Text(l.$2),
            onTap: () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${l.$2} – v ďalšej verzii')));
            },
          )).toList(),
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) async {
    final info = await PackageInfo.fromPlatform();
    if (!context.mounted) return;
    showDialog(
      context: context,
      builder: (ctx) => AboutDialog(
        applicationName: 'HMB Sailing Log',
        applicationVersion: 'v${info.version} (build ${info.buildNumber})',
        applicationIcon: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.asset('assets/icons/app_icon.png',
              width: 56, height: 56,
              errorBuilder: (_, __, ___) =>
                  const Icon(Icons.sailing, size: 56)),
        ),
        applicationLegalese: '© 2025 Lacoste\nVšetky práva vyhradené',
        children: [
          const SizedBox(height: 16),
          const Text('Profesionálny lodný denník pre jachtárov.',
              style: TextStyle(fontSize: 14)),
          const SizedBox(height: 8),
          const _AboutRow(Icons.gps_fixed, 'GPS tracking s auto-zápismi'),
          const _AboutRow(Icons.book, 'Viacdenný charterový denník'),
          const _AboutRow(Icons.map, 'Offline nautické mapy (OpenSeaMap)'),
          const _AboutRow(Icons.cloud, 'Morské počasie (Open-Meteo)'),
          const _AboutRow(Icons.picture_as_pdf, 'Export PDF + GPX'),
          const _AboutRow(Icons.shield, 'Safety briefing & Mayday Card'),
          const SizedBox(height: 16),
          const Text('Autor: Lacoste',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Verzia: ${info.version} (${info.buildNumber})',
              style: const TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 4),
          const Text('Platform: Flutter / Android',
              style: TextStyle(color: Colors.grey, fontSize: 12)),
        ],
      ),
    );
  }
}

class _AboutRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _AboutRow(this.icon, this.text);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(children: [
      Icon(icon, size: 16, color: Theme.of(context).colorScheme.primary),
      const SizedBox(width: 8),
      Text(text, style: const TextStyle(fontSize: 13)),
    ]),
  );
}

class _Section extends StatelessWidget {
  final String t;
  const _Section(this.t);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(
        color: Theme.of(context).colorScheme.primary,
        fontWeight: FontWeight.bold)));
}
