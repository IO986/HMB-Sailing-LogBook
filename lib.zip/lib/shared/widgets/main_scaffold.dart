import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/tracking/providers/tracking_provider.dart';
import '../../core/services/gps_tracking_service.dart';

class MainScaffold extends ConsumerStatefulWidget {
  final Widget child;
  const MainScaffold({super.key, required this.child});

  @override
  ConsumerState<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends ConsumerState<MainScaffold> {
  DateTime? _lastBackPress;

  static const _tabs = [
    (icon: Icons.map_outlined,        activeIcon: Icons.map,          label: 'Mapa',        path: '/map'),
    (icon: Icons.play_circle_outline, activeIcon: Icons.play_circle,  label: 'Tracking',    path: '/tracking'),
    (icon: Icons.book_outlined,       activeIcon: Icons.book,         label: 'Denník',      path: '/logbook'),
    (icon: Icons.cloud_outlined,      activeIcon: Icons.cloud,        label: 'Počasie',     path: '/weather'),
    (icon: Icons.shield_outlined,     activeIcon: Icons.shield,       label: 'Bezpečnosť',  path: '/safety'),
    (icon: Icons.settings_outlined,   activeIcon: Icons.settings,     label: 'Nastavenia',  path: '/settings'),
  ];

  int _idx(BuildContext ctx) {
    try {
      final loc = GoRouterState.of(ctx).uri.path;
      final i = _tabs.indexWhere((t) => loc.startsWith(t.path));
      return i < 0 ? 0 : i;
    } catch (_) { return 0; }
  }

  void _handleBack(BuildContext context) {
    try {
      final loc = GoRouterState.of(context).uri.path;
      final isMainTab = _tabs.any((t) => t.path == loc);
      final currentIndex = _idx(context);

      // Vnorená stránka → GoRouter pop
      if (!isMainTab) {
        if (context.canPop()) {
          context.pop();
        } else {
          context.go('/logbook');
        }
        return;
      }

      // Nie na mape → choď na mapu
      if (currentIndex != 0) {
        context.go('/map');
        return;
      }

      // Na mape - double back
      final now = DateTime.now();
      final isDouble = _lastBackPress != null &&
          now.difference(_lastBackPress!) < const Duration(seconds: 2);

      if (!isDouble) {
        _lastBackPress = now;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Stlač Späť ešte raz pre ukončenie'),
            duration: Duration(seconds: 2),
          ),
        );
        return;
      }

      // Double back - ukončenie
      if (GpsTrackingService().isTracking) {
        _showExitDialog(context);
      } else {
        SystemNavigator.pop(animated: true);
      }
    } catch (e) {
      print('[BACK] error: $e');
    }
  }

  void _showExitDialog(BuildContext context) {
    showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Tracking beží'),
        content: const Text('Tracking je aktívny. Čo chceš urobiť?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Zrušiť'),
          ),
          OutlinedButton.icon(
            onPressed: () async {
              Navigator.pop(ctx);
              await ref.read(trackingNotifierProvider.notifier).stopTracking();
              SystemNavigator.pop(animated: true);
            },
            icon: const Icon(Icons.stop, color: Colors.red),
            label: const Text('Zastaviť a ukončiť',
                style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              SystemNavigator.pop(animated: true);
            },
            icon: const Icon(Icons.minimize),
            label: const Text('Nechať bežať'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isTracking = ref.watch(isTrackingProvider);
    final currentIndex = _idx(context);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) => _handleBack(context),
      child: Scaffold(
        body: widget.child,
        bottomNavigationBar: NavigationBar(
          selectedIndex: currentIndex,
          onDestinationSelected: (i) => context.go(_tabs[i].path),
          destinations: _tabs.map((t) {
            final isTrack = t.path == '/tracking';
            return NavigationDestination(
              icon: Badge(
                isLabelVisible: isTrack && isTracking,
                child: Icon(t.icon),
              ),
              selectedIcon: Icon(t.activeIcon),
              label: t.label,
            );
          }).toList(),
        ),
      ),
    );
  }
}
