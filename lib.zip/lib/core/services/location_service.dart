import 'dart:async';
import 'package:geolocator/geolocator.dart';

/// Singleton GPS service - vždy aktívny, nezávislý od trackingu
class LocationService {
  static final LocationService _i = LocationService._();
  factory LocationService() => _i;
  LocationService._();

  StreamSubscription<Position>? _sub;
  final _ctrl = StreamController<Position>.broadcast();
  Position? _lastPosition;
  bool _initialized = false;

  Stream<Position> get stream => _ctrl.stream;
  Position? get lastPosition => _lastPosition;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    final svcOn = await Geolocator.isLocationServiceEnabled();
    if (!svcOn) return;

    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.deniedForever) return;

    // Načítaj poslednú known position okamžite
    try {
      final last = await Geolocator.getLastKnownPosition();
      if (last != null) {
        _lastPosition = last;
        _ctrl.add(last);
      }
    } catch (_) {}

    // Spusti stream
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen((pos) {
      _lastPosition = pos;
      _ctrl.add(pos);
    }, onError: (e) => print('[LOC] error: $e'));

    print('[LOC] Location service started');
  }

  void dispose() {
    _sub?.cancel();
    _ctrl.close();
  }
}
