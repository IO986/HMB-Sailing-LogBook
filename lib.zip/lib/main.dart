import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'app_router.dart';
import 'core/database/app_database.dart';
import 'core/services/background_service.dart';
import 'core/services/gps_tracking_service.dart';
import 'core/services/location_service.dart';
import 'core/services/weather_repository.dart';
import 'core/services/weather_service.dart';
import 'features/export/services/export_service.dart';
import 'shared/theme/app_theme.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  return db;
});

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('sk', null);

  final db = AppDatabase();
  await db.fixOrphanedSessions();

  // Spusti GPS vždy - nezávisle od trackingu
  await LocationService().init();
  GpsTrackingService().setDatabase(db);
  WeatherService().setDatabase(db);
  WeatherRepository().setDatabase(db);
  ExportService().setDatabase(db);

  await BackgroundService.init();

  runApp(ProviderScope(
    overrides: [databaseProvider.overrideWithValue(db)],
    child: const HmbSailingLogApp(),
  ));
}

class HmbSailingLogApp extends ConsumerWidget {
  const HmbSailingLogApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    return MaterialApp.router(
      title: 'HMB Sailing Log',
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      routerConfig: router,
      debugShowCheckedModeBanner: false,
      locale: const Locale('sk'),
    );
  }
}
